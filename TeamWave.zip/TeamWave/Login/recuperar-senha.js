// =========================================
// CONFIGURAÇÕES INICIAIS
// =========================================

// Esta é a mesma chave utilizada no cadastro e no login.
const CHAVE_USUARIOS = "teamwave_usuarios";

// Seleciona os formulários e os campos.
const verificationForm = document.getElementById("verificationForm");
const passwordForm = document.getElementById("passwordForm");
const phoneSimulation = document.getElementById("phoneSimulation");
const confirmationSimulation = document.getElementById("confirmationSimulation");

const continuePasswordButton = document.getElementById("continuePasswordButton");
const phoneEnding = document.getElementById("phoneEnding");
const phoneStatus = document.getElementById("phoneStatus");

const emailInput = document.getElementById("email");
const cpfInput = document.getElementById("cpf");
const novaSenhaInput = document.getElementById("novaSenha");
const confirmarSenhaInput = document.getElementById("confirmarSenha");

const verificationMessage = document.getElementById("verificationMessage");
const passwordMessage = document.getElementById("passwordMessage");

// Guarda a posição do usuário encontrado para atualizar a senha depois.
let indiceUsuario = -1;
let temporizadorConfirmacao;


// =========================================
// FUNÇÕES DE ARMAZENAMENTO
// =========================================

// Recupera os usuários que foram cadastrados.
function obterUsuarios() {
    try {
        const dadosSalvos = localStorage.getItem(CHAVE_USUARIOS);
        return dadosSalvos ? JSON.parse(dadosSalvos) : [];

    } catch (erro) {
        return null;
    }
}


// =========================================
// MÁSCARA DO CPF
// =========================================

function formatarCPF(valor) {
    let numeros = valor.replace(/\D/g, "").slice(0, 11);

    numeros = numeros.replace(/(\d{3})(\d)/, "$1.$2");
    numeros = numeros.replace(/(\d{3})(\d)/, "$1.$2");
    numeros = numeros.replace(/(\d{3})(\d{1,2})$/, "$1-$2");

    return numeros;
}

// Formata o CPF enquanto o usuário digita.
cpfInput.addEventListener("input", function () {
    cpfInput.value = formatarCPF(cpfInput.value);
});


// =========================================
// VALIDADOR DE SENHA
// =========================================

// Mantém as mesmas regras utilizadas no cadastro.
function validarSenha(senha) {

    if (senha.length < 8) {
        return "A senha deve ter pelo menos 8 caracteres.";
    }

    if (!/[A-ZÀ-ÖØ-Þ]/.test(senha)) {
        return "A senha deve conter pelo menos uma letra maiúscula.";
    }

    if (!/[0-9]/.test(senha)) {
        return "A senha deve conter pelo menos um número.";
    }

    if (!/[^A-Za-zÀ-ÖØ-öø-ÿ0-9\s]/.test(senha)) {
        return "A senha deve conter pelo menos um caractere especial.";
    }

    return "";
}


// =========================================
// VERIFICAÇÃO DOS DADOS DA CONTA
// =========================================

verificationForm.addEventListener("submit", function (evento) {
    evento.preventDefault();

    // Recupera e padroniza os dados informados.
    const email = emailInput.value.trim().toLowerCase();
    const cpf = cpfInput.value.replace(/\D/g, "");

    // Recupera os usuários salvos.
    const usuarios = obterUsuarios();

    if (usuarios === null) {
        verificationMessage.textContent = "Não foi possível acessar os cadastros salvos.";
        verificationMessage.className = "message error";
        return;
    }

    // Procura uma conta que tenha o mesmo e-mail e CPF.
    indiceUsuario = usuarios.findIndex(function (usuario) {
        const cpfCadastrado = (usuario.cpf || "").replace(/\D/g, "");

        return usuario.email === email && cpfCadastrado === cpf;
    });

    // Impede a recuperação quando os dados não correspondem a uma conta.
    if (indiceUsuario === -1) {
        verificationMessage.textContent = "E-mail ou CPF não encontrado. Confira os dados e tente novamente.";
        verificationMessage.className = "message error";
        return;
    }

    // Recupera os quatro últimos números do celular cadastrado.
    const telefone = (usuarios[indiceUsuario].telefone || "").replace(/\D/g, "");
    phoneEnding.textContent = telefone.length >= 4 ? telefone.slice(-4) : "não informado";

    // Mostra a notificação como se tivesse sido enviada ao celular.
    // Nenhuma mensagem é enviada de verdade nesta demonstração.
    verificationForm.classList.add("hidden");
    phoneSimulation.classList.remove("hidden");
    phoneStatus.textContent = "Esperando o recebimento da resposta da notificação...";

    // Simula que o usuário recebeu a notificação e tocou em "Sou eu".
    // Não existe botão de confirmação na página.
    clearTimeout(temporizadorConfirmacao);

    temporizadorConfirmacao = setTimeout(function () {
        phoneSimulation.classList.add("hidden");
        confirmationSimulation.classList.remove("hidden");
    }, 10000);
});


// =========================================
// CONTINUAR PARA A NOVA SENHA
// =========================================

continuePasswordButton.addEventListener("click", function () {

    // Só mostra os campos de senha depois da confirmação simulada.
    confirmationSimulation.classList.add("hidden");
    passwordForm.classList.remove("hidden");

    novaSenhaInput.focus();
});


// =========================================
// CADASTRO DA NOVA SENHA
// =========================================

passwordForm.addEventListener("submit", function (evento) {
    evento.preventDefault();

    // Recupera as senhas e remove espaços do início e do final.
    const novaSenha = novaSenhaInput.value.trim();
    const confirmarSenha = confirmarSenhaInput.value.trim();

    // Verifica se a senha atende às regras do cadastro.
    const erroSenha = validarSenha(novaSenha);

    if (erroSenha !== "") {
        passwordMessage.textContent = erroSenha;
        passwordMessage.className = "message error";
        novaSenhaInput.focus();
        return;
    }

    // Verifica se os dois campos possuem a mesma senha.
    if (novaSenha !== confirmarSenha) {
        passwordMessage.textContent = "As senhas não são iguais.";
        passwordMessage.className = "message error";
        confirmarSenhaInput.focus();
        return;
    }

    // Recupera novamente os usuários antes de salvar a alteração.
    const usuarios = obterUsuarios();

    if (usuarios === null || indiceUsuario < 0 || !usuarios[indiceUsuario]) {
        passwordMessage.textContent = "Não foi possível localizar a conta. Faça a verificação novamente.";
        passwordMessage.className = "message error";
        return;
    }

    // Atualiza somente a senha do usuário confirmado.
    usuarios[indiceUsuario].senha = novaSenha;

    try {
        localStorage.setItem(CHAVE_USUARIOS, JSON.stringify(usuarios));

        passwordMessage.textContent = "Senha alterada com sucesso! Redirecionando para o login...";
        passwordMessage.className = "message success";

        // Impede novos envios enquanto a página redireciona.
        passwordForm.querySelector("button[type='submit']").disabled = true;

        setTimeout(function () {
            window.location.href = "login.html?senha=alterada";
        }, 1200);

    } catch (erro) {
        passwordMessage.textContent = "Não foi possível salvar a nova senha no navegador.";
        passwordMessage.className = "message error";
    }
});