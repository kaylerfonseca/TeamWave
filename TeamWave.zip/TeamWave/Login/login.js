// =========================================
// CONFIGURAÇÕES INICIAIS
// =========================================

// Mesma chave utilizada na página de Cadastro.
const CHAVE_USUARIOS = "teamwave_usuarios";

// Seleciona o formulário e os campos.
const formulario = document.getElementById("loginForm");

const emailInput = document.getElementById("email");
const senhaInput = document.getElementById("senha");


// =========================================
// MENSAGEM DE CADASTRO REALIZADO
// =========================================

// Verifica se o usuário acabou de realizar um cadastro.
const parametros = new URLSearchParams(window.location.search);

if (parametros.get("cadastro") === "sucesso") {
    alert("Cadastro realizado com sucesso! Entre com seu e-mail e senha.");
}

// Informa quando o usuário acabou de recuperar a senha.
if (parametros.get("senha") === "alterada") {
    alert("Senha alterada com sucesso! Entre com sua nova senha.");
}


// =========================================
// FUNÇÃO DE LOGIN
// =========================================

formulario.addEventListener("submit", function (evento) {

    evento.preventDefault();

    // Recupera os dados digitados.
    const email = emailInput.value.trim().toLowerCase();
    const senha = senhaInput.value;

    // Verifica se existem usuários cadastrados.
    let usuarios = [];

    try {
        const dadosSalvos = localStorage.getItem(CHAVE_USUARIOS);

        usuarios = dadosSalvos ? JSON.parse(dadosSalvos) : [];

    } catch (erro) {
        alert("Não foi possível acessar os dados dos usuários.");
        return;
    }

    // Impede o login quando não existe nenhum cadastro.
    if (usuarios.length === 0) {
        alert("Nenhum usuário cadastrado! Faça seu cadastro primeiro.");
        return;
    }

    // Procura um usuário com o e-mail e a senha informados.
    const usuarioEncontrado = usuarios.find(function (usuario) {
        return usuario.email === email && usuario.senha === senha;
    });

    // Verifica se o usuário foi encontrado.
    if (usuarioEncontrado) {

        alert("Login realizado com sucesso! Bem-vindo(a), " + usuarioEncontrado.nome + "!");

        // Salva o usuário atualmente conectado.
        localStorage.setItem("teamwave_usuario_logado", JSON.stringify({
            nome: usuarioEncontrado.nome,
            email: usuarioEncontrado.email,
            perfil: usuarioEncontrado.perfil
        }));

        // Abre o Dashboard correspondente ao perfil cadastrado.
        const paginaDashboard = usuarioEncontrado.perfil === "gestor"
            ? "../Gestor/Dashboard/dashboard.html"
            : "../Membro/Dashboard/dashboard.html";
        window.location.href = paginaDashboard;

    } else {

        alert("E-mail ou senha incorretos!");

    }

});