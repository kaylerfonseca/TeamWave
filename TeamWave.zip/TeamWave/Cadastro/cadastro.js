// =========================================
// CONFIGURAÇÕES INICIAIS
// =========================================

// Chave utilizada para armazenar os usuários no navegador.
const CHAVE_USUARIOS = "teamwave_usuarios";

// Seleciona o formulário e os campos.
const formulario = document.getElementById("registerForm");

const nomeInput = document.getElementById("nome");
const emailInput = document.getElementById("email");
const senhaInput = document.getElementById("senha");
const confirmarSenhaInput = document.getElementById("confirmarSenha");
const telefoneInput = document.getElementById("telefone");
const cpfInput = document.getElementById("cpf");
const dataNascimentoInput = document.getElementById("dataNascimento");


// =========================================
// FUNÇÕES DE ARMAZENAMENTO
// =========================================

// Recupera os usuários que já foram cadastrados.
function obterUsuarios() {
    try {
        const usuarios = localStorage.getItem(CHAVE_USUARIOS);

        return usuarios ? JSON.parse(usuarios) : [];
    } catch (erro) {
        alert("Não foi possível acessar os cadastros salvos.");
        return [];
    }
}


// =========================================
// MÁSCARA DO CPF
// =========================================

function formatarCPF(valor) {
    let numeros = valor.replace(/\D/g, "").slice(0, 11);

    numeros = numeros.replace(/(\d{3})(\d)/, "$1.$2");
    numeros = numeros.replace(/(\d{3})(\d)/, "$1.$2");
    numeros = numeros.replace(/(\d{3})(\d{1,2})$/, "$1-$2");

    return numeros;
}

// Aplica a formatação enquanto o usuário digita.
cpfInput.addEventListener("input", function () {
    cpfInput.value = formatarCPF(cpfInput.value);
});


// =========================================
// VALIDADOR DE CPF
// =========================================

function validarCPF(cpf) {

    // Remove pontos e traços.
    const numeros = cpf.replace(/\D/g, "");

    // Verifica se possui 11 números.
    if (numeros.length !== 11) {
        return false;
    }

    // Impede CPFs com todos os números iguais.
    if (/^(\d)\1{10}$/.test(numeros)) {
        return false;
    }

    // Calcula o primeiro e o segundo dígitos verificadores.
    function calcularDigito(base, pesoInicial) {
        let soma = 0;

        for (let i = 0; i < base.length; i++) {
            soma += Number(base[i]) * (pesoInicial - i);
        }

        let resultado = (soma * 10) % 11;

        if (resultado === 10) {
            resultado = 0;
        }

        return resultado;
    }

    const primeiroDigito = calcularDigito(numeros.substring(0, 9), 10);

    if (primeiroDigito !== Number(numeros[9])) {
        return false;
    }

    const segundoDigito = calcularDigito(numeros.substring(0, 10), 11);

    if (segundoDigito !== Number(numeros[10])) {
        return false;
    }

    return true;
}


// =========================================
// MÁSCARA DO TELEFONE
// =========================================

function formatarTelefone(valor) {
    const numeros = valor.replace(/\D/g, "").slice(0, 11);

    if (numeros.length <= 2) {
        return numeros.length ? `(${numeros}` : "";
    }

    const ddd = numeros.substring(0, 2);
    const telefone = numeros.substring(2);

    if (telefone.length <= 4) {
        return `(${ddd}) ${telefone}`;
    }

    if (telefone.length <= 8) {
        return `(${ddd}) ${telefone.substring(0, 4)}-${telefone.substring(4)}`;
    }

    return `(${ddd}) ${telefone.substring(0, 5)}-${telefone.substring(5)}`;
}

// Aplica a formatação enquanto o usuário digita.
telefoneInput.addEventListener("input", function () {
    telefoneInput.value = formatarTelefone(telefoneInput.value);
});


// =========================================
// VALIDADOR DE TELEFONE
// =========================================

function validarTelefone(telefone) {

    // Remove parênteses, espaços e traços.
    const numeros = telefone.replace(/\D/g, "");

    // DDDs existentes no Brasil.
    const ddds = [
        11, 12, 13, 14, 15, 16, 17, 18, 19,
        21, 22, 24, 27, 28,
        31, 32, 33, 34, 35, 37, 38,
        41, 42, 43, 44, 45, 46, 47, 48, 49,
        51, 53, 54, 55,
        61, 62, 63, 64, 65, 66, 67, 68, 69,
        71, 73, 74, 75, 77, 79,
        81, 82, 83, 84, 85, 86, 87, 88, 89,
        91, 93, 94, 95, 96, 97, 98, 99
    ];

    // Verifica se o DDD é válido.
    const ddd = Number(numeros.substring(0, 2));

    if (!ddds.includes(ddd)) {
        return false;
    }

    // Valida telefone fixo com 10 dígitos.
    if (numeros.length === 10) {
        return /^[2-5]\d{7}$/.test(numeros.substring(2));
    }

    // Valida celular com 11 dígitos.
    if (numeros.length === 11) {
        return /^9\d{8}$/.test(numeros.substring(2));
    }

    return false;
}


// =========================================
// DATA DE NASCIMENTO
// =========================================

// Impede que o usuário selecione uma data futura.
function obterDataAtual() {
    const hoje = new Date();

    const ano = hoje.getFullYear();
    const mes = String(hoje.getMonth() + 1).padStart(2, "0");
    const dia = String(hoje.getDate()).padStart(2, "0");

    return `${ano}-${mes}-${dia}`;
}

dataNascimentoInput.max = obterDataAtual();

// =========================================
// VALIDADOR DE SENHA
// =========================================

function validarSenha(senha) {

    // Verifica se possui pelo menos 8 caracteres.
    if (senha.length < 8) {
        return "A senha deve ter pelo menos 8 caracteres.";
    }

    // Verifica se possui pelo menos uma letra maiúscula.
    if (!/[A-ZÀ-ÖØ-Þ]/.test(senha)) {
        return "A senha deve conter pelo menos uma letra maiúscula.";
    }

    // Verifica se possui pelo menos um número.
    if (!/[0-9]/.test(senha)) {
        return "A senha deve conter pelo menos um número.";
    }

    // Verifica se possui pelo menos um caractere especial.
    if (!/[^A-Za-zÀ-ÖØ-öø-ÿ0-9\s]/.test(senha)) {
        return "A senha deve conter pelo menos um caractere especial.";
    }

    // Se passar por todas as verificações, não retorna erro.
    return "";
}

// =========================================
// CADASTRAMENTO DO USUÁRIO
// =========================================

formulario.addEventListener("submit", function (evento) {

    evento.preventDefault();

    // Recupera os valores preenchidos.
    const nome = nomeInput.value.trim();
    const email = emailInput.value.trim().toLowerCase();
    const senha = senhaInput.value.trim();
    const confirmarSenha = confirmarSenhaInput.value.trim();
    const telefone = telefoneInput.value;
    const cpf = cpfInput.value;
    const dataNascimento = dataNascimentoInput.value;

    // Valida a segurança da senha.
    const erroSenha = validarSenha(senha);

    if (erroSenha !== "") {
        alert(erroSenha);
        senhaInput.focus();
        return;
    }

    // Verifica se as senhas são iguais.
    if (senha !== confirmarSenha) {
        alert("As senhas não são iguais!");
        confirmarSenhaInput.focus();
        return;
    }

    // Valida o CPF.
    if (!validarCPF(cpf)) {
        alert("CPF inválido! Verifique os números informados.");
        cpfInput.focus();
        return;
    }

    // Valida o telefone.
    if (!validarTelefone(telefone)) {
        alert("Telefone inválido! Informe um DDD e um número válido.");
        telefoneInput.focus();
        return;
    }

    // Recupera os cadastros existentes.
    const usuarios = obterUsuarios();

    // Verifica se o e-mail já está cadastrado.
    const emailExiste = usuarios.some(function (usuario) {
        return usuario.email === email;
    });

    if (emailExiste) {
        alert("Este e-mail já possui um cadastro!");
        emailInput.focus();
        return;
    }

    // Verifica se o CPF já está cadastrado.
    const cpfNumeros = cpf.replace(/\D/g, "");

    const cpfExiste = usuarios.some(function (usuario) {
        return usuario.cpf.replace(/\D/g, "") === cpfNumeros;
    });

    if (cpfExiste) {
        alert("Este CPF já está cadastrado!");
        cpfInput.focus();
        return;
    }

    // Identifica se o cadastro é de Membro ou Gestor.
    const parametros = new URLSearchParams(window.location.search);
    const perfilSelecionado = parametros.get("perfil");

    const perfil = perfilSelecionado === "gestor" ? "gestor" : "membro";

    // Cria o objeto com os dados do usuário.
    const novoUsuario = {
        nome: nome,
        email: email,
        senha: senha,
        telefone: telefone,
        cpf: cpf,
        dataNascimento: dataNascimento,
        perfil: perfil
    };

    // Adiciona o novo usuário à lista.
    usuarios.push(novoUsuario);

    // Salva todos os usuários no navegador.
    try {
        localStorage.setItem(CHAVE_USUARIOS, JSON.stringify(usuarios));

        alert("Cadastro realizado com sucesso! Agora faça seu login.");

        // Redireciona para a página de Login.
        window.location.href = "../Login/login.html?cadastro=sucesso";

    } catch (erro) {
        alert("Não foi possível salvar o cadastro no navegador.");
    }

});