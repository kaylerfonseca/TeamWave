/* =========================================================
   TeamWave - Chat interno (JavaScript puro)
   As conversas e mensagens deste protótipo são armazenadas
   localmente no navegador. O IndexedDB guarda os anexos.
========================================================= */
document.addEventListener('DOMContentLoaded', () => {
    // ================================================================
    // 1. CONFIGURAÇÕES E ELEMENTOS DA PÁGINA
    // ================================================================
    const CHAVE_CONVERSAS = 'teamwave_chat_conversas_v1';
    const CHAVE_USUARIO_ATUAL = 'teamwave_usuario_logado';
    const BANCO_ANEXOS = 'teamwave_chat_arquivos_db';
    const LIMITE_ANEXO = 5 * 1024 * 1024; // 5 MB por arquivo
    const PRAZO_EDICAO_MENSAGEM = 15 * 60 * 1000;

    function carregarUsuarioAtual() {
        try {
            const usuario = JSON.parse(localStorage.getItem(CHAVE_USUARIO_ATUAL) || 'null');
            return {
                nome: typeof usuario?.nome === 'string' && usuario.nome.trim() ? usuario.nome.trim() : 'Pessoa',
                email: typeof usuario?.email === 'string' ? usuario.email.trim().toLocaleLowerCase('pt-BR') : '',
                perfil: typeof usuario?.perfil === 'string' ? usuario.perfil : ''
            };
        } catch (erro) {
            console.warn('Não foi possível ler o usuário conectado:', erro);
            return { nome: 'Pessoa', email: '', perfil: '' };
        }
    }

    const usuarioAtual = carregarUsuarioAtual();
    const USUARIO_ATUAL = usuarioAtual.nome;
    const ID_USUARIO_ATUAL = usuarioAtual.email
        ? `email:${usuarioAtual.email}`
        : `nome:${USUARIO_ATUAL.toLocaleLowerCase('pt-BR')}`;

    const areaChat = document.querySelector('.chat-workspace');
    const listaConversas = document.getElementById('conversation-list');
    const contadorConversas = document.getElementById('conversation-count');
    const avisoSemConversas = document.getElementById('conversation-empty');
    const pesquisaConversas = document.getElementById('conversation-search');
    const pesquisaGeral = document.getElementById('global-search');
    const botoesFiltro = Array.from(document.querySelectorAll('.filter-chip'));
    const estadoVazio = document.getElementById('chat-empty-state');
    const conversaAtiva = document.getElementById('active-chat');
    const nomeAtivo = document.getElementById('active-conversation-name');
    const subtituloAtivo = document.getElementById('active-conversation-subtitle');
    const areaMensagens = document.getElementById('messages-area');
    const painelFixadas = document.getElementById('pinned-messages-panel');
    const listaFixadas = document.getElementById('pinned-message-list');
    const contadorFixadas = document.getElementById('pinned-count');
    const contadorFavoritas = document.getElementById('favorites-count');
    const botoesFiltroMensagens = Array.from(document.querySelectorAll('[data-message-filter]'));
    const formularioMensagem = document.getElementById('message-form');
    const campoMensagem = document.getElementById('message-input');
    const campoArquivo = document.getElementById('message-file');
    const botaoAnexo = document.getElementById('attach-file');
    const botaoGravarAudio = document.getElementById('record-audio');
    const iconeGravarAudio = document.getElementById('record-audio-icon');
    const statusGravacao = document.getElementById('recording-status');
    const textoStatusGravacao = document.getElementById('recording-status-text');
    const previewAnexo = document.getElementById('attachment-preview');
    const previewResposta = document.getElementById('reply-preview');
    const nomeResposta = document.getElementById('reply-preview-name');
    const textoResposta = document.getElementById('reply-preview-text');
    const painelInfo = document.getElementById('conversation-info');
    const listaParticipantes = document.getElementById('participants-list');
    const modalNovaConversa = document.getElementById('new-conversation-modal');
    const formularioNovaConversa = document.getElementById('new-conversation-form');
    const tipoConversa = document.getElementById('conversation-type');
    const campoNomeConversa = document.getElementById('conversation-name');
    const labelNomeConversa = document.getElementById('conversation-name-label');
    const campoMembros = document.getElementById('conversation-members');
    const campoMembrosContainer = document.getElementById('group-members-field');
    const aviso = document.getElementById('toast-message');

    let conversas = carregarConversas();
    let conversaSelecionada = conversas.length ? conversas[0].id : null;
    let filtroAtual = 'all';
    let respostaSelecionada = null;
    let mensagemEmEdicaoId = null;
    let filtroMensagens = 'all';
    let arquivosSelecionados = [];
    let gravadorAudio = null;
    let fluxoMicrofone = null;
    let partesAudio = [];
    let inicioGravacao = 0;
    let temporizadorGravacao = null;
    let descartarGravacao = false;
    const urlsAudioAtivos = new Set();
    let temporizadorAviso = null;
    let bancoArquivos = abrirBancoArquivos().catch(erro => {
        console.error('O armazenamento de anexos não está disponível:', erro);
        return null;
    });

    // ================================================================
    // 2. FUNÇÕES GERAIS E IDENTIFICADORES
    // ================================================================
    function gerarId() {
        if (window.crypto && typeof window.crypto.randomUUID === 'function') {
            return window.crypto.randomUUID();
        }
        return `chat-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    }

    function normalizarTexto(valor) {
        return String(valor || '').toLocaleLowerCase('pt-BR').trim();
    }

    function obterIdentificadorRemetente(mensagem) {
        if (typeof mensagem.senderId === 'string' && mensagem.senderId.trim()) {
            return mensagem.senderId.trim().slice(0, 180);
        }
        return mensagem.sender === 'me'
            ? ID_USUARIO_ATUAL
            : `nome:${normalizarTexto(mensagem.senderName || 'Participante')}`;
    }

    function mensagemPodeSerEditada(mensagem) {
        const instanteEnvio = new Date(mensagem.createdAt).getTime();
        const tempoDecorrido = Date.now() - instanteEnvio;
        return mensagem.senderId === ID_USUARIO_ATUAL &&
            Boolean(mensagem.text) &&
            Number.isFinite(instanteEnvio) &&
            tempoDecorrido >= 0 &&
            tempoDecorrido <= PRAZO_EDICAO_MENSAGEM;
    }

    function obterMatizRemetente(identificador) {
        let hash = 0;
        for (let indice = 0; indice < identificador.length; indice++) {
            hash = (hash * 31 + identificador.charCodeAt(indice)) >>> 0;
        }
        return hash % 360;
    }

    function iniciais(nome) {
        const partes = String(nome || '').trim().split(/\s+/).filter(Boolean);
        if (!partes.length) return '?';
        return partes.length === 1
            ? partes[0].slice(0, 2).toLocaleUpperCase('pt-BR')
            : `${partes[0][0]}${partes[partes.length - 1][0]}`.toLocaleUpperCase('pt-BR');
    }

    function mostrarAviso(mensagem) {
        aviso.textContent = mensagem;
        aviso.classList.add('show');
        clearTimeout(temporizadorAviso);
        temporizadorAviso = setTimeout(() => aviso.classList.remove('show'), 2800);
    }

    function conversaAtual() {
        return conversas.find(conversa => conversa.id === conversaSelecionada) || null;
    }

    function formatarHorario(data) {
        const valor = new Date(data);
        if (Number.isNaN(valor.getTime())) return '';
        return valor.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    }

    function formatarDia(data) {
        const valor = new Date(data);
        const hoje = new Date();
        const ontem = new Date();
        ontem.setDate(hoje.getDate() - 1);

        if (valor.toDateString() === hoje.toDateString()) return 'Hoje';
        if (valor.toDateString() === ontem.toDateString()) return 'Ontem';
        return valor.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
    }

    function descricaoAnexo(anexo) {
        if (!anexo) return '';
        return String(anexo.type || '').startsWith('audio/')
            ? `Áudio: ${anexo.name}`
            : `Arquivo: ${anexo.name}`;
    }

    function formatarUltimaMensagem(conversa) {
        const ultima = conversa.messages[conversa.messages.length - 1];
        if (!ultima) return 'Nenhuma mensagem ainda';
        const texto = ultima.text || obterResumoAnexos(ultima) || 'Mensagem';
        return `${ultima.senderId === ID_USUARIO_ATUAL ? 'Você: ' : ''}${texto}`;
    }

    function horarioLista(conversa) {
        const ultima = conversa.messages[conversa.messages.length - 1];
        return ultima ? formatarHorario(ultima.createdAt) : '';
    }

    // ================================================================
    // 3. CONVERSAS DE EXEMPLO E ARMAZENAMENTO LOCAL
    // ================================================================
    function criarConversasExemplo() {
        const agora = Date.now();
        const minutosAtras = minutos => new Date(agora - minutos * 60000).toISOString();

        return [
            {
                id: gerarId(),
                name: 'Equipe TeamWave',
                type: 'group',
                members: [USUARIO_ATUAL, 'Ana Souza', 'Lucas Mendes', 'Marina Costa'],
                demo: true,
                createdAt: minutosAtras(80),
                messages: [
                    {
                        id: gerarId(), sender: 'other', senderId: 'nome:ana souza', senderName: 'Ana Souza',
                        text: 'Pessoal, vamos utilizar este espaço para alinhar as atividades do projeto TeamWave.',
                        createdAt: minutosAtras(72), attachment: null, replyTo: null
                    },
                    {
                        id: gerarId(), sender: 'me', senderId: ID_USUARIO_ATUAL, senderName: USUARIO_ATUAL,
                        text: 'Combinado! Assim conseguimos manter as informações da equipe organizadas.',
                        createdAt: minutosAtras(65), attachment: null, replyTo: null
                    },
                    {
                        id: gerarId(), sender: 'other', senderId: 'nome:lucas mendes', senderName: 'Lucas Mendes',
                        text: 'Ótimo. Vou compartilhar as atualizações por aqui.',
                        createdAt: minutosAtras(58), attachment: null, replyTo: null
                    }
                ]
            },
            {
                id: gerarId(),
                name: 'Marina Costa',
                type: 'individual',
                members: [USUARIO_ATUAL, 'Marina Costa'],
                demo: true,
                createdAt: minutosAtras(180),
                messages: [
                    {
                        id: gerarId(), sender: 'other', senderId: 'nome:marina costa', senderName: 'Marina Costa',
                        text: 'Oi! Podemos conversar sobre a organização das próximas tarefas?',
                        createdAt: minutosAtras(175), attachment: null, replyTo: null
                    }
                ]
            }
        ];
    }

    function validarConversa(conversa) {
        if (!conversa || typeof conversa !== 'object') return false;
        if (typeof conversa.id !== 'string' || typeof conversa.name !== 'string' || !conversa.name.trim()) return false;
        if (!['individual', 'group'].includes(conversa.type)) return false;
        return Array.isArray(conversa.messages) && Array.isArray(conversa.members);
    }

    function carregarConversas() {
        try {
            const dados = localStorage.getItem(CHAVE_CONVERSAS);
            if (!dados) {
                const exemplos = criarConversasExemplo();
                localStorage.setItem(CHAVE_CONVERSAS, JSON.stringify(exemplos));
                return exemplos;
            }

            const salvas = JSON.parse(dados);
            if (!Array.isArray(salvas)) return [];
            return salvas.filter(validarConversa).map(conversa => ({
                id: conversa.id,
                name: conversa.name.trim().slice(0, 70),
                type: conversa.type,
                members: conversa.members.filter(nome => typeof nome === 'string').slice(0, 40),
                demo: Boolean(conversa.demo),
                createdAt: conversa.createdAt || new Date().toISOString(),
                messages: conversa.messages.filter(mensagem => mensagem && typeof mensagem === 'object').map(mensagem => ({
                    id: String(mensagem.id || gerarId()),
                    sender: mensagem.sender === 'me' ? 'me' : 'other',
                    senderName: String(mensagem.senderName || 'Participante').slice(0, 70),
                    senderId: obterIdentificadorRemetente(mensagem),
                    text: String(mensagem.text || '').slice(0, 3000),
                    createdAt: mensagem.createdAt || new Date().toISOString(),
                    editedAt: typeof mensagem.editedAt === 'string' ? mensagem.editedAt : null,
                    attachments: obterAnexosMensagem(mensagem),
                    isPinned: Boolean(mensagem.isPinned),
                    isFavorite: Boolean(mensagem.isFavorite),
                    replyTo: mensagem.replyTo && typeof mensagem.replyTo === 'object' ? {
                        id: String(mensagem.replyTo.id || ''),
                        senderName: String(mensagem.replyTo.senderName || '').slice(0, 70),
                        text: String(mensagem.replyTo.text || '').slice(0, 300)
                    } : null
                }))
            }));
        } catch (erro) {
            console.error('Não foi possível carregar as conversas:', erro);
            mostrarAviso('Não foi possível ler as conversas salvas neste navegador.');
            return [];
        }
    }

    function validarAnexo(anexo) {
        if (!anexo || typeof anexo !== 'object') return null;
        if (typeof anexo.id !== 'string' || typeof anexo.name !== 'string') return null;
        return {
            id: anexo.id,
            name: anexo.name.slice(0, 180),
            type: String(anexo.type || 'application/octet-stream').slice(0, 100),
            size: Number(anexo.size) || 0
        };
    }

    function obterAnexosMensagem(mensagem) {
        const anexos = Array.isArray(mensagem.attachments)
            ? mensagem.attachments
            : mensagem.attachment ? [mensagem.attachment] : [];
        return anexos.map(validarAnexo).filter(Boolean);
    }

    function obterResumoAnexos(mensagem) {
        const anexos = obterAnexosMensagem(mensagem);
        if (anexos.length === 1) return descricaoAnexo(anexos[0]);
        return anexos.length ? `${anexos.length} arquivos anexados` : '';
    }

    function salvarConversas() {
        try {
            localStorage.setItem(CHAVE_CONVERSAS, JSON.stringify(conversas));
            return true;
        } catch (erro) {
            console.error('Não foi possível salvar as conversas:', erro);
            mostrarAviso('Não foi possível salvar. O armazenamento do navegador pode estar cheio.');
            return false;
        }
    }

    // ================================================================
    // 4. INDEXEDDB PARA GUARDAR OS ARQUIVOS COMPARTILHADOS
    // ================================================================
    function abrirBancoArquivos() {
        return new Promise((resolve, reject) => {
            if (!('indexedDB' in window)) {
                reject(new Error('Este navegador não oferece armazenamento de arquivos.'));
                return;
            }

            const pedido = window.indexedDB.open(BANCO_ANEXOS, 1);
            pedido.onupgradeneeded = () => {
                const banco = pedido.result;
                if (!banco.objectStoreNames.contains('arquivos')) {
                    banco.createObjectStore('arquivos', { keyPath: 'id' });
                }
            };
            pedido.onsuccess = () => resolve(pedido.result);
            pedido.onerror = () => reject(pedido.error || new Error('Falha ao abrir o armazenamento de arquivos.'));
        });
    }

    // Guarda um anexo e retorna seu identificador para a mensagem.
    async function armazenarAnexo(arquivo) {
        const banco = await bancoArquivos;
        if (!banco) throw new Error('O armazenamento de arquivos não está disponível neste navegador.');
        const id = gerarId();
        return new Promise((resolve, reject) => {
            const transacao = banco.transaction('arquivos', 'readwrite');
            transacao.objectStore('arquivos').put({
                id,
                blob: arquivo,
                name: arquivo.name,
                type: arquivo.type || 'application/octet-stream',
                size: arquivo.size
            });
            transacao.oncomplete = () => resolve({
                id,
                name: arquivo.name,
                type: arquivo.type || 'application/octet-stream',
                size: arquivo.size
            });
            transacao.onerror = () => reject(transacao.error || new Error('Não foi possível guardar o arquivo.'));
        });
    }

    async function buscarAnexo(id) {
        const banco = await bancoArquivos;
        if (!banco) throw new Error('O armazenamento de arquivos não está disponível neste navegador.');
        return new Promise((resolve, reject) => {
            const transacao = banco.transaction('arquivos', 'readonly');
            const pedido = transacao.objectStore('arquivos').get(id);
            pedido.onsuccess = () => resolve(pedido.result || null);
            pedido.onerror = () => reject(pedido.error || new Error('Não foi possível abrir o arquivo.'));
        });
    }

    async function excluirAnexo(id) {
        const banco = await bancoArquivos;
        if (!banco) throw new Error('O armazenamento de arquivos não está disponível neste navegador.');
        return new Promise((resolve, reject) => {
            const transacao = banco.transaction('arquivos', 'readwrite');
            transacao.objectStore('arquivos').delete(id);
            transacao.oncomplete = () => resolve();
            transacao.onerror = () => reject(transacao.error || new Error('Não foi possível excluir o arquivo.'));
        });
    }

    function formatarTamanho(bytes) {
        if (bytes < 1024) return `${bytes} B`;
        if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
        return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    }

    // ================================================================
    // 5. RENDERIZAÇÃO DA LISTA DE CONVERSAS
    // ================================================================
    function criarAvatar(nome, tipo, tamanhoGrande = false) {
        const avatar = document.createElement('div');
        avatar.className = `avatar${tipo === 'group' ? ' group-avatar' : ''}${tamanhoGrande ? ' avatar-large' : ''}`;

        if (tipo === 'group') {
            const icone = document.createElement('i');
            icone.className = 'fa-solid fa-users';
            icone.setAttribute('aria-hidden', 'true');
            avatar.append(icone);
        } else {
            avatar.textContent = iniciais(nome);
        }
        return avatar;
    }

    function renderizarConversas() {
        listaConversas.replaceChildren();
        const pesquisa = normalizarTexto(pesquisaConversas.value);

        const filtradas = conversas.filter(conversa => {
            const correspondeTipo = filtroAtual === 'all' || conversa.type === filtroAtual;
            const conteudoMensagens = conversa.messages.map(mensagem =>
                `${mensagem.text} ${mensagem.senderName} ${obterAnexosMensagem(mensagem).map(anexo => anexo.name).join(' ')}`
            ).join(' ');
            const correspondePesquisa = !pesquisa || normalizarTexto(`${conversa.name} ${conversa.members.join(' ')} ${conteudoMensagens}`).includes(pesquisa);
            return correspondeTipo && correspondePesquisa;
        }).sort((a, b) => {
            const ultimaA = a.messages.length ? new Date(a.messages[a.messages.length - 1].createdAt).getTime() : 0;
            const ultimaB = b.messages.length ? new Date(b.messages[b.messages.length - 1].createdAt).getTime() : 0;
            return ultimaB - ultimaA;
        });

        contadorConversas.textContent = `${conversas.length} ${conversas.length === 1 ? 'conversa' : 'conversas'}`;
        avisoSemConversas.hidden = filtradas.length > 0;

        filtradas.forEach(conversa => {
            const botao = document.createElement('button');
            botao.type = 'button';
            botao.className = `conversation-item${conversa.id === conversaSelecionada ? ' active' : ''}`;
            botao.setAttribute('aria-current', conversa.id === conversaSelecionada ? 'true' : 'false');
            botao.setAttribute('aria-label', `Abrir conversa ${conversa.name}`);

            botao.append(criarAvatar(conversa.name, conversa.type));

            const conteudo = document.createElement('span');
            conteudo.className = 'conversation-item-content';

            const topo = document.createElement('span');
            topo.className = 'conversation-item-top';
            const nome = document.createElement('strong');
            nome.className = 'conversation-name';
            nome.textContent = conversa.name;
            if (conversa.demo) {
                const exemplo = document.createElement('small');
                exemplo.className = 'conversation-demo';
                exemplo.textContent = 'Exemplo';
                nome.append(exemplo);
            }
            const horario = document.createElement('small');
            horario.className = 'conversation-time';
            horario.textContent = horarioLista(conversa);
            topo.append(nome, horario);

            const inferior = document.createElement('span');
            inferior.className = 'conversation-item-bottom';
            const ultimaMensagem = document.createElement('span');
            ultimaMensagem.className = 'conversation-last-message';
            ultimaMensagem.textContent = formatarUltimaMensagem(conversa);
            inferior.append(ultimaMensagem);

            conteudo.append(topo, inferior);
            botao.append(conteudo);
            botao.addEventListener('click', () => selecionarConversa(conversa.id));
            listaConversas.append(botao);
        });
    }

    // ================================================================
    // 6. RENDERIZAÇÃO DAS MENSAGENS E INFORMAÇÕES
    // ================================================================
    function criarDivisorDia(data) {
        const divisor = document.createElement('div');
        divisor.className = 'message-day-divider';
        const texto = document.createElement('span');
        texto.textContent = formatarDia(data);
        divisor.append(texto);
        return divisor;
    }

    function iconeArquivo(tipo) {
        if (tipo.startsWith('image/')) return 'fa-regular fa-file-image';
        if (tipo.includes('pdf')) return 'fa-regular fa-file-pdf';
        if (tipo.includes('word') || tipo.includes('document')) return 'fa-regular fa-file-word';
        if (tipo.includes('sheet') || tipo.includes('excel')) return 'fa-regular fa-file-excel';
        if (tipo.startsWith('video/')) return 'fa-regular fa-file-video';
        if (tipo.startsWith('audio/')) return 'fa-regular fa-file-audio';
        return 'fa-regular fa-file-lines';
    }

    function liberarAudiosDaTela() {
        urlsAudioAtivos.forEach(endereco => URL.revokeObjectURL(endereco));
        urlsAudioAtivos.clear();
    }

    function criarAnexoMensagem(anexo) {
        const ehAudio = String(anexo.type || '').startsWith('audio/');
        const cartao = document.createElement('div');
        cartao.className = ehAudio ? 'message-attachment message-audio-attachment' : 'message-attachment';

        const icone = document.createElement('i');
        icone.className = iconeArquivo(anexo.type);
        icone.setAttribute('aria-hidden', 'true');

        const informacoes = document.createElement('div');
        informacoes.className = 'message-attachment-info';
        const nome = document.createElement('strong');
        nome.textContent = anexo.name;
        const tamanho = document.createElement('span');
        tamanho.textContent = formatarTamanho(anexo.size);
        informacoes.append(nome, tamanho);

        const baixar = document.createElement('button');
        baixar.type = 'button';
        baixar.className = 'download-attachment';
        baixar.title = 'Baixar arquivo';
        baixar.setAttribute('aria-label', `Baixar ${anexo.name}`);
        baixar.innerHTML = '<i class="fa-solid fa-download" aria-hidden="true"></i>';
        baixar.addEventListener('click', () => baixarAnexo(anexo));

        if (ehAudio) {
            const player = document.createElement('audio');
            player.className = 'message-audio-source';
            player.preload = 'metadata';
            player.hidden = true;
            player.setAttribute('aria-hidden', 'true');
            player.tabIndex = -1;
            let ultimoVolumeAudio = player.volume;

            const avisoAudio = document.createElement('span');
            avisoAudio.className = 'audio-unavailable';
            avisoAudio.textContent = 'Carregando áudio...';
            avisoAudio.setAttribute('role', 'status');
            avisoAudio.setAttribute('aria-live', 'polite');

            const conteudoAudio = document.createElement('div');
            conteudoAudio.className = 'message-audio-content';

            const controlesAudio = document.createElement('div');
            controlesAudio.className = 'audio-player-controls';

            const botaoReproducao = document.createElement('button');
            botaoReproducao.className = 'audio-control-button audio-play-button';
            botaoReproducao.type = 'button';
            botaoReproducao.disabled = true;
            botaoReproducao.setAttribute('aria-label', 'Reproduzir áudio');
            botaoReproducao.title = 'Reproduzir áudio';
            botaoReproducao.innerHTML = '<i class="fa-solid fa-play" aria-hidden="true"></i>';

            const tempoAtual = document.createElement('span');
            tempoAtual.className = 'audio-time-current';
            tempoAtual.textContent = '0:00';

            const progressoAudio = document.createElement('input');
            progressoAudio.className = 'audio-range audio-progress';
            progressoAudio.type = 'range';
            progressoAudio.min = '0';
            progressoAudio.max = '1000';
            progressoAudio.value = '0';
            progressoAudio.disabled = true;
            progressoAudio.setAttribute('aria-label', `Progresso do áudio ${anexo.name}`);

            const duracaoAudio = document.createElement('span');
            duracaoAudio.className = 'audio-time-duration';
            duracaoAudio.textContent = '0:00';

            const volumeAudio = document.createElement('input');
            volumeAudio.className = 'audio-range audio-volume-slider';
            volumeAudio.type = 'range';
            volumeAudio.min = '0';
            volumeAudio.max = '1';
            volumeAudio.step = '0.01';
            volumeAudio.value = '1';
            volumeAudio.setAttribute('aria-label', `Volume do áudio ${anexo.name}`);

            const botaoVolume = document.createElement('button');
            botaoVolume.className = 'audio-control-button audio-volume-button';
            botaoVolume.type = 'button';
            botaoVolume.setAttribute('aria-label', 'Silenciar áudio');
            botaoVolume.title = 'Silenciar áudio';
            botaoVolume.innerHTML = '<i class="fa-solid fa-volume-high" aria-hidden="true"></i>';

            function formatarTempoAudio(segundos) {
                if (!Number.isFinite(segundos) || segundos < 0) return '0:00';
                const totalSegundos = Math.floor(segundos);
                const minutos = Math.floor(totalSegundos / 60);
                const segundosRestantes = String(totalSegundos % 60).padStart(2, '0');
                return minutos >= 60
                    ? `${Math.floor(minutos / 60)}:${String(minutos % 60).padStart(2, '0')}:${segundosRestantes}`
                    : `${minutos}:${segundosRestantes}`;
            }

            function atualizarProgressoAudio() {
                const duracao = player.duration;
                const valor = Number.isFinite(duracao) && duracao > 0
                    ? Math.round((player.currentTime / duracao) * 1000)
                    : 0;
                progressoAudio.value = String(valor);
                progressoAudio.style.setProperty('--range-progress', `${valor / 10}%`);
                tempoAtual.textContent = formatarTempoAudio(player.currentTime);
                duracaoAudio.textContent = formatarTempoAudio(duracao);
            }

            function atualizarBotaoReproducao() {
                const reproduzindo = !player.paused && !player.ended;
                botaoReproducao.innerHTML = `<i class="fa-solid ${reproduzindo ? 'fa-pause' : 'fa-play'}" aria-hidden="true"></i>`;
                botaoReproducao.setAttribute('aria-label', reproduzindo ? 'Pausar áudio' : 'Reproduzir áudio');
                botaoReproducao.title = reproduzindo ? 'Pausar áudio' : 'Reproduzir áudio';
            }

            function atualizarControlesVolume() {
                const volumeAtual = player.muted ? 0 : player.volume;
                volumeAudio.value = String(volumeAtual);
                volumeAudio.style.setProperty('--range-progress', `${volumeAtual * 100}%`);
                const silencioso = volumeAtual === 0;
                const iconeVolume = silencioso
                    ? 'fa-volume-xmark'
                    : player.volume < 0.5 ? 'fa-volume-low' : 'fa-volume-high';
                botaoVolume.innerHTML = `<i class="fa-solid ${iconeVolume}" aria-hidden="true"></i>`;
                botaoVolume.setAttribute('aria-label', silencioso ? 'Ativar áudio' : 'Silenciar áudio');
                botaoVolume.title = silencioso ? 'Ativar áudio' : 'Silenciar áudio';
            }

            function mostrarErroAudio() {
                avisoAudio.textContent = 'Não foi possível carregar ou reproduzir este áudio.';
                avisoAudio.hidden = false;
                botaoReproducao.disabled = true;
                progressoAudio.disabled = true;
            }

            botaoReproducao.addEventListener('click', () => {
                if (player.paused) {
                    player.play().catch(erro => {
                        console.warn('Não foi possível reproduzir o áudio:', erro);
                        mostrarErroAudio();
                    });
                } else {
                    player.pause();
                }
            });
            progressoAudio.addEventListener('input', () => {
                if (Number.isFinite(player.duration)) {
                    player.currentTime = (Number(progressoAudio.value) / 1000) * player.duration;
                    atualizarProgressoAudio();
                }
            });
            volumeAudio.addEventListener('input', () => {
                const volume = Number(volumeAudio.value);
                if (volume > 0) ultimoVolumeAudio = volume;
                player.volume = volume;
                player.muted = volume === 0;
                atualizarControlesVolume();
            });
            botaoVolume.addEventListener('click', () => {
                if (player.muted || player.volume === 0) {
                    player.muted = false;
                    player.volume = ultimoVolumeAudio > 0 ? ultimoVolumeAudio : 1;
                } else {
                    ultimoVolumeAudio = player.volume;
                    player.muted = true;
                }
                atualizarControlesVolume();
            });

            player.addEventListener('loadedmetadata', () => {
                avisoAudio.hidden = true;
                botaoReproducao.disabled = false;
                progressoAudio.disabled = !Number.isFinite(player.duration) || player.duration <= 0;
                atualizarProgressoAudio();
            });
            player.addEventListener('timeupdate', atualizarProgressoAudio);
            player.addEventListener('durationchange', atualizarProgressoAudio);
            player.addEventListener('play', atualizarBotaoReproducao);
            player.addEventListener('pause', atualizarBotaoReproducao);
            player.addEventListener('ended', atualizarBotaoReproducao);
            player.addEventListener('volumechange', atualizarControlesVolume);
            player.addEventListener('error', mostrarErroAudio);

            conteudoAudio.append(informacoes, avisoAudio);
            controlesAudio.append(botaoReproducao, tempoAtual, progressoAudio, duracaoAudio, volumeAudio, botaoVolume);
            cartao.append(icone, conteudoAudio, controlesAudio, baixar, player);
            atualizarControlesVolume();

            buscarAnexo(anexo.id).then(registro => {
                if (!player.isConnected) return;
                if (!registro || !registro.blob) {
                    avisoAudio.textContent = 'Áudio não disponível neste navegador.';
                    return;
                }
                const endereco = URL.createObjectURL(registro.blob);
                urlsAudioAtivos.add(endereco);
                player.src = endereco;
                avisoAudio.hidden = true;
            }).catch(erro => {
                console.warn('Não foi possível carregar o áudio:', erro);
                if (player.isConnected) avisoAudio.textContent = 'Não foi possível carregar este áudio.';
            });
            return cartao;
        }

        cartao.append(icone, informacoes, baixar);
        return cartao;
    }

    function criarBotaoFerramenta(classe, icone, texto, titulo, aoClicar, ativo = false) {
        const botao = document.createElement('button');
        botao.type = 'button';
        botao.className = `message-tool-button${classe ? ` ${classe}` : ''}${ativo ? ' is-active' : ''}`;
        botao.title = titulo;
        botao.setAttribute('aria-label', titulo);
        if (classe.includes('toggle-action')) botao.setAttribute('aria-pressed', String(ativo));
        botao.innerHTML = `<i class="${icone}" aria-hidden="true"></i> ${texto}`;
        botao.addEventListener('click', aoClicar);
        return botao;
    }

    function renderizarTextoComMencoes(elemento, texto, conversa) {
        if (conversa.type !== 'group' || !conversa.members.length) {
            elemento.textContent = texto;
            return;
        }

        const termos = ['todos', ...conversa.members
            .filter(nome => typeof nome === 'string' && nome.trim())
            .map(nome => nome.trim())]
            .filter((nome, indice, lista) => lista.findIndex(item =>
                item.toLocaleLowerCase('pt-BR') === nome.toLocaleLowerCase('pt-BR')
            ) === indice)
            .sort((a, b) => b.length - a.length)
            .map(nome => nome.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
        const limitePalavra = 'A-Za-z0-9À-ÖØ-öø-ÿ_';
        const padrao = new RegExp(
            `(^|[^${limitePalavra}@])(@(?:${termos.join('|')}))(?=$|[^${limitePalavra}])`,
            'gi'
        );
        const fragmento = document.createDocumentFragment();
        let posicao = 0;
        let correspondencia;

        while ((correspondencia = padrao.exec(texto)) !== null) {
            const inicioMencao = correspondencia.index + correspondencia[1].length;
            const fimMencao = inicioMencao + correspondencia[2].length;
            fragmento.append(document.createTextNode(texto.slice(posicao, inicioMencao)));

            const mencao = document.createElement('span');
            mencao.className = 'message-mention';
            mencao.textContent = correspondencia[2];
            fragmento.append(mencao);
            posicao = fimMencao;
        }

        fragmento.append(document.createTextNode(texto.slice(posicao)));
        elemento.append(fragmento);
    }

    function criarMensagem(mensagem, conversa) {
        const propria = mensagem.senderId === ID_USUARIO_ATUAL;
        const linha = document.createElement('article');
        linha.className = `message-row${propria ? ' own-message' : ''}${mensagem.isPinned ? ' is-pinned' : ''}${mensagem.isFavorite ? ' is-favorite' : ''}`;
        linha.style.setProperty('--sender-hue', String(obterMatizRemetente(mensagem.senderId)));
        linha.dataset.messageId = mensagem.id;

        if (!propria) {
            const avatar = document.createElement('div');
            avatar.className = 'message-avatar-small';
            avatar.textContent = iniciais(mensagem.senderName);
            linha.append(avatar);
        }

        const conteudo = document.createElement('div');
        conteudo.className = 'message-content';
        const anexos = obterAnexosMensagem(mensagem);
        if (anexos.some(anexo => String(anexo.type || '').startsWith('audio/'))) {
            conteudo.classList.add('has-audio-attachment');
        }

        if (conversa.type === 'group') {
            const remetente = document.createElement('span');
            remetente.className = 'message-sender';
            remetente.textContent = propria ? `${mensagem.senderName} (Você)` : mensagem.senderName;
            conteudo.append(remetente);
        }

        const balao = document.createElement('div');
        balao.className = 'message-bubble';

        if (mensagem.replyTo) {
            const citacao = document.createElement('div');
            citacao.className = 'message-reply-quote';
            const nomeCitacao = document.createElement('strong');
            nomeCitacao.textContent = mensagem.replyTo.senderName;
            const textoCitacao = document.createElement('span');
            textoCitacao.textContent = mensagem.replyTo.text || 'Arquivo compartilhado';
            citacao.append(nomeCitacao, textoCitacao);
            balao.append(citacao);
        }

        if (mensagem.text && propria && mensagemEmEdicaoId === mensagem.id) {
            const editor = document.createElement('div');
            editor.className = 'message-edit-form';

            const campoEdicao = document.createElement('textarea');
            campoEdicao.className = 'message-edit-input';
            campoEdicao.maxLength = 3000;
            campoEdicao.setAttribute('aria-label', 'Editar mensagem');
            campoEdicao.value = mensagem.text;

            const acoesEdicao = document.createElement('div');
            acoesEdicao.className = 'message-edit-actions';

            const salvarEdicao = document.createElement('button');
            salvarEdicao.type = 'button';
            salvarEdicao.className = 'message-edit-button save-message-edit';
            salvarEdicao.textContent = 'Salvar';
            salvarEdicao.addEventListener('click', () => salvarEdicaoMensagem(mensagem.id, campoEdicao.value));

            const cancelarEdicao = document.createElement('button');
            cancelarEdicao.type = 'button';
            cancelarEdicao.className = 'message-edit-button cancel-message-edit';
            cancelarEdicao.textContent = 'Cancelar';
            cancelarEdicao.addEventListener('click', cancelarEdicaoMensagem);

            acoesEdicao.append(cancelarEdicao, salvarEdicao);
            editor.append(campoEdicao, acoesEdicao);
            balao.append(editor);
        } else if (mensagem.text) {
            const texto = document.createElement('div');
            renderizarTextoComMencoes(texto, mensagem.text, conversa);
            balao.append(texto);
        }

        anexos.forEach(anexo => balao.append(criarAnexoMensagem(anexo)));

        const meta = document.createElement('div');
        meta.className = 'message-meta';
        const horario = document.createElement('span');
        horario.textContent = formatarHorario(mensagem.createdAt);
        meta.append(horario);
        if (mensagem.editedAt) {
            const editada = document.createElement('span');
            editada.className = 'message-edited';
            editada.textContent = 'editada';
            meta.append(editada);
        }
        if (mensagem.isPinned) {
            const iconeFixada = document.createElement('i');
            iconeFixada.className = 'fa-solid fa-thumbtack';
            iconeFixada.title = 'Mensagem fixada';
            meta.append(iconeFixada);
        }
        if (mensagem.isFavorite) {
            const iconeFavorita = document.createElement('i');
            iconeFavorita.className = 'fa-solid fa-star';
            iconeFavorita.title = 'Mensagem favoritada';
            meta.append(iconeFavorita);
        }
        if (propria) {
            const confirmacao = document.createElement('i');
            confirmacao.className = 'fa-solid fa-check-double';
            confirmacao.setAttribute('aria-label', 'Salva neste navegador');
            meta.append(confirmacao);
        }
        balao.append(meta);
        conteudo.append(balao);

        const ferramentas = document.createElement('div');
        ferramentas.className = 'message-tools';
        if (propria && mensagemPodeSerEditada(mensagem)) {
            ferramentas.append(criarBotaoFerramenta(
                'edit-message', 'fa-regular fa-pen-to-square', 'Editar', 'Editar mensagem',
                () => iniciarEdicaoMensagem(mensagem.id)
            ));
        }
        ferramentas.append(
            criarBotaoFerramenta('', 'fa-solid fa-reply', 'Responder', 'Responder mensagem', () => prepararResposta(mensagem)),
            criarBotaoFerramenta('', 'fa-regular fa-copy', 'Copiar', 'Copiar mensagem', () => copiarMensagem(mensagem)),
            criarBotaoFerramenta(
                'toggle-action', mensagem.isFavorite ? 'fa-solid fa-star' : 'fa-regular fa-star',
                mensagem.isFavorite ? 'Desfavoritar' : 'Favoritar',
                mensagem.isFavorite ? 'Remover dos favoritos' : 'Adicionar aos favoritos',
                () => alternarMarcacaoMensagem(mensagem.id, 'isFavorite'), mensagem.isFavorite
            ),
            criarBotaoFerramenta(
                'toggle-action', 'fa-solid fa-thumbtack', mensagem.isPinned ? 'Desfixar' : 'Fixar',
                mensagem.isPinned ? 'Desafixar mensagem' : 'Fixar mensagem',
                () => alternarMarcacaoMensagem(mensagem.id, 'isPinned'), mensagem.isPinned
            ),
            criarBotaoFerramenta('delete-message', 'fa-regular fa-trash-can', 'Apagar', 'Apagar mensagem', () => excluirMensagem(mensagem.id))
        );
        conteudo.append(ferramentas);

        linha.append(conteudo);
        return linha;
    }

    function renderizarMensagensFixadas(conversa) {
        listaFixadas.replaceChildren();
        const fixadas = conversa.messages
            .filter(mensagem => mensagem.isPinned)
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        painelFixadas.hidden = fixadas.length === 0;
        contadorFixadas.textContent = String(fixadas.length);

        fixadas.forEach(mensagem => {
            const botao = document.createElement('button');
            botao.type = 'button';
            botao.className = 'pinned-message-chip';
            const icone = document.createElement('i');
            icone.className = 'fa-solid fa-thumbtack';
            const texto = document.createElement('span');
            const resumo = mensagem.text || obterResumoAnexos(mensagem) || 'Mensagem';
            texto.textContent = `${mensagem.senderName}: ${resumo}`;
            botao.append(icone, texto);
            botao.title = texto.textContent;
            botao.addEventListener('click', () => localizarMensagem(mensagem.id));
            listaFixadas.append(botao);
        });
    }

    function atualizarFiltroMensagens(conversa) {
        const favoritas = conversa ? conversa.messages.filter(mensagem => mensagem.isFavorite).length : 0;
        contadorFavoritas.textContent = String(favoritas);
        botoesFiltroMensagens.forEach(botao => {
            const ativo = botao.dataset.messageFilter === filtroMensagens;
            botao.classList.toggle('active', ativo);
            botao.setAttribute('aria-pressed', String(ativo));
        });
    }

    function localizarMensagem(id) {
        let linha = Array.from(areaMensagens.querySelectorAll('[data-message-id]'))
            .find(elemento => elemento.dataset.messageId === id);

        // Uma mensagem fixada pode não ser favorita. Nesse caso, abre a visualização completa.
        if (!linha && conversaAtual()?.messages.some(mensagem => mensagem.id === id)) {
            filtroMensagens = 'all';
            renderizarMensagens();
            linha = Array.from(areaMensagens.querySelectorAll('[data-message-id]'))
                .find(elemento => elemento.dataset.messageId === id);
        }

        if (!linha) {
            mostrarAviso('Não foi possível localizar esta mensagem.');
            return;
        }
        linha.scrollIntoView({ behavior: 'smooth', block: 'center' });
        linha.classList.add('message-highlight');
        window.setTimeout(() => linha.classList.remove('message-highlight'), 1300);
    }

    async function copiarMensagem(mensagem) {
        const conteudo = [
            mensagem.text,
            obterAnexosMensagem(mensagem).map(descricaoAnexo).join('\n')
        ].filter(Boolean).join('\n');

        if (!conteudo) {
            mostrarAviso('Esta mensagem não possui conteúdo para copiar.');
            return;
        }

        try {
            if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
                await navigator.clipboard.writeText(conteudo);
            } else {
                throw new Error('Área de transferência indisponível.');
            }
            mostrarAviso('Mensagem copiada.');
        } catch (erro) {
            const campoTemporario = document.createElement('textarea');
            campoTemporario.value = conteudo;
            campoTemporario.setAttribute('readonly', '');
            campoTemporario.style.position = 'fixed';
            campoTemporario.style.opacity = '0';
            document.body.append(campoTemporario);
            campoTemporario.select();
            let copiou = false;
            try {
                copiou = document.execCommand('copy');
            } catch (erroCopia) {
                console.warn('Não foi possível copiar a mensagem:', erroCopia);
            }
            campoTemporario.remove();
            mostrarAviso(copiou ? 'Mensagem copiada.' : 'Não foi possível copiar. Verifique a permissão do navegador.');
        }
    }

    function alternarMarcacaoMensagem(idMensagem, propriedade) {
        const conversa = conversaAtual();
        if (!conversa || !['isPinned', 'isFavorite'].includes(propriedade)) return;
        const mensagem = conversa.messages.find(item => item.id === idMensagem);
        if (!mensagem) return;

        const estadoAnterior = mensagem[propriedade];
        mensagem[propriedade] = !estadoAnterior;
        if (!salvarConversas()) {
            mensagem[propriedade] = estadoAnterior;
            return;
        }

        // Se a mensagem deixar de ser favorita, volta para Todas para não ocultá-la logo após a ação.
        if (propriedade === 'isFavorite' && !mensagem.isFavorite && filtroMensagens === 'favorites') {
            filtroMensagens = 'all';
        }

        renderizarMensagens();
        renderizarConversas();
        localizarMensagem(idMensagem);
        if (propriedade === 'isPinned') {
            mostrarAviso(mensagem.isPinned ? 'Mensagem fixada nesta conversa.' : 'Mensagem desafixada.');
        } else {
            mostrarAviso(mensagem.isFavorite ? 'Mensagem adicionada aos favoritos.' : 'Mensagem removida dos favoritos.');
        }
    }

    function iniciarEdicaoMensagem(idMensagem) {
        const conversa = conversaAtual();
        const mensagem = conversa?.messages.find(item => item.id === idMensagem);
        if (!mensagem || !mensagemPodeSerEditada(mensagem)) {
            mostrarAviso('Só é possível editar suas mensagens nos primeiros 15 minutos após o envio.');
            return;
        }

        mensagemEmEdicaoId = idMensagem;
        renderizarMensagens();
        const campoEdicao = areaMensagens.querySelector('.message-edit-input');
        campoEdicao?.focus();
        campoEdicao?.select();
    }

    function cancelarEdicaoMensagem() {
        mensagemEmEdicaoId = null;
        renderizarMensagens();
    }

    function salvarEdicaoMensagem(idMensagem, texto) {
        const conversa = conversaAtual();
        const mensagem = conversa?.messages.find(item => item.id === idMensagem);
        if (!mensagem || !mensagemPodeSerEditada(mensagem)) {
            mensagemEmEdicaoId = null;
            renderizarMensagens();
            mostrarAviso('O prazo de 15 minutos para editar esta mensagem terminou.');
            return;
        }

        const novoTexto = texto.trim();
        if (!novoTexto) {
            mostrarAviso('A mensagem não pode ficar vazia.');
            return;
        }
        if (novoTexto.length > 3000) {
            mostrarAviso('A mensagem pode ter no máximo 3000 caracteres.');
            return;
        }
        if (novoTexto === mensagem.text) {
            cancelarEdicaoMensagem();
            return;
        }

        const textoAnterior = mensagem.text;
        const edicaoAnterior = mensagem.editedAt;
        mensagem.text = novoTexto;
        mensagem.editedAt = new Date().toISOString();
        if (!salvarConversas()) {
            mensagem.text = textoAnterior;
            mensagem.editedAt = edicaoAnterior;
            return;
        }

        mensagemEmEdicaoId = null;
        renderizarMensagens();
        renderizarConversas();
        mostrarAviso('Mensagem editada.');
    }

    async function excluirMensagem(idMensagem) {
        const conversa = conversaAtual();
        if (!conversa) return;
        const mensagem = conversa.messages.find(item => item.id === idMensagem);
        if (!mensagem) return;

        const resumo = mensagem.text || obterResumoAnexos(mensagem) || 'esta mensagem';
        if (!window.confirm(`Deseja apagar a mensagem "${resumo.slice(0, 90)}" desta conversa?`)) return;

        const mensagensAnteriores = conversa.messages;
        conversa.messages = conversa.messages.filter(item => item.id !== idMensagem);
        if (!salvarConversas()) {
            conversa.messages = mensagensAnteriores;
            return;
        }

        obterAnexosMensagem(mensagem).forEach(anexo => {
            excluirAnexo(anexo.id).catch(erro => {
                console.warn('Não foi possível remover o arquivo da mensagem apagada:', erro);
            });
        });
        if (respostaSelecionada && respostaSelecionada.id === idMensagem) esconderPreviewResposta();

        renderizarMensagens();
        renderizarConversas();
        mostrarAviso('Mensagem apagada desta conversa.');
    }

    function renderizarMensagens() {
        const conversa = conversaAtual();
        liberarAudiosDaTela();
        areaMensagens.replaceChildren();
        if (!conversa) {
            painelFixadas.hidden = true;
            return;
        }

        renderizarMensagensFixadas(conversa);
        atualizarFiltroMensagens(conversa);

        const mensagensExibidas = filtroMensagens === 'favorites'
            ? conversa.messages.filter(mensagem => mensagem.isFavorite)
            : conversa.messages;

        let diaAnterior = '';
        mensagensExibidas.forEach(mensagem => {
            const data = new Date(mensagem.createdAt);
            const dia = Number.isNaN(data.getTime()) ? '' : data.toDateString();
            if (dia !== diaAnterior) {
                areaMensagens.append(criarDivisorDia(mensagem.createdAt));
                diaAnterior = dia;
            }
            areaMensagens.append(criarMensagem(mensagem, conversa));
        });

        if (!mensagensExibidas.length) {
            const vazio = document.createElement('div');
            vazio.className = 'message-empty-filter';
            vazio.textContent = filtroMensagens === 'favorites'
                ? 'Nenhuma mensagem favoritada nesta conversa.'
                : 'Conversa iniciada. Envie a primeira mensagem para começar.';
            areaMensagens.append(vazio);
        }

        areaMensagens.scrollTop = areaMensagens.scrollHeight;
    }

    function renderizarInformacoes() {
        const conversa = conversaAtual();
        listaParticipantes.replaceChildren();
        if (!conversa) return;

        conversa.members.forEach(membro => {
            const participante = document.createElement('span');
            participante.className = 'participant-chip';
            participante.textContent = membro === USUARIO_ATUAL ? `${membro} (Você)` : membro;
            listaParticipantes.append(participante);
        });
        subtituloAtivo.textContent = conversa.type === 'group'
            ? `${conversa.members.length} participantes`
            : 'Conversa individual';
    }

    function renderizarConversaAtiva() {
        const conversa = conversaAtual();
        const existe = Boolean(conversa);
        estadoVazio.hidden = existe;
        conversaAtiva.hidden = !existe;
        if (!conversa) {
            areaChat.classList.remove('mobile-chat-open');
            return;
        }

        nomeAtivo.textContent = conversa.name;
        const avatarAtual = document.getElementById('active-avatar');
        if (avatarAtual) {
            const novoAvatar = criarAvatar(conversa.name, conversa.type, true);
            novoAvatar.id = 'active-avatar';
            avatarAtual.replaceWith(novoAvatar);
        }
        renderizarInformacoes();
        renderizarMensagens();
    }

    function selecionarConversa(id) {
        cancelarGravacaoAudio();
        conversaSelecionada = id;
        filtroMensagens = 'all';
        respostaSelecionada = null;
        esconderPreviewResposta();
        painelInfo.hidden = true;
        document.getElementById('toggle-conversation-info').setAttribute('aria-expanded', 'false');
        renderizarConversas();
        renderizarConversaAtiva();
        areaChat.classList.add('mobile-chat-open');
        campoMensagem.focus();
    }

    // ================================================================
    // 7. RESPOSTAS E ENVIO DE MENSAGENS
    // ================================================================
    function prepararResposta(mensagem) {
        respostaSelecionada = {
            id: mensagem.id,
            senderName: mensagem.senderName,
            text: mensagem.text || obterResumoAnexos(mensagem)
        };
        nomeResposta.textContent = mensagem.senderName;
        textoResposta.textContent = respostaSelecionada.text || 'Arquivo compartilhado';
        previewResposta.hidden = false;
        campoMensagem.focus();
    }

    function esconderPreviewResposta() {
        respostaSelecionada = null;
        previewResposta.hidden = true;
    }

    function mostrarPreviewAnexo() {
        previewAnexo.hidden = arquivosSelecionados.length === 0;
        const lista = document.getElementById('attachment-preview-list');
        lista.replaceChildren();

        arquivosSelecionados.forEach((arquivo, indice) => {
            const linha = document.createElement('div');
            linha.className = 'attachment-preview-item';

            const icone = document.createElement('i');
            const ehAudio = String(arquivo.type || '').startsWith('audio/');
            icone.className = ehAudio ? 'fa-solid fa-file-audio' : 'fa-solid fa-paperclip';
            icone.setAttribute('aria-hidden', 'true');

            const nome = document.createElement('span');
            nome.textContent = `${arquivo.name} (${formatarTamanho(arquivo.size)})`;

            const remover = document.createElement('button');
            remover.type = 'button';
            remover.className = 'icon-button attachment-preview-remove';
            remover.dataset.index = String(indice);
            remover.setAttribute('aria-label', `Remover ${arquivo.name}`);
            remover.title = `Remover ${arquivo.name}`;
            remover.innerHTML = '<i class="fa-solid fa-xmark" aria-hidden="true"></i>';

            linha.append(icone, nome, remover);
            lista.append(linha);
        });
    }

    function limparAnexoSelecionado() {
        arquivosSelecionados = [];
        campoArquivo.value = '';
        mostrarPreviewAnexo();
    }

    function formatarDuracaoGravacao(segundos) {
        const minutos = String(Math.floor(segundos / 60)).padStart(2, '0');
        const restante = String(segundos % 60).padStart(2, '0');
        return `${minutos}:${restante}`;
    }

    function atualizarIndicadorGravacao() {
        if (!inicioGravacao) return;
        const segundos = Math.floor((Date.now() - inicioGravacao) / 1000);
        textoStatusGravacao.textContent = `Gravando áudio · ${formatarDuracaoGravacao(segundos)} · toque no botão para finalizar`;
    }

    function atualizarBotaoGravacao(gravando) {
        botaoGravarAudio.classList.toggle('is-recording', gravando);
        botaoGravarAudio.setAttribute('aria-pressed', String(gravando));
        botaoGravarAudio.setAttribute('aria-label', gravando ? 'Finalizar gravação de áudio' : 'Gravar áudio');
        botaoGravarAudio.title = gravando ? 'Finalizar gravação' : 'Gravar áudio';
        iconeGravarAudio.className = gravando ? 'fa-solid fa-stop' : 'fa-solid fa-microphone';
        statusGravacao.hidden = !gravando;
        botaoAnexo.disabled = gravando;
    }

    async function iniciarGravacaoAudio() {
        if (arquivosSelecionados.length) {
            mostrarAviso('Remova o arquivo selecionado antes de gravar um áudio.');
            return;
        }
        if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function' || typeof window.MediaRecorder !== 'function') {
            mostrarAviso('A gravação não está disponível. Abra o site em HTTPS ou localhost e use um navegador compatível.');
            return;
        }

        botaoGravarAudio.disabled = true;
        try {
            fluxoMicrofone = await navigator.mediaDevices.getUserMedia({ audio: true });
            const formatos = ['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/mp4'];
            const formatoSuportado = typeof window.MediaRecorder.isTypeSupported === 'function'
                ? formatos.find(formato => window.MediaRecorder.isTypeSupported(formato))
                : '';
            gravadorAudio = formatoSuportado
                ? new window.MediaRecorder(fluxoMicrofone, { mimeType: formatoSuportado })
                : new window.MediaRecorder(fluxoMicrofone);
            partesAudio = [];
            descartarGravacao = false;

            const gravadorAtual = gravadorAudio;
            gravadorAtual.addEventListener('dataavailable', evento => {
                if (evento.data && evento.data.size > 0) partesAudio.push(evento.data);
            });
            gravadorAtual.addEventListener('error', evento => {
                console.error('Erro durante a gravação:', evento.error);
                mostrarAviso('Ocorreu um erro durante a gravação do áudio.');
            });
            gravadorAtual.addEventListener('stop', () => {
                fluxoMicrofone?.getTracks().forEach(faixa => faixa.stop());
                fluxoMicrofone = null;
                if (temporizadorGravacao) clearInterval(temporizadorGravacao);
                temporizadorGravacao = null;
                inicioGravacao = 0;
                atualizarBotaoGravacao(false);

                const descartar = descartarGravacao;
                descartarGravacao = false;
                if (gravadorAudio === gravadorAtual) gravadorAudio = null;
                if (descartar) {
                    partesAudio = [];
                    return;
                }

                const tipoAudio = gravadorAtual.mimeType || (partesAudio[0] && partesAudio[0].type) || 'audio/webm';
                const blobAudio = new Blob(partesAudio, { type: tipoAudio });
                partesAudio = [];
                if (!blobAudio.size) {
                    mostrarAviso('Nenhum áudio foi capturado. Tente gravar novamente.');
                    return;
                }
                if (blobAudio.size > LIMITE_ANEXO) {
                    mostrarAviso('O áudio ultrapassou o limite de 5 MB. Grave uma mensagem mais curta.');
                    return;
                }

                const extensao = tipoAudio.includes('ogg') ? 'ogg' : (tipoAudio.includes('mp4') ? 'm4a' : 'webm');
                arquivosSelecionados = [new File([blobAudio], `mensagem-de-audio-${Date.now()}.${extensao}`, { type: tipoAudio })];
                mostrarPreviewAnexo();
                mostrarAviso('Áudio gravado. Clique em enviar para compartilhar.');
            });

            gravadorAtual.start();
            inicioGravacao = Date.now();
            atualizarBotaoGravacao(true);
            atualizarIndicadorGravacao();
            temporizadorGravacao = setInterval(atualizarIndicadorGravacao, 1000);
        } catch (erro) {
            console.error('Não foi possível acessar o microfone:', erro);
            fluxoMicrofone?.getTracks().forEach(faixa => faixa.stop());
            fluxoMicrofone = null;
            gravadorAudio = null;
            atualizarBotaoGravacao(false);
            if (erro && (erro.name === 'NotAllowedError' || erro.name === 'PermissionDeniedError')) {
                mostrarAviso('Permita o acesso ao microfone nas configurações do navegador para gravar áudio.');
            } else {
                mostrarAviso('Não foi possível iniciar a gravação de áudio neste dispositivo.');
            }
        } finally {
            botaoGravarAudio.disabled = false;
        }
    }

    function alternarGravacaoAudio() {
        if (gravadorAudio && gravadorAudio.state === 'recording') {
            gravadorAudio.stop();
            return;
        }
        iniciarGravacaoAudio();
    }

    function cancelarGravacaoAudio() {
        if (!gravadorAudio || gravadorAudio.state !== 'recording') return;
        descartarGravacao = true;
        gravadorAudio.stop();
    }

    async function enviarMensagem(evento) {
        evento.preventDefault();
        const conversa = conversaAtual();
        const texto = campoMensagem.value.trim();
        if (!conversa) return;
        if (gravadorAudio && gravadorAudio.state === 'recording') {
            mostrarAviso('Finalize a gravação antes de enviar a mensagem.');
            return;
        }
        if (!texto && !arquivosSelecionados.length) {
            campoMensagem.focus();
            return;
        }

        const botaoEnviar = document.getElementById('send-message');
        botaoEnviar.disabled = true;
        const anexosSalvos = [];

        try {
            for (const arquivo of arquivosSelecionados) {
                anexosSalvos.push(await armazenarAnexo(arquivo));
            }

            const mensagem = {
                id: gerarId(),
                sender: 'me',
                senderId: ID_USUARIO_ATUAL,
                senderName: USUARIO_ATUAL,
                text: texto,
                createdAt: new Date().toISOString(),
                attachments: anexosSalvos,
                isPinned: false,
                isFavorite: false,
                replyTo: respostaSelecionada
            };

            conversa.messages.push(mensagem);
            conversa.demo = false;

            if (!salvarConversas()) {
                conversa.messages.pop();
                await Promise.all(anexosSalvos.map(anexo =>
                    excluirAnexo(anexo.id).catch(erro => {
                        console.warn('Não foi possível limpar um arquivo de uma mensagem não salva:', erro);
                    })
                ));
                return;
            }

            campoMensagem.value = '';
            ajustarAlturaMensagem();
            esconderPreviewResposta();
            limparAnexoSelecionado();
            renderizarConversas();
            renderizarMensagens();
            campoMensagem.focus();
        } catch (erro) {
            await Promise.all(anexosSalvos.map(anexo =>
                excluirAnexo(anexo.id).catch(erroRemocao => {
                    console.warn('Não foi possível limpar um arquivo de uma mensagem não enviada:', erroRemocao);
                })
            ));
            console.error('Não foi possível enviar a mensagem:', erro);
            mostrarAviso(erro.message || 'Não foi possível enviar a mensagem.');
        } finally {
            botaoEnviar.disabled = false;
        }
    }

    function ajustarAlturaMensagem() {
        campoMensagem.style.height = 'auto';
        campoMensagem.style.height = `${Math.min(campoMensagem.scrollHeight, 112)}px`;
    }

    async function baixarAnexo(anexo) {
        try {
            const registro = await buscarAnexo(anexo.id);
            if (!registro || !registro.blob) {
                mostrarAviso('O arquivo não está mais disponível neste navegador.');
                return;
            }

            const endereco = URL.createObjectURL(registro.blob);
            const link = document.createElement('a');
            link.href = endereco;
            link.download = registro.name || anexo.name;
            document.body.append(link);
            link.click();
            link.remove();
            setTimeout(() => URL.revokeObjectURL(endereco), 1000);
        } catch (erro) {
            console.error('Não foi possível baixar o anexo:', erro);
            mostrarAviso('Não foi possível baixar este arquivo.');
        }
    }

    // ================================================================
    // 8. CRIAÇÃO E EXCLUSÃO DE CONVERSAS
    // ================================================================
    function abrirModalNovaConversa() {
        formularioNovaConversa.reset();
        atualizarCamposTipoConversa();
        modalNovaConversa.hidden = false;
        document.body.classList.add('modal-open');
        campoNomeConversa.focus();
    }

    function fecharModalNovaConversa() {
        modalNovaConversa.hidden = true;
        document.body.classList.remove('modal-open');
    }

    function atualizarCamposTipoConversa() {
        const grupo = tipoConversa.value === 'group';
        campoMembrosContainer.hidden = !grupo;
        labelNomeConversa.textContent = grupo ? 'Nome do grupo' : 'Nome da pessoa';
        campoNomeConversa.placeholder = grupo ? 'Ex.: Desenvolvimento do TeamWave' : 'Ex.: Ana Souza';
    }

    function criarConversa(evento) {
        evento.preventDefault();
        const tipo = tipoConversa.value;
        const nome = campoNomeConversa.value.trim();
        if (!nome) {
            campoNomeConversa.focus();
            return;
        }

        const membrosDigitados = campoMembros.value.split(',').map(nomeMembro => nomeMembro.trim()).filter(Boolean);
        const membros = Array.from(new Set([USUARIO_ATUAL, ...(tipo === 'group' ? membrosDigitados : [nome])]));
        if (tipo === 'individual' && normalizarTexto(nome) === normalizarTexto(USUARIO_ATUAL)) {
            mostrarAviso('Digite o nome de outra pessoa para iniciar uma conversa individual.');
            return;
        }

        // Evita criar duas conversas individuais com o mesmo contato.
        if (tipo === 'individual') {
            const existente = conversas.find(conversa => conversa.type === 'individual' && normalizarTexto(conversa.name) === normalizarTexto(nome));
            if (existente) {
                fecharModalNovaConversa();
                selecionarConversa(existente.id);
                mostrarAviso('Essa conversa já existe.');
                return;
            }
        }

        const nova = {
            id: gerarId(),
            name: nome,
            type: tipo,
            members: membros.slice(0, 40),
            demo: false,
            createdAt: new Date().toISOString(),
            messages: []
        };

        conversas.unshift(nova);
        if (!salvarConversas()) {
            conversas.shift();
            return;
        }

        fecharModalNovaConversa();
        pesquisaConversas.value = '';
        pesquisaGeral.value = '';
        filtroAtual = 'all';
        atualizarBotoesFiltro();
        selecionarConversa(nova.id);
        mostrarAviso('Conversa criada com sucesso.');
    }

    function excluirConversaAtual() {
        const conversa = conversaAtual();
        if (!conversa) return;
        const confirmar = window.confirm(`Deseja excluir a conversa "${conversa.name}" deste navegador?`);
        if (!confirmar) return;

        const conversasAnteriores = conversas;
        conversas = conversas.filter(item => item.id !== conversa.id);
        if (!salvarConversas()) {
            conversas = conversasAnteriores;
            return;
        }

        conversa.messages.forEach(mensagem => {
            obterAnexosMensagem(mensagem).forEach(anexo => {
                excluirAnexo(anexo.id).catch(erro => {
                    console.warn('Não foi possível remover um arquivo da conversa excluída:', erro);
                });
            });
        });

        conversaSelecionada = conversas.length ? conversas[0].id : null;
        esconderPreviewResposta();
        painelInfo.hidden = true;
        renderizarConversas();
        renderizarConversaAtiva();
        mostrarAviso('Conversa excluída deste navegador.');
    }

    // ================================================================
    // 9. FILTROS, PESQUISA E SINCRONIZAÇÃO ENTRE ABAS
    // ================================================================
    function atualizarBotoesFiltro() {
        botoesFiltro.forEach(botao => {
            const ativo = botao.dataset.filter === filtroAtual;
            botao.classList.toggle('active', ativo);
            botao.setAttribute('aria-pressed', String(ativo));
        });
    }

    function aplicarPesquisa(valor, origem) {
        pesquisaConversas.value = valor;
        pesquisaGeral.value = valor;
        renderizarConversas();
        if (origem === 'global' && conversaSelecionada) {
            const termo = normalizarTexto(valor);
            const conversa = conversaAtual();
            if (termo && conversa) {
                const conversaCorresponde = normalizarTexto(`${conversa.name} ${conversa.members.join(' ')} ${conversa.messages.map(mensagem => mensagem.text).join(' ')}`).includes(termo);
                if (!conversaCorresponde) areaMensagens.scrollTop = 0;
            }
        }
    }

    window.addEventListener('storage', evento => {
        if (evento.key === CHAVE_CONVERSAS) {
            conversas = carregarConversas();
            if (!conversas.some(conversa => conversa.id === conversaSelecionada)) {
                conversaSelecionada = conversas.length ? conversas[0].id : null;
            }
            renderizarConversas();
            renderizarConversaAtiva();
        }
    });

    // ================================================================
    // 10. EVENTOS DA INTERFACE
    // ================================================================
    document.getElementById('open-new-conversation').addEventListener('click', abrirModalNovaConversa);
    document.getElementById('open-new-conversation-small').addEventListener('click', abrirModalNovaConversa);
    document.getElementById('empty-new-conversation').addEventListener('click', abrirModalNovaConversa);
    document.getElementById('close-new-conversation').addEventListener('click', fecharModalNovaConversa);
    document.getElementById('cancel-new-conversation').addEventListener('click', fecharModalNovaConversa);
    modalNovaConversa.addEventListener('click', evento => {
        if (evento.target === modalNovaConversa) fecharModalNovaConversa();
    });
    formularioNovaConversa.addEventListener('submit', criarConversa);
    tipoConversa.addEventListener('change', atualizarCamposTipoConversa);

    botoesFiltro.forEach(botao => {
        botao.addEventListener('click', () => {
            filtroAtual = botao.dataset.filter;
            atualizarBotoesFiltro();
            renderizarConversas();
        });
    });

    pesquisaConversas.addEventListener('input', () => aplicarPesquisa(pesquisaConversas.value, 'lista'));
    pesquisaGeral.addEventListener('input', () => aplicarPesquisa(pesquisaGeral.value, 'global'));

    botoesFiltroMensagens.forEach(botao => {
        botao.addEventListener('click', () => {
            filtroMensagens = botao.dataset.messageFilter;
            atualizarFiltroMensagens(conversaAtual());
            renderizarMensagens();
        });
    });

    formularioMensagem.addEventListener('submit', enviarMensagem);
    campoMensagem.addEventListener('input', ajustarAlturaMensagem);
    campoMensagem.addEventListener('keydown', evento => {
        if (evento.key === 'Enter' && !evento.shiftKey) {
            evento.preventDefault();
            formularioMensagem.requestSubmit();
        }
    });

    botaoAnexo.addEventListener('click', () => campoArquivo.click());
    botaoGravarAudio.addEventListener('click', alternarGravacaoAudio);
    campoArquivo.addEventListener('change', () => {
        const arquivos = Array.from(campoArquivo.files || []);
        campoArquivo.value = '';
        if (!arquivos.length) return;

        let algumArquivoGrande = false;
        arquivos.forEach(arquivo => {
            if (arquivo.size > LIMITE_ANEXO) {
                algumArquivoGrande = true;
                return;
            }
            arquivosSelecionados.push(arquivo);
        });

        mostrarPreviewAnexo();
        if (algumArquivoGrande) mostrarAviso('Um ou mais arquivos ultrapassam o limite de 5 MB e não foram adicionados.');
    });

    previewAnexo.addEventListener('click', evento => {
        const botao = evento.target.closest('.attachment-preview-remove[data-index]');
        if (!botao) return;

        const indice = Number(botao.dataset.index);
        if (!Number.isInteger(indice) || indice < 0 || indice >= arquivosSelecionados.length) return;
        arquivosSelecionados = arquivosSelecionados.filter((arquivo, posicao) => posicao !== indice);
        mostrarPreviewAnexo();
    });
    document.getElementById('cancel-reply').addEventListener('click', esconderPreviewResposta);
    document.getElementById('toggle-conversation-info').addEventListener('click', evento => {
        painelInfo.hidden = !painelInfo.hidden;
        evento.currentTarget.setAttribute('aria-expanded', String(!painelInfo.hidden));
    });
    document.getElementById('delete-conversation').addEventListener('click', excluirConversaAtual);
    document.getElementById('back-to-conversations').addEventListener('click', () => areaChat.classList.remove('mobile-chat-open'));

    document.addEventListener('keydown', evento => {
        if (evento.key === 'Escape' && !modalNovaConversa.hidden) fecharModalNovaConversa();
    });

    window.addEventListener('pagehide', () => {
        cancelarGravacaoAudio();
        liberarAudiosDaTela();
    });

    // ================================================================
    // 11. INICIALIZAÇÃO
    // ================================================================
    const nomeUsuarioCabecalho = document.querySelector('.user-info .name');
    const perfilUsuarioCabecalho = document.querySelector('.user-info .role');
    if (nomeUsuarioCabecalho) nomeUsuarioCabecalho.textContent = USUARIO_ATUAL;
    if (perfilUsuarioCabecalho && usuarioAtual.perfil) {
        perfilUsuarioCabecalho.textContent = usuarioAtual.perfil === 'gestor' ? 'Gestor' : 'Membro';
    }

    renderizarConversas();
    renderizarConversaAtiva();
});
