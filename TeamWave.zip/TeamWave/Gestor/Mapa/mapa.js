/**
 * ==========================================================================
 * CONFIGURAÇÕES DA APLICAÇÃO
 * ==========================================================================
 */
const AppConfig = {
    business: {
        id: "teamwave",
        nome: "Sede TeamWave",
        descricao: "Sede oficial da TeamWave, empresa especializada em comunicação e gestão de projetos.",
        endereco: "Praia Grande - SP",
        coordenadas: [-24.032406, -46.506550]
    },
    defaultZoom: 14,
    storageKey: "teamwave_empresas_localizacao_v1",
    customBoardsKey: "teamwave_quadros_personalizados_v1"
};

// Quadros predefinidos disponíveis na página Quadros.
const predefinedBoards = [
    { id: "team-wave", name: "TeamWave" },
    { id: "estrategia", name: "Estratégia" },
    { id: "operacoes", name: "Operações" },
    { id: "marketing", name: "Marketing" },
    { id: "projeto", name: "Projeto" },
    { id: "reunioes", name: "Reuniões" },
    { id: "design", name: "Design" },
    { id: "planejamento", name: "Planejamento" },
    { id: "natureza", name: "Natureza" },
    { id: "montanhas", name: "Montanhas" },
    { id: "praia", name: "Praia" },
    { id: "amanhecer", name: "Amanhecer" },
    { id: "ceu-estrelado", name: "Céu estrelado" }
];

/**
 * ==========================================================================
 * ESTADO DA APLICAÇÃO
 * ==========================================================================
 */
let map = null;
let userMarker = null;
let businessMarker = null;
let userAccuracyCircle = null;
let distanceLine = null;
let companyLayer = null;
let companyMarkers = new Map();
let companies = loadCompanies();
let userCoords = null;
let selectedCompany = null;
let selectingMapLocation = false;
let editingCompanyId = null;

/**
 * ==========================================================================
 * ELEMENTOS DO HTML
 * ==========================================================================
 */
const statusCard = document.getElementById("geo-status");
const statusText = document.getElementById("status-text");
const btnRetry = document.getElementById("btn-retry");
const btnRecenter = document.getElementById("btn-recenter");
const distancePanel = document.getElementById("distance-panel");
const selectedCompanyName = document.getElementById("selected-company-name");
const distanceText = document.getElementById("distance-text");
const distanceNote = document.getElementById("distance-note");
const companyForm = document.getElementById("company-form");
const companyNameInput = document.getElementById("company-name");
const companyDescriptionInput = document.getElementById("company-description");
const companyLatitudeInput = document.getElementById("company-latitude");
const companyLongitudeInput = document.getElementById("company-longitude");
const btnSelectMap = document.getElementById("btn-select-map");
const mapSelectionStatus = document.getElementById("map-selection-status");
const companyFormStatus = document.getElementById("company-form-status");
const companyList = document.getElementById("company-list");
const companyCount = document.getElementById("company-count");
const businessCard = document.getElementById("business-card");
const companyBoardsContainer = document.getElementById("company-boards");
const companyNoBoardsCheckbox = document.getElementById("company-no-boards");
const companyFormTitle = document.getElementById("company-form-title");
const companySubmitButton = document.getElementById("company-submit-button");
const btnCancelEditCompany = document.getElementById("btn-cancel-edit-company");

/**
 * ==========================================================================
 * INICIALIZAÇÃO DO MAPA
 * ==========================================================================
 */
function initMap() {
    map = L.map("map-container", {
        zoomControl: true,
        scrollWheelZoom: true
    }).setView(AppConfig.business.coordenadas, AppConfig.defaultZoom);

    // Camada do OpenStreetMap.
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Camada exclusiva para as empresas cadastradas.
    companyLayer = L.layerGroup().addTo(map);

    renderBusinessMarker();
    renderCompanyMarkers();
    renderCompanyList();

    // Detecta a seleção de uma localização pelo mapa.
    map.on("click", handleMapClick);
}

/**
 * ==========================================================================
 * CRIAÇÃO DOS MARCADORES
 * ==========================================================================
 */
function createMapIcon(type, label) {
    return L.divIcon({
        className: "",
        html: `<div class="custom-map-marker ${type}"><span>${label}</span></div>`,
        iconSize: [36, 44],
        iconAnchor: [18, 43],
        popupAnchor: [0, -42]
    });
}

/**
 * ==========================================================================
 * MARCADOR DA TEAMWAVE
 * ==========================================================================
 */
function renderBusinessMarker() {
    const business = AppConfig.business;
    const businessIcon = createMapIcon("business-map-marker", "TW");

    businessMarker = L.marker(business.coordenadas, {
        icon: businessIcon,
        title: business.nome
    }).addTo(map);

    businessMarker.bindPopup(`
        <div>
            <h4>${escapeHTML(business.nome)}</h4>
            <p>${escapeHTML(business.descricao)}</p>
            <p>${escapeHTML(business.endereco)}</p>
        </div>
    `);

    // Seleciona a sede quando seu popup for aberto.
    businessMarker.on("popupopen", () => {
        selectCompany({
            id: business.id,
            name: business.nome,
            description: business.descricao,
            latitude: business.coordenadas[0],
            longitude: business.coordenadas[1]
        });
    });
}

/**
 * ==========================================================================
 * CARREGAMENTO DAS EMPRESAS SALVAS
 * ==========================================================================
 */
function loadCompanies() {
    try {
        const savedCompanies = localStorage.getItem(AppConfig.storageKey);

        if (!savedCompanies) {
            return [];
        }

        const parsedCompanies = JSON.parse(savedCompanies);

        if (!Array.isArray(parsedCompanies)) {
            return [];
        }

        return parsedCompanies.filter(company => {
            return (
                company &&
                typeof company.id === "string" &&
                typeof company.name === "string" &&
                typeof company.description === "string" &&
                Number.isFinite(company.latitude) &&
                Number.isFinite(company.longitude) &&
                company.latitude >= -90 &&
                company.latitude <= 90 &&
                company.longitude >= -180 &&
                company.longitude <= 180
            );
        }).map(company => ({
            ...company,
            // Empresas antigas ainda podem não possuir a propriedade boardIds.
            boardIds: Array.isArray(company.boardIds)
                ? company.boardIds.filter(id => typeof id === "string")
                : []
        }));
    } catch (error) {
        console.error("Erro ao recuperar empresas:", error);
        return [];
    }
}

/**
 * ==========================================================================
 * QUADROS DISPONÍVEIS PARA VINCULAR À EMPRESA
 * ==========================================================================
 */
function loadAvailableBoards() {
    let customBoards = [];

    try {
        const savedBoards = JSON.parse(localStorage.getItem(AppConfig.customBoardsKey) || "[]");

        if (Array.isArray(savedBoards)) {
            customBoards = savedBoards
                .filter(board =>
                    board &&
                    typeof board.id === "string" &&
                    typeof board.name === "string" &&
                    board.name.trim()
                )
                .map(board => ({
                    id: board.id,
                    name: board.name.trim()
                }));
        }
    } catch (error) {
        console.error("Erro ao carregar os quadros personalizados:", error);
    }

    const allBoards = [...predefinedBoards, ...customBoards];
    const uniqueBoards = new Map();

    allBoards.forEach(board => {
        if (!uniqueBoards.has(board.id)) {
            uniqueBoards.set(board.id, board);
        }
    });

    return Array.from(uniqueBoards.values()).sort((a, b) =>
        a.name.localeCompare(b.name, "pt-BR")
    );
}

function renderBoardOptions(selectedBoardIds = [], noBoardsSelected = false) {
    companyBoardsContainer.replaceChildren();
    companyNoBoardsCheckbox.checked = noBoardsSelected;

    const boards = loadAvailableBoards();

    if (boards.length === 0) {
        const message = document.createElement("p");
        message.className = "board-assignment-empty";
        message.textContent = "Nenhum quadro disponível foi encontrado.";
        companyBoardsContainer.appendChild(message);
        updateBoardSelectionState();
        return;
    }

    boards.forEach(board => {
        const label = document.createElement("label");
        label.className = "board-assignment-option";

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.name = "company-boards";
        checkbox.value = board.id;
        checkbox.checked = selectedBoardIds.includes(board.id);

        const name = document.createElement("span");
        name.textContent = board.name;

        label.append(checkbox, name);
        companyBoardsContainer.appendChild(label);
    });

    updateBoardSelectionState();
}

function updateBoardSelectionState() {
    const noBoardsSelected = companyNoBoardsCheckbox.checked;
    const boardCheckboxes = companyBoardsContainer.querySelectorAll('input[name="company-boards"]');

    boardCheckboxes.forEach(checkbox => {
        if (noBoardsSelected) checkbox.checked = false;
        checkbox.disabled = noBoardsSelected;
    });

    companyBoardsContainer.classList.toggle("is-disabled", noBoardsSelected);
}

function getSelectedBoardIds() {
    return Array.from(companyBoardsContainer.querySelectorAll('input[name="company-boards"]:checked'))
        .map(checkbox => checkbox.value);
}

function getCompanyBoardNames(company) {
    const boards = loadAvailableBoards();
    const boardNames = (Array.isArray(company.boardIds) ? company.boardIds : []).map(id => {
        const board = boards.find(item => item.id === id);
        return board ? board.name : "Quadro não disponível";
    });

    return [...new Set(boardNames)];
}

function resetCompanyForm() {
    companyForm.reset();
    editingCompanyId = null;
    companyFormTitle.textContent = "Adicionar empresa";
    companySubmitButton.textContent = "+ Adicionar empresa";
    btnCancelEditCompany.hidden = true;
    renderBoardOptions();
    cancelMapSelection();
}

function prepareCompanyEdit(company) {
    editingCompanyId = company.id;
    companyFormTitle.textContent = "Editar empresa";
    companySubmitButton.textContent = "Salvar alterações";
    btnCancelEditCompany.hidden = false;

    companyNameInput.value = company.name;
    companyDescriptionInput.value = company.description;
    companyLatitudeInput.value = company.latitude;
    companyLongitudeInput.value = company.longitude;
    const assignedBoardIds = company.boardIds || [];
    renderBoardOptions(assignedBoardIds, assignedBoardIds.length === 0);

    updateCompanyFormStatus("success", "Altere os dados e os quadros relacionados e salve as alterações.");
    companyForm.scrollIntoView({ behavior: "smooth", block: "nearest" });
    companyNameInput.focus({ preventScroll: true });
}

/**
 * ==========================================================================
 * SALVAMENTO DAS EMPRESAS
 * ==========================================================================
 */
function saveCompanies() {
    try {
        localStorage.setItem(AppConfig.storageKey, JSON.stringify(companies));
        return true;
    } catch (error) {
        console.error("Erro ao salvar empresas:", error);
        return false;
    }
}

/**
 * ==========================================================================
 * CADASTRAMENTO DE UMA NOVA EMPRESA
 * ==========================================================================
 */
function addCompany(event) {
    event.preventDefault();

    const name = companyNameInput.value.trim();
    const description = companyDescriptionInput.value.trim();
    const latitudeValue = companyLatitudeInput.value.trim();
    const longitudeValue = companyLongitudeInput.value.trim();
    const boardIds = getSelectedBoardIds();

    if (!name || !latitudeValue || !longitudeValue) {
        updateCompanyFormStatus("error", "Preencha o nome e a localização da empresa.");
        return;
    }

    if (boardIds.length === 0 && !companyNoBoardsCheckbox.checked) {
        updateCompanyFormStatus("error", "Selecione pelo menos um quadro ou marque a opção para não relacionar a empresa a nenhum quadro.");
        return;
    }

    const latitude = Number(latitudeValue);
    const longitude = Number(longitudeValue);

    if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) {
        updateCompanyFormStatus("error", "Informe uma latitude válida entre -90 e 90.");
        return;
    }

    if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
        updateCompanyFormStatus("error", "Informe uma longitude válida entre -180 e 180.");
        return;
    }

    let company;
    let successMessage;
    let wasSelected = false;

    if (editingCompanyId) {
        const companyIndex = companies.findIndex(item => item.id === editingCompanyId);
        wasSelected = Boolean(selectedCompany && selectedCompany.id === editingCompanyId);

        if (companyIndex === -1) {
            updateCompanyFormStatus("error", "A empresa que você tentou editar não foi encontrada.");
            resetCompanyForm();
            return;
        }

        company = {
            ...companies[companyIndex],
            name,
            description,
            latitude,
            longitude,
            boardIds
        };

        companies[companyIndex] = company;
        if (wasSelected) selectedCompany = company;
        successMessage = "Empresa atualizada com sucesso!";
    } else {
        company = {
            id: typeof crypto !== "undefined" && crypto.randomUUID
                ? crypto.randomUUID()
                : `${Date.now()}-${Math.random()}`,
            name,
            description,
            latitude,
            longitude,
            boardIds
        };

        companies.push(company);
        successMessage = "Empresa cadastrada com sucesso!";
    }

    const saved = saveCompanies();

    renderCompanyMarkers();
    renderCompanyList();

    // Apenas centraliza o mapa na empresa salva, sem calcular a distância automaticamente.
    map.setView([latitude, longitude], 15);

    if (wasSelected) updateDistance();

    resetCompanyForm();

    if (saved) {
        updateCompanyFormStatus("success", `${successMessage} Selecione seu marcador para calcular a distância.`);
    } else {
        updateCompanyFormStatus("error", "As alterações foram aplicadas na tela, mas não foi possível salvar os dados no navegador.");
    }
}

/**
 * ==========================================================================
 * MARCADORES DAS OUTRAS EMPRESAS
 * ==========================================================================
 */
function renderCompanyMarkers() {
    companyLayer.clearLayers();
    companyMarkers.clear();

    companies.forEach(company => {
        const companyIcon = createMapIcon("company-map-marker", "EM");

        const marker = L.marker(
            [company.latitude, company.longitude],
            {
                icon: companyIcon,
                title: company.name
            }
        ).addTo(companyLayer);

        // Informações e quadros relacionados exibidos ao clicar no marcador.
        const boardNames = getCompanyBoardNames(company);
        const boardsText = boardNames.length
            ? boardNames.map(escapeHTML).join(", ")
            : "Nenhum quadro atribuído";

        marker.bindPopup(`
            <div class="company-popup">
                <h4>${escapeHTML(company.name)}</h4>
                <p>${escapeHTML(company.description).replace(/\n/g, "<br>")}</p>
                <p><strong>Quadros Kanban:</strong> ${boardsText}</p>
                <p><strong>Latitude:</strong> ${company.latitude.toFixed(6)}</p>
                <p><strong>Longitude:</strong> ${company.longitude.toFixed(6)}</p>
            </div>
        `);

        // Seleciona a empresa e calcula a distância até o cliente.
        marker.on("click", () => {
            selectCompany(company);
        });

        companyMarkers.set(company.id, marker);
    });
}

/**
 * ==========================================================================
 * PROTEÇÃO DOS TEXTOS DOS POPUPS
 * ==========================================================================
 */
function escapeHTML(text) {
    return String(text).replace(/[&<>"']/g, character => {
        const characters = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        };

        return characters[character];
    });
}

/**
 * ==========================================================================
 * SELEÇÃO DE UMA EMPRESA PARA CALCULAR A DISTÂNCIA
 * ==========================================================================
 */
function selectCompany(company) {
    // Guarda a empresa escolhida pelo usuário.
    selectedCompany = company;

    // Atualiza o nome apresentado no painel.
    selectedCompanyName.textContent = company.name;

    // Mostra o painel de distância.
    distancePanel.classList.remove("hidden");

    // Calcula a distância somente para a empresa selecionada.
    updateDistance();

    // Ajusta o mapa para mostrar os dois pontos, quando possível.
    fitSelectedCompany();
}

// Seleciona a sede da TeamWave ao clicar no card.
function selectTeamWaveBusiness() {
    selectCompany({
        id: AppConfig.business.id,
        name: AppConfig.business.nome,
        description: AppConfig.business.descricao,
        latitude: AppConfig.business.coordenadas[0],
        longitude: AppConfig.business.coordenadas[1]
    });
}

/**
 * ==========================================================================
 * ATUALIZAÇÃO DA DISTÂNCIA DA EMPRESA SELECIONADA
 * ==========================================================================
 */
function updateDistance() {
    // Remove a linha anterior.
    if (distanceLine) {
        map.removeLayer(distanceLine);
        distanceLine = null;
    }

    // Não calcula distância se nenhuma empresa foi selecionada.
    if (!selectedCompany) {
        distancePanel.classList.add("hidden");
        return;
    }

    selectedCompanyName.textContent = selectedCompany.name;

    // Verifica se a localização do cliente foi obtida.
    if (!userCoords) {
        distanceText.textContent = "Indisponível";
        distanceNote.textContent = "Autorize o acesso à sua localização para calcular a distância até esta empresa.";
        return;
    }

    const companyCoords = [
        selectedCompany.latitude,
        selectedCompany.longitude
    ];

    // Calcula a distância entre o cliente e a empresa selecionada.
    const distanceInMeters = calculateDistance(
        userCoords[0],
        userCoords[1],
        companyCoords[0],
        companyCoords[1]
    );

    distanceText.textContent = formatDistance(distanceInMeters);
    distanceNote.textContent = "Distância aproximada em linha reta entre sua localização e a empresa selecionada.";

    // Desenha a linha entre o usuário e a empresa selecionada.
    distanceLine = L.polyline(
        [userCoords, companyCoords],
        {
            color: "#3159d9",
            weight: 3,
            opacity: 0.85,
            dashArray: "7, 8"
        }
    ).addTo(map);
}

/**
 * ==========================================================================
 * CENTRALIZAÇÃO DA EMPRESA SELECIONADA
 * ==========================================================================
 */
function fitSelectedCompany() {
    if (!selectedCompany) {
        return;
    }

    const companyCoords = [
        selectedCompany.latitude,
        selectedCompany.longitude
    ];

    // Quando a localização do usuário está disponível, mostra os dois pontos.
    if (userCoords) {
        const bounds = L.latLngBounds([
            userCoords,
            companyCoords
        ]);

        map.fitBounds(bounds, {
            padding: [55, 55],
            maxZoom: 14,
            animate: true
        });
    } else {
        map.setView(companyCoords, 15);
    }
}

/**
 * ==========================================================================
 * LISTA LATERAL DE EMPRESAS
 * ==========================================================================
 */
function renderCompanyList() {
    companyList.replaceChildren();
    companyCount.textContent = companies.length;

    if (companies.length === 0) {
        const emptyMessage = document.createElement("p");
        emptyMessage.className = "empty-companies";
        emptyMessage.textContent = "Nenhuma empresa cadastrada.";
        companyList.appendChild(emptyMessage);
        return;
    }

    companies.forEach(company => {
        const item = document.createElement("div");
        item.className = "company-item";

        const info = document.createElement("div");
        info.className = "company-item-info";

        const name = document.createElement("strong");
        name.textContent = company.name;

        const coordinates = document.createElement("small");
        coordinates.textContent = `${company.latitude.toFixed(4)}, ${company.longitude.toFixed(4)}`;

        const boards = document.createElement("small");
        boards.className = "company-item-boards";
        const boardNames = getCompanyBoardNames(company);
        boards.textContent = boardNames.length
            ? `Quadros: ${boardNames.join(", ")}`
            : "Quadros: nenhum atribuído";

        info.append(name, coordinates, boards);

        const actions = document.createElement("div");
        actions.className = "company-item-actions";

        const viewButton = document.createElement("button");
        viewButton.type = "button";
        viewButton.className = "btn-view-company";
        viewButton.textContent = "Ver";
        viewButton.dataset.id = company.id;

        const editButton = document.createElement("button");
        editButton.type = "button";
        editButton.className = "btn-edit-company";
        editButton.textContent = "Editar";
        editButton.dataset.id = company.id;

        const removeButton = document.createElement("button");
        removeButton.type = "button";
        removeButton.className = "btn-remove-company";
        removeButton.textContent = "Excluir";
        removeButton.dataset.id = company.id;

        actions.append(viewButton, editButton, removeButton);
        item.append(info, actions);
        companyList.appendChild(item);
    });
}

/**
 * ==========================================================================
 * EVENTOS DA LISTA DE EMPRESAS
 * ==========================================================================
 */
function handleCompanyListClick(event) {
    const viewButton = event.target.closest(".btn-view-company");

    if (viewButton) {
        const company = companies.find(item => item.id === viewButton.dataset.id);

        if (company) {
            selectCompany(company);

            const marker = companyMarkers.get(company.id);

            if (marker) {
                marker.openPopup();
            }
        }
    }

    const editButton = event.target.closest(".btn-edit-company");

    if (editButton) {
        const company = companies.find(item => item.id === editButton.dataset.id);
        if (company) prepareCompanyEdit(company);
    }

    const removeButton = event.target.closest(".btn-remove-company");

    if (removeButton) {
        removeCompany(removeButton.dataset.id);
    }
}

/**
 * ==========================================================================
 * REMOÇÃO DE EMPRESAS
 * ==========================================================================
 */
function removeCompany(id) {
    companies = companies.filter(company => company.id !== id);

    // Cancela a edição caso a empresa em edição seja excluída.
    if (editingCompanyId === id) resetCompanyForm();

    // Limpa a seleção caso a empresa selecionada seja excluída.
    if (selectedCompany && selectedCompany.id === id) {
        clearSelectedCompany();
    }

    const saved = saveCompanies();

    renderCompanyMarkers();
    renderCompanyList();

    if (saved) {
        updateCompanyFormStatus("success", "Empresa removida com sucesso.");
    } else {
        updateCompanyFormStatus("error", "Empresa removida da visualização, mas não foi possível atualizar o armazenamento.");
    }
}

/**
 * ==========================================================================
 * LIMPEZA DA EMPRESA SELECIONADA
 * ==========================================================================
 */
function clearSelectedCompany() {
    selectedCompany = null;

    if (distanceLine) {
        map.removeLayer(distanceLine);
        distanceLine = null;
    }

    distancePanel.classList.add("hidden");
}

/**
 * ==========================================================================
 * SELEÇÃO DE LOCALIZAÇÃO PELO MAPA
 * ==========================================================================
 */
function startMapSelection() {
    selectingMapLocation = true;

    btnSelectMap.classList.add("active");
    btnSelectMap.textContent = "Cancelar seleção";

    map.getContainer().style.cursor = "crosshair";

    mapSelectionStatus.textContent = "Clique no ponto desejado no mapa para definir a localização da empresa.";
    mapSelectionStatus.classList.add("active");
}

function cancelMapSelection() {
    selectingMapLocation = false;

    btnSelectMap.classList.remove("active");
    btnSelectMap.textContent = "Selecionar no mapa";

    map.getContainer().style.cursor = "";

    mapSelectionStatus.textContent = "Nenhuma localização selecionada.";
    mapSelectionStatus.classList.remove("active");
}

/**
 * ==========================================================================
 * CAPTURA DAS COORDENADAS NO MAPA
 * ==========================================================================
 */
function handleMapClick(event) {
    if (!selectingMapLocation) {
        return;
    }

    const latitude = event.latlng.lat;
    const longitude = event.latlng.lng;

    // Preenche automaticamente os campos de coordenadas.
    companyLatitudeInput.value = latitude.toFixed(6);
    companyLongitudeInput.value = longitude.toFixed(6);

    cancelMapSelection();

    mapSelectionStatus.textContent = "Localização selecionada com sucesso! Agora você pode cadastrar a empresa.";
}

/**
 * ==========================================================================
 * MENSAGENS DO FORMULÁRIO
 * ==========================================================================
 */
function updateCompanyFormStatus(type, message) {
    companyFormStatus.className = `company-form-status ${type}`;
    companyFormStatus.textContent = message;
}

/**
 * ==========================================================================
 * GEOLOCALIZAÇÃO DO CLIENTE
 * ==========================================================================
 */
function executeGeolocation() {
    if (!navigator.geolocation) {
        updateUIStatus("error", "Seu navegador não oferece suporte à geolocalização. Você ainda pode visualizar as empresas.");
        btnRetry.classList.add("hidden");
        return;
    }

    if (!window.isSecureContext) {
        updateUIStatus("error", "Abra o projeto em uma conexão segura (HTTPS) ou em um servidor local, como o Live Server.");
        btnRetry.classList.add("hidden");
        return;
    }

    updateUIStatus("info", "Aguardando sua autorização no navegador para acessar a localização...");
    btnRetry.classList.add("hidden");

    const geoOptions = {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0
    };

    navigator.geolocation.getCurrentPosition(
        handleGeoSuccess,
        handleGeoError,
        geoOptions
    );
}

/**
 * ==========================================================================
 * LOCALIZAÇÃO DO CLIENTE ENCONTRADA
 * ==========================================================================
 */
function handleGeoSuccess(position) {
    const lat = position.coords.latitude;
    const lng = position.coords.longitude;
    const accuracy = position.coords.accuracy;

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
        handleGeoError({ code: 2 });
        return;
    }

    userCoords = [lat, lng];

    updateUIStatus("success", "Localização encontrada! Clique em uma empresa no mapa para calcular a distância até ela.");

    btnRetry.classList.add("hidden");
    btnRecenter.classList.remove("hidden");

    renderUserMarker(accuracy);

    // Só calcula a distância se o usuário já tiver selecionado uma empresa.
    if (selectedCompany) {
        updateDistance();
        fitSelectedCompany();
    } else {
        // Sem empresa selecionada, apenas mostra as localizações no mapa.
        fitAllLocations();
    }
}

/**
 * ==========================================================================
 * MARCADOR DA LOCALIZAÇÃO DO CLIENTE
 * ==========================================================================
 */
function renderUserMarker(accuracy) {
    const userIcon = createMapIcon("client-map-marker", "EU");

    if (userMarker) {
        map.removeLayer(userMarker);
    }

    if (userAccuracyCircle) {
        map.removeLayer(userAccuracyCircle);
    }

    userMarker = L.marker(userCoords, {
        icon: userIcon,
        title: "Sua localização atual"
    }).addTo(map);

    userMarker.bindPopup(`
        <div>
            <h4>Você está aqui!</h4>
            <p>Precisão aproximada: ${formatDistance(accuracy)}.</p>
        </div>
    `);

    if (Number.isFinite(accuracy) && accuracy > 0) {
        userAccuracyCircle = L.circle(userCoords, {
            radius: accuracy,
            color: "#2563eb",
            weight: 1,
            opacity: 0.55,
            fillColor: "#2563eb",
            fillOpacity: 0.08
        }).addTo(map);
    }
}

/**
 * ==========================================================================
 * TRATAMENTO DE ERROS DA GEOLOCALIZAÇÃO
 * ==========================================================================
 */
function handleGeoError(error) {
    let message = "Não foi possível obter sua localização atual.";
    const errorCode = error && Number(error.code);

    switch (errorCode) {
        case 1:
            message = "O acesso à localização foi negado. Altere a permissão nas configurações do navegador e tente novamente.";
            break;
        case 2:
            message = "Sua localização não está disponível no momento. Verifique o GPS ou a conexão.";
            break;
        case 3:
            message = "A busca pela localização demorou demais. Tente novamente.";
            break;
        default:
            message = "Ocorreu um erro ao obter sua localização. Você ainda pode visualizar as empresas cadastradas.";
    }

    updateUIStatus("error", message);

    btnRetry.classList.remove("hidden");
    btnRecenter.classList.add("hidden");

    if (!userCoords) {
        map.setView(AppConfig.business.coordenadas, AppConfig.defaultZoom);
    }

    // Não calcula distância automaticamente.
    // Se houver uma empresa selecionada, aguarda a localização do usuário.
    if (selectedCompany) {
        updateDistance();
    }
}

/**
 * ==========================================================================
 * FÓRMULA DE HAVERSINE
 * ==========================================================================
 */
function calculateDistance(lat1, lon1, lat2, lon2) {
    const earthRadius = 6371000;

    const toRadians = degrees => {
        return degrees * (Math.PI / 180);
    };

    const deltaLat = toRadians(lat2 - lat1);
    const deltaLon = toRadians(lon2 - lon1);

    const a = Math.sin(deltaLat / 2) ** 2 +
        Math.cos(toRadians(lat1)) *
        Math.cos(toRadians(lat2)) *
        Math.sin(deltaLon / 2) ** 2;

    const centralAngle = 2 * Math.atan2(
        Math.sqrt(a),
        Math.sqrt(1 - a)
    );

    return earthRadius * centralAngle;
}

/**
 * ==========================================================================
 * FORMATAÇÃO DA DISTÂNCIA
 * ==========================================================================
 */
function formatDistance(meters) {
    if (!Number.isFinite(meters)) {
        return "Indisponível";
    }

    if (meters < 1000) {
        return `${Math.round(meters)} m`;
    }

    return `${(meters / 1000).toLocaleString("pt-BR", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })} km`;
}

/**
 * ==========================================================================
 * CENTRALIZAÇÃO DE TODAS AS LOCALIZAÇÕES
 * ==========================================================================
 */
function fitAllLocations() {
    const locations = [AppConfig.business.coordenadas];

    if (userCoords) {
        locations.push(userCoords);
    }

    companies.forEach(company => {
        locations.push([company.latitude, company.longitude]);
    });

    const bounds = L.latLngBounds(locations);

    map.fitBounds(bounds, {
        padding: [55, 55],
        maxZoom: 14,
        animate: true
    });
}

/**
 * ==========================================================================
 * ATUALIZAÇÃO DO STATUS DA GEOLOCALIZAÇÃO
 * ==========================================================================
 */
function updateUIStatus(type, message) {
    statusCard.className = `status-card ${type}`;
    statusText.textContent = message;
}

/**
 * ==========================================================================
 * EVENTOS DOS BOTÕES E FORMULÁRIOS
 * ==========================================================================
 */

// Cadastro e edição de empresas.
renderBoardOptions();
companyNoBoardsCheckbox.addEventListener("change", updateBoardSelectionState);
companyBoardsContainer.addEventListener("change", event => {
    if (event.target.matches('input[name="company-boards"]') && event.target.checked) {
        companyNoBoardsCheckbox.checked = false;
    }
    updateBoardSelectionState();
});
companyForm.addEventListener("submit", addCompany);
btnCancelEditCompany.addEventListener("click", () => {
    resetCompanyForm();
    updateCompanyFormStatus("success", "Edição cancelada.");
});

// Seleção de localização pelo mapa.
btnSelectMap.addEventListener("click", () => {
    if (selectingMapLocation) {
        cancelMapSelection();
    } else {
        startMapSelection();
    }
});

// Botões da lista de empresas.
companyList.addEventListener("click", handleCompanyListClick);

// Nova tentativa de obter localização.
btnRetry.addEventListener("click", executeGeolocation);

// Evento de clique no card.
businessCard.addEventListener("click", selectTeamWaveBusiness);

// Permite selecionar o card utilizando Enter ou Espaço.
businessCard.addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectTeamWaveBusiness();
    }
});

// Centralização do mapa na localização do usuário.
btnRecenter.addEventListener("click", () => {
    if (userCoords) {
        map.setView(userCoords, 15, { animate: true });
    } else {
        map.setView(AppConfig.business.coordenadas, AppConfig.defaultZoom);
    }
});

/**
 * ==========================================================================
 * INICIALIZAÇÃO DA APLICAÇÃO
 * ==========================================================================
 */
document.addEventListener("DOMContentLoaded", () => {
    initMap();
    executeGeolocation();
});