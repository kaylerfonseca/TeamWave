/* ========================================================================== */
/* TEAMWAVE - DASHBOARD DE TAREFAS                                            */
/* Reúne as tarefas salvas em todos os quadros do Kanban.                     */
/* ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
    // O TeamWave utiliza a chave antiga; os demais quadros usam o próprio ID.
    const CHAVE_TAREFAS = 'teamwave_kanban_tarefas_v1';
    const PREFIXO_CHAVES_TAREFAS = `${CHAVE_TAREFAS}_`;
    const CHAVE_QUADROS_PERSONALIZADOS = 'teamwave_quadros_personalizados_v1';

    // Status utilizados pelas colunas do Kanban. Status extras salvos no navegador
    // também serão incluídos no filtro para manter compatibilidade.
    const STATUS_KANBAN = ['Documentos', 'A Fazer', 'Fazendo', 'Concluído'];
    const ORDEM_STATUS = ['Documentos', 'A Fazer', 'Pendente', 'Fazendo', 'Em andamento', 'Concluído', 'Concluída'];
    const ORDEM_PRIORIDADE = ['Urgente', 'Alta', 'Média', 'Baixa'];

    // Elementos usados pela interface.
    const DOM = {
        total: document.getElementById('total-tarefas'),
        pendentes: document.getElementById('tarefas-pendentes'),
        andamento: document.getElementById('tarefas-andamento'),
        concluidas: document.getElementById('tarefas-concluidas'),
        atrasadas: document.getElementById('tarefas-atrasadas'),
        percentual: document.getElementById('percentual-conclusao'),
        barraProgresso: document.getElementById('barra-progresso'),
        progressoAcessivel: document.getElementById('progresso-acessivel'),
        resumoProgresso: document.getElementById('resumo-progresso'),
        pesquisa: document.getElementById('pesquisa-tarefa'),
        filtroStatus: document.getElementById('filtro-status'),
        filtroPrioridade: document.getElementById('filtro-prioridade'),
        filtroPrazo: document.getElementById('filtro-prazo'),
        ordenacao: document.getElementById('ordenacao'),
        limparFiltros: document.getElementById('limpar-filtros'),
        atualizar: document.getElementById('btn-atualizar'),
        syncStatus: document.getElementById('sync-status'),
        lista: document.getElementById('lista-tarefas'),
        estadoVazio: document.getElementById('estado-vazio'),
        tituloVazio: document.getElementById('titulo-vazio'),
        mensagemVazia: document.getElementById('mensagem-vazia'),
        contadorResultados: document.getElementById('contador-resultados')
    };

    let tarefas = [];
    let erroLeitura = false;

    // Obtém a data atual no formato AAAA-MM-DD usando o horário local do dispositivo.
    function dataLocalISO(data = new Date()) {
        const ano = data.getFullYear();
        const mes = String(data.getMonth() + 1).padStart(2, '0');
        const dia = String(data.getDate()).padStart(2, '0');
        return `${ano}-${mes}-${dia}`;
    }

    // Soma dias à data local sem depender da conversão para UTC.
    function somarDias(dataISO, quantidade) {
        const [ano, mes, dia] = dataISO.split('-').map(Number);
        const data = new Date(ano, mes - 1, dia, 12, 0, 0);
        data.setDate(data.getDate() + quantidade);
        return dataLocalISO(data);
    }

    // Converte AAAA-MM-DD em DD/MM/AAAA para exibição.
    function formatarData(dataISO) {
        if (!dataISO || !/^\d{4}-\d{2}-\d{2}$/.test(dataISO)) return '';
        const [ano, mes, dia] = dataISO.split('-');
        return `${dia}/${mes}/${ano}`;
    }

    // Obtém todas as chaves utilizadas para armazenar tarefas dos quadros.
    function obterChavesDosQuadros() {
        const chaves = [];

        // Preserva a leitura do quadro TeamWave, que utiliza a chave antiga.
        if (localStorage.getItem(CHAVE_TAREFAS) !== null) {
            chaves.push(CHAVE_TAREFAS);
        }

        // Os outros quadros salvam as tarefas com o ID anexado à chave principal.
        for (let indice = 0; indice < localStorage.length; indice++) {
            const chave = localStorage.key(indice);

            if (chave && chave.startsWith(PREFIXO_CHAVES_TAREFAS)) {
                chaves.push(chave);
            }
        }

        return [...new Set(chaves)];
    }

    // Recupera os nomes dos quadros padrões e dos quadros criados pela pessoa.
    function carregarNomesQuadros() {
        const nomes = new Map([
            ['team-wave', 'TeamWave'],
            ['estrategia', 'Estratégia'],
            ['operacoes', 'Operações'],
            ['marketing', 'Marketing'],
            ['projeto', 'Projeto'],
            ['reunioes', 'Reuniões'],
            ['design', 'Design'],
            ['planejamento', 'Planejamento'],
            ['natureza', 'Natureza'],
            ['montanhas', 'Montanhas'],
            ['praia', 'Praia'],
            ['amanhecer', 'Amanhecer'],
            ['ceu-estrelado', 'Céu estrelado']
        ]);

        try {
            const dados = JSON.parse(localStorage.getItem(CHAVE_QUADROS_PERSONALIZADOS) || '[]');

            if (Array.isArray(dados)) {
                dados.forEach(quadro => {
                    if (quadro && typeof quadro.id === 'string' && typeof quadro.name === 'string' && quadro.name.trim()) {
                        nomes.set(quadro.id, quadro.name.trim());
                    }
                });
            }
        } catch (erro) {
            console.warn('Não foi possível carregar os nomes dos quadros personalizados:', erro);
        }

        return nomes;
    }

    // Gera um nome legível caso algum quadro não esteja no cadastro de nomes.
    function nomeDoQuadroPeloId(id) {
        const nome = String(id || 'quadro').replace(/[-_]+/g, ' ').trim();
        return nome ? nome.charAt(0).toLocaleUpperCase('pt-BR') + nome.slice(1) : 'Quadro';
    }

    // Lê as tarefas de todos os quadros e mantém a identificação de sua origem.
    function carregarTarefas() {
        erroLeitura = false;

        try {
            const chaves = obterChavesDosQuadros();
            const nomesQuadros = carregarNomesQuadros();
            const todasTarefas = [];

            chaves.forEach(chave => {
                try {
                    const dados = localStorage.getItem(chave);
                    if (dados === null) return;

                    const tarefasSalvas = JSON.parse(dados);
                    if (!Array.isArray(tarefasSalvas)) {
                        throw new Error(`Os dados salvos na chave "${chave}" não são uma lista de tarefas.`);
                    }

                    const idQuadro = chave === CHAVE_TAREFAS
                        ? 'team-wave'
                        : chave.slice(PREFIXO_CHAVES_TAREFAS.length);
                    const nomeQuadro = nomesQuadros.get(idQuadro) || nomeDoQuadroPeloId(idQuadro);

                    tarefasSalvas
                        .filter(tarefa => tarefa && typeof tarefa.title === 'string' && tarefa.title.trim())
                        .forEach(tarefa => {
                            todasTarefas.push({
                                id: String(tarefa.id || ''),
                                title: String(tarefa.title || '').trim(),
                                description: String(tarefa.description || ''),
                                responsible: String(tarefa.responsible || '').trim(),
                                priority: ORDEM_PRIORIDADE.includes(tarefa.priority) ? tarefa.priority : 'Média',
                                dueDate: /^\d{4}-\d{2}-\d{2}$/.test(String(tarefa.dueDate || '')) ? tarefa.dueDate : '',
                                status: String(tarefa.status || 'A Fazer'),
                                boardId: idQuadro,
                                boardName: nomeQuadro
                            });
                        });
                } catch (erro) {
                    console.error(`Não foi possível ler as tarefas do quadro associado à chave "${chave}":`, erro);
                    erroLeitura = true;
                }
            });

            return todasTarefas;
        } catch (erro) {
            console.error('Não foi possível localizar as tarefas dos quadros:', erro);
            erroLeitura = true;
            return [];
        }
    }

    // Normaliza o status para calcular indicadores mesmo se houver registros antigos.
    function statusNormalizado(tarefa) {
        return String(tarefa.status || '').toLocaleLowerCase('pt-BR').trim();
    }

    function tarefaConcluida(tarefa) {
        return ['concluído', 'concluída', 'concluida', 'concluido'].includes(statusNormalizado(tarefa));
    }

    function tarefaPendente(tarefa) {
        return ['documentos', 'a fazer', 'pendente'].includes(statusNormalizado(tarefa));
    }

    function tarefaEmAndamento(tarefa) {
        return ['fazendo', 'em andamento'].includes(statusNormalizado(tarefa));
    }

    // Uma tarefa só conta como atrasada quando ainda não foi concluída.
    function tarefaAtrasada(tarefa) {
        return Boolean(tarefa.dueDate && tarefa.dueDate < dataLocalISO() && !tarefaConcluida(tarefa));
    }

    // Atualiza os números com base em todas as tarefas, independentemente dos filtros.
    function atualizarIndicadores() {
        const total = tarefas.length;
        const pendentes = tarefas.filter(tarefaPendente).length;
        const andamento = tarefas.filter(tarefaEmAndamento).length;
        const concluidas = tarefas.filter(tarefaConcluida).length;
        const atrasadas = tarefas.filter(tarefaAtrasada).length;
        const percentual = total ? Math.round((concluidas / total) * 100) : 0;

        DOM.total.textContent = total;
        DOM.pendentes.textContent = pendentes;
        DOM.andamento.textContent = andamento;
        DOM.concluidas.textContent = concluidas;
        DOM.atrasadas.textContent = atrasadas;
        DOM.percentual.textContent = `${percentual}%`;
        DOM.barraProgresso.style.width = `${percentual}%`;
        DOM.progressoAcessivel.setAttribute('aria-valuenow', percentual);
        DOM.resumoProgresso.textContent = `${concluidas} de ${total} ${total === 1 ? 'tarefa concluída' : 'tarefas concluídas'}`;
    }

    // Preenche o filtro usando os status conhecidos e os status encontrados nos dados.
    function atualizarOpcoesStatus() {
        const valorSelecionado = DOM.filtroStatus.value;
        const statusEncontrados = tarefas.map(tarefa => tarefa.status).filter(Boolean);
        const todosStatus = [...new Set([...STATUS_KANBAN, ...statusEncontrados])];

        todosStatus.sort((a, b) => {
            const indiceA = ORDEM_STATUS.indexOf(a);
            const indiceB = ORDEM_STATUS.indexOf(b);
            if (indiceA >= 0 || indiceB >= 0) {
                return (indiceA < 0 ? 99 : indiceA) - (indiceB < 0 ? 99 : indiceB);
            }
            return a.localeCompare(b, 'pt-BR');
        });

        DOM.filtroStatus.replaceChildren(new Option('Todos os status', ''));
        todosStatus.forEach(status => DOM.filtroStatus.add(new Option(status, status)));
        DOM.filtroStatus.value = todosStatus.includes(valorSelecionado) ? valorSelecionado : '';
    }

    // Aplica os filtros de pesquisa, status, prioridade e prazo.
    function filtrarTarefas() {
        const termo = DOM.pesquisa.value.trim().toLocaleLowerCase('pt-BR');
        const statusEscolhido = DOM.filtroStatus.value;
        const prioridadeEscolhida = DOM.filtroPrioridade.value;
        const prazoEscolhido = DOM.filtroPrazo.value;
        const hoje = dataLocalISO();
        const limite7Dias = somarDias(hoje, 7);

        return tarefas.filter(tarefa => {
            const textoBusca = [tarefa.title, tarefa.description, tarefa.responsible, tarefa.priority, tarefa.status]
                .join(' ').toLocaleLowerCase('pt-BR');

            if (termo && !textoBusca.includes(termo)) return false;
            if (statusEscolhido && tarefa.status !== statusEscolhido) return false;
            if (prioridadeEscolhida && tarefa.priority !== prioridadeEscolhida) return false;

            if (prazoEscolhido === 'atrasadas' && !tarefaAtrasada(tarefa)) return false;
            if (prazoEscolhido === 'hoje' && (tarefa.dueDate !== hoje || tarefaConcluida(tarefa))) return false;
            if (prazoEscolhido === 'proximos7' && (!tarefa.dueDate || tarefa.dueDate <= hoje || tarefa.dueDate > limite7Dias || tarefaConcluida(tarefa))) return false;
            if (prazoEscolhido === 'noprazo' && (!tarefa.dueDate || tarefa.dueDate < hoje || tarefaConcluida(tarefa))) return false;
            if (prazoEscolhido === 'sem-prazo' && tarefa.dueDate) return false;

            return true;
        });
    }

    // Ordena a cópia filtrada para não alterar a lista original guardada no navegador.
    function ordenarTarefas(lista) {
        const criterio = DOM.ordenacao.value;
        const copia = [...lista];

        copia.sort((a, b) => {
            let comparacao = 0;

            if (criterio === 'prazo') {
                if (!a.dueDate && b.dueDate) return 1;
                if (a.dueDate && !b.dueDate) return -1;
                comparacao = (a.dueDate || '').localeCompare(b.dueDate || '');
            } else if (criterio === 'prioridade') {
                comparacao = ORDEM_PRIORIDADE.indexOf(a.priority) - ORDEM_PRIORIDADE.indexOf(b.priority);
            } else if (criterio === 'status') {
                const indiceA = ORDEM_STATUS.indexOf(a.status);
                const indiceB = ORDEM_STATUS.indexOf(b.status);
                comparacao = (indiceA < 0 ? 99 : indiceA) - (indiceB < 0 ? 99 : indiceB);
                if (comparacao === 0) comparacao = a.status.localeCompare(b.status, 'pt-BR');
            } else if (criterio === 'responsavel') {
                const responsavelA = a.responsible || '\uffff';
                const responsavelB = b.responsible || '\uffff';
                comparacao = responsavelA.localeCompare(responsavelB, 'pt-BR');
            }

            return comparacao || a.title.localeCompare(b.title, 'pt-BR');
        });

        return copia;
    }

    // Cria um elemento de texto com segurança, evitando inserir conteúdo das tarefas como HTML.
    function criarElemento(tag, classe, texto) {
        const elemento = document.createElement(tag);
        if (classe) elemento.className = classe;
        if (texto !== undefined) elemento.textContent = texto;
        return elemento;
    }

    function classeStatus(status) {
        const normalizado = status.toLocaleLowerCase('pt-BR');
        if (normalizado === 'documentos') return 'status-documentos';
        if (normalizado === 'a fazer') return 'status-a-fazer';
        if (normalizado === 'pendente') return 'status-pendente';
        if (normalizado === 'fazendo') return 'status-fazendo';
        if (normalizado === 'em andamento') return 'status-em-andamento';
        if (['concluído', 'concluída', 'concluido', 'concluida'].includes(normalizado)) return 'status-concluido';
        return 'status-generico';
    }

    function classePrioridade(prioridade) {
        return {
            'Baixa': 'priority-baixa',
            'Média': 'priority-media',
            'Alta': 'priority-alta',
            'Urgente': 'priority-urgente'
        }[prioridade] || 'priority-media';
    }

    // Preenche uma linha da tabela com título, responsável, prioridade, status e prazo.
    function criarLinhaTarefa(tarefa) {
        const linha = document.createElement('tr');
        const celulaTitulo = document.createElement('td');
        const titulo = criarElemento('span', 'task-title', tarefa.title);
        celulaTitulo.append(titulo);

        if (tarefa.description) {
            celulaTitulo.append(criarElemento('span', 'task-description', tarefa.description));
        }

        // Identifica de qual quadro veio o cartão exibido no dashboard.
        if (tarefa.boardName) {
            const origemQuadro = criarElemento('span', 'muted-value', `Quadro: ${tarefa.boardName}`);
            origemQuadro.style.display = 'block';
            origemQuadro.style.marginTop = '8px';
            origemQuadro.style.fontSize = '10px';
            origemQuadro.style.fontStyle = 'normal';
            celulaTitulo.append(origemQuadro);
        }

        linha.append(celulaTitulo);

        const celulaResponsavel = document.createElement('td');
        celulaResponsavel.append(criarElemento(
            'span', tarefa.responsible ? 'responsible-name' : 'muted-value', tarefa.responsible || 'Não definido'
        ));
        linha.append(celulaResponsavel);

        const celulaPrioridade = document.createElement('td');
        celulaPrioridade.append(criarElemento('span', `badge ${classePrioridade(tarefa.priority)}`, tarefa.priority));
        linha.append(celulaPrioridade);

        const celulaStatus = document.createElement('td');
        celulaStatus.append(criarElemento('span', `badge ${classeStatus(tarefa.status)}`, tarefa.status));
        linha.append(celulaStatus);

        const celulaPrazo = document.createElement('td');
        if (!tarefa.dueDate) {
            celulaPrazo.append(criarElemento('span', 'muted-value', 'Sem prazo'));
        } else {
            const vencido = tarefaAtrasada(tarefa);
            const venceHoje = tarefa.dueDate === dataLocalISO() && !tarefaConcluida(tarefa);
            const classeData = vencido ? 'due-date overdue' : (venceHoje ? 'due-date today' : 'due-date');
            const data = criarElemento('span', classeData);
            const icone = document.createElement('i');
            icone.className = vencido ? 'fa-solid fa-triangle-exclamation' : 'fa-regular fa-calendar';
            icone.setAttribute('aria-hidden', 'true');
            data.append(icone, document.createTextNode(formatarData(tarefa.dueDate)));
            if (vencido) data.append(document.createTextNode(' · Atrasada'));
            celulaPrazo.append(data);
        }
        linha.append(celulaPrazo);
        return linha;
    }

    // Atualiza a tabela e a mensagem de lista vazia conforme os filtros ativos.
    function renderizarLista() {
        const resultado = ordenarTarefas(filtrarTarefas());
        DOM.lista.replaceChildren();
        resultado.forEach(tarefa => DOM.lista.append(criarLinhaTarefa(tarefa)));

        DOM.contadorResultados.textContent = `${resultado.length} ${resultado.length === 1 ? 'tarefa encontrada' : 'tarefas encontradas'}`;
        DOM.estadoVazio.hidden = resultado.length > 0;

        if (erroLeitura) {
            DOM.tituloVazio.textContent = 'Não foi possível ler as tarefas';
            DOM.mensagemVazia.textContent = 'O conteúdo salvo do Kanban está inválido. Abra o quadro e verifique os dados salvos neste navegador.';
        } else if (tarefas.length === 0) {
            DOM.tituloVazio.textContent = 'Nenhuma tarefa cadastrada';
            DOM.mensagemVazia.textContent = 'Crie tarefas em qualquer quadro Kanban. Elas aparecerão aqui assim que forem salvas neste navegador.';
        } else {
            DOM.tituloVazio.textContent = 'Nenhuma tarefa encontrada';
            DOM.mensagemVazia.textContent = 'Não há tarefas que correspondam aos filtros atuais. Tente ajustar os filtros ou limpar a pesquisa.';
        }
    }

    // Atualiza os dados, os indicadores, as opções e a tabela.
    function atualizarDashboard() {
        tarefas = carregarTarefas();
        atualizarOpcoesStatus();
        atualizarIndicadores();
        renderizarLista();
        DOM.syncStatus.innerHTML = erroLeitura
            ? '<i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> Erro ao ler dados'
            : '<i class="fa-solid fa-circle-check" aria-hidden="true"></i> Dados de todos os quadros';
    }

    // Liga os filtros aos elementos da página.
    DOM.pesquisa.addEventListener('input', renderizarLista);
    DOM.filtroStatus.addEventListener('change', renderizarLista);
    DOM.filtroPrioridade.addEventListener('change', renderizarLista);
    DOM.filtroPrazo.addEventListener('change', renderizarLista);
    DOM.ordenacao.addEventListener('change', renderizarLista);
    DOM.atualizar.addEventListener('click', atualizarDashboard);

    DOM.limparFiltros.addEventListener('click', () => {
        DOM.pesquisa.value = '';
        DOM.filtroStatus.value = '';
        DOM.filtroPrioridade.value = '';
        DOM.filtroPrazo.value = '';
        DOM.ordenacao.value = 'prazo';
        renderizarLista();
    });

    // Atualiza o dashboard quando qualquer quadro for alterado em outra aba.
    window.addEventListener('storage', evento => {
        const alterouTarefas = evento.key === CHAVE_TAREFAS ||
            (evento.key && evento.key.startsWith(PREFIXO_CHAVES_TAREFAS));
        const alterouQuadros = evento.key === CHAVE_QUADROS_PERSONALIZADOS;

        if (alterouTarefas || alterouQuadros || evento.key === null) {
            atualizarDashboard();
        }
    });

    // Atualiza também quando a pessoa retorna a esta aba depois de usar o Kanban.
    window.addEventListener('focus', atualizarDashboard);

    atualizarDashboard();
});