/* TeamWave - funcionamento do quadro Kanban (JavaScript puro) */
document.addEventListener('DOMContentLoaded', () => {
    // ================================================================
    // 1. CONFIGURAÇÕES E ELEMENTOS DA INTERFACE
    // ================================================================
    // Cada quadro recebe uma chave própria. O quadro TeamWave mantém a chave
    // antiga para preservar as tarefas já cadastradas antes desta atualização.
    const parametros = new URLSearchParams(window.location.search);
    const ID_QUADRO = (parametros.get('quadro') || 'team-wave').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80) || 'team-wave';
    const CHAVE_QUADRO_ATUAL = 'teamwave_quadro_atual_v1';
    const CHAVE_QUADROS_PERSONALIZADOS = 'teamwave_quadros_personalizados_v1';
    const CHAVE_USUARIOS = 'teamwave_usuarios';
    const QUADRO_LEGADO = ID_QUADRO === 'team-wave';
    const CHAVE_ARMAZENAMENTO = QUADRO_LEGADO
        ? 'teamwave_kanban_tarefas_v1'
        : `teamwave_kanban_tarefas_v1_${ID_QUADRO}`;
    const CHAVE_FAVORITO = QUADRO_LEGADO
        ? 'teamwave_kanban_favorito_v1'
        : `teamwave_kanban_favorito_v1_${ID_QUADRO}`;
    const BANCO_ANEXOS = 'teamwave_kanban_arquivos_db';
    const LIMITE_ARQUIVO = 25 * 1024 * 1024; // 25 MB por arquivo
    const LIMITE_ANEXOS_TAREFA = 10;

    const colunas = Array.from(document.querySelectorAll('.column[data-status]'));
    const statusPermitidos = colunas.map(coluna => coluna.dataset.status);
    const campoPesquisa = document.getElementById('search-input');
    const modal = document.getElementById('task-modal');
    const formulario = document.getElementById('task-form');
    const campoId = document.getElementById('task-id');
    const campoTitulo = document.getElementById('task-title');
    const campoDescricao = document.getElementById('task-description');
    const campoResponsavel = document.getElementById('task-responsible');
    const campoPrioridade = document.getElementById('task-priority');
    const campoPrazo = document.getElementById('task-due-date');
    const campoStatus = document.getElementById('task-status');
    const campoAnexos = document.getElementById('task-attachments');
    const listaAnexos = document.getElementById('attachment-list');
    const tituloModal = document.getElementById('modal-title');
    const arquivoImportacao = document.getElementById('import-file');
    const areaKanban = document.querySelector('.board-container');
    const nomeQuadro = document.getElementById('board-name');
    const areaMembrosEquipe = document.querySelector('.team-members');
    const botaoMembrosEquipe = document.getElementById('open-team-members');
    const painelMembrosEquipe = document.getElementById('team-members-panel');
    const listaMembrosEquipe = document.getElementById('team-members-list');
    const mensagemMembrosEquipe = document.getElementById('team-members-message');
    const botaoSeletorQuadros = document.getElementById('open-board-selector');
    const modalSeletorQuadros = document.getElementById('board-selector-modal');
    const gradeSeletorQuadros = document.getElementById('board-choices');
    const botaoFecharSeletor = document.getElementById('close-board-selector');
    const modalDetalhesTarefa = document.getElementById('task-details-modal');
    const tituloDetalhesTarefa = document.getElementById('task-details-title');
    const statusDetalhesTarefa = document.getElementById('task-details-status');
    const campoDescricaoDetalhes = document.getElementById('task-details-description');
    const campoArquivosDetalhes = document.getElementById('task-details-files');
    const botaoAdicionarArquivosDetalhes = document.getElementById('open-task-details-files');
    const listaAnexosDetalhes = document.getElementById('task-details-attachments');
    const formularioChecklistDetalhes = document.getElementById('task-checklist-form');
    const campoNovoChecklistDetalhes = document.getElementById('task-checklist-input');
    const listaChecklistDetalhes = document.getElementById('task-checklist');
    const listaComentariosDetalhes = document.getElementById('task-comments-list');
    const formularioComentarioDetalhes = document.getElementById('task-comment-form');
    const campoComentarioDetalhes = document.getElementById('task-comment-input');
    const mensagemDetalhesTarefa = document.getElementById('task-details-message');
    const botaoFecharDetalhesTarefa = document.getElementById('close-task-details');

    function renderizarMembrosEquipe() {
        listaMembrosEquipe.replaceChildren();
        mensagemMembrosEquipe.hidden = true;
        mensagemMembrosEquipe.textContent = '';

        try {
            const dados = JSON.parse(localStorage.getItem(CHAVE_USUARIOS) || '[]');
            if (!Array.isArray(dados)) {
                throw new Error('A lista de pessoas cadastradas não é válida.');
            }

            const nomes = dados
                .filter(usuario => usuario && typeof usuario.nome === 'string' && usuario.nome.trim())
                .map(usuario => usuario.nome.trim())
                .sort((a, b) => a.localeCompare(b, 'pt-BR'));

            if (nomes.length === 0) {
                mensagemMembrosEquipe.textContent = 'Nenhuma pessoa cadastrada foi encontrada.';
                mensagemMembrosEquipe.hidden = false;
                return;
            }

            nomes.forEach(nome => {
                const item = document.createElement('li');
                item.textContent = nome;
                listaMembrosEquipe.append(item);
            });
        } catch (erro) {
            console.error('Não foi possível carregar as pessoas cadastradas:', erro);
            mensagemMembrosEquipe.textContent = 'Não foi possível carregar a lista de pessoas cadastradas.';
            mensagemMembrosEquipe.hidden = false;
        }
    }

    function fecharPainelMembrosEquipe() {
        painelMembrosEquipe.hidden = true;
        botaoMembrosEquipe.setAttribute('aria-expanded', 'false');
    }

    botaoMembrosEquipe.addEventListener('click', () => {
        const abrir = painelMembrosEquipe.hidden;
        if (abrir) renderizarMembrosEquipe();
        painelMembrosEquipe.hidden = !abrir;
        botaoMembrosEquipe.setAttribute('aria-expanded', String(abrir));
    });

    document.addEventListener('click', evento => {
        if (!areaMembrosEquipe.contains(evento.target)) fecharPainelMembrosEquipe();
    });

    document.addEventListener('keydown', evento => {
        if (evento.key === 'Escape' && !painelMembrosEquipe.hidden) {
            fecharPainelMembrosEquipe();
            botaoMembrosEquipe.focus();
        }
    });

    window.addEventListener('storage', evento => {
        if (evento.key === CHAVE_USUARIOS || evento.key === null) renderizarMembrosEquipe();
    });

    const QUADROS_PREDEFINIDOS = [
        { id: 'team-wave', name: 'TeamWave', type: 'color', value: '#2563eb' },
        { id: 'estrategia', name: 'Estratégia', type: 'color', value: '#7c3aed' },
        { id: 'operacoes', name: 'Operações', type: 'color', value: '#ea580c' },
        { id: 'marketing', name: 'Marketing', type: 'color', value: '#0f766e' },
        { id: 'projeto', name: 'Projeto', type: 'color', value: '#be123c' },
        { id: 'reunioes', name: 'Reuniões', type: 'color', value: '#334155' },
        { id: 'design', name: 'Design', type: 'color', value: '#0891b2' },
        { id: 'planejamento', name: 'Planejamento', type: 'color', value: '#4d7c0f' },
        { id: 'natureza', name: 'Natureza', type: 'image', value: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=85' },
        { id: 'montanhas', name: 'Montanhas', type: 'image', value: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1600&q=85' },
        { id: 'praia', name: 'Praia', type: 'image', value: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1600&q=85' },
        { id: 'amanhecer', name: 'Amanhecer', type: 'image', value: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&w=1600&q=85' },
        { id: 'ceu-estrelado', name: 'Céu estrelado', type: 'image', value: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1600&q=85' }
    ];

    function obterEnderecoImagemPermitido(valor) {
        if (typeof valor !== 'string') return '';
        if (/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(valor)) return valor;

        try {
            const endereco = new URL(valor);
            return endereco.protocol === 'https:' || endereco.protocol === 'http:' ? endereco.href : '';
        } catch {
            return '';
        }
    }

    // Recupera os dados que a página Quadros salvou antes de abrir este Kanban.
    function carregarConfiguracaoQuadro() {
        try {
            const salvo = JSON.parse(localStorage.getItem(CHAVE_QUADRO_ATUAL) || 'null');
            if (salvo && salvo.id === ID_QUADRO) return salvo;
        } catch (erro) {
            console.warn('Não foi possível ler a aparência do quadro:', erro);
        }

        return { id: ID_QUADRO, name: ID_QUADRO === 'team-wave' ? 'TeamWave' : ID_QUADRO, type: 'color', value: '#2563eb' };
    }

    const quadroAtual = carregarConfiguracaoQuadro();

    function aplicarConfiguracaoQuadro() {
        const nome = String(quadroAtual.name || 'TeamWave').trim().slice(0, 45) || 'TeamWave';
        nomeQuadro.textContent = nome;
        document.title = `TeamWave | ${nome}`;

        if (quadroAtual.type === 'image') {
            try {
                const enderecoImagem = obterEnderecoImagemPermitido(quadroAtual.value);
                if (!enderecoImagem) throw new Error('Endereço de imagem não permitido.');

                areaKanban.style.backgroundColor = '#334155';
                areaKanban.style.backgroundImage = `linear-gradient(rgba(15, 23, 42, .28), rgba(15, 23, 42, .28)), url("${enderecoImagem}")`;
                areaKanban.style.backgroundPosition = 'center';
                areaKanban.style.backgroundSize = 'cover';
                areaKanban.style.backgroundRepeat = 'no-repeat';
                areaKanban.classList.add('has-image-background');
                areaKanban.classList.remove('has-color-background');
            } catch (erro) {
                console.warn('A imagem de fundo não pôde ser aplicada:', erro);
            }
        } else {
            const cor = /^#[0-9a-fA-F]{6}$/.test(String(quadroAtual.value)) ? quadroAtual.value : '#2563eb';
            areaKanban.style.backgroundColor = cor;
            areaKanban.style.backgroundImage = 'none';
            areaKanban.classList.add('has-color-background');
            areaKanban.classList.remove('has-image-background');
        }
    }

    aplicarConfiguracaoQuadro();

    function carregarQuadrosDisponiveis() {
        try {
            const personalizados = JSON.parse(localStorage.getItem(CHAVE_QUADROS_PERSONALIZADOS) || '[]');
            if (!Array.isArray(personalizados)) {
                throw new Error('A lista de quadros personalizados não é válida.');
            }

            const validos = personalizados.filter(quadro => {
                if (
                    !quadro ||
                    typeof quadro.id !== 'string' ||
                    !/^[a-zA-Z0-9_-]{1,80}$/.test(quadro.id) ||
                    typeof quadro.name !== 'string' ||
                    !quadro.name.trim() ||
                    (quadro.type !== 'color' && quadro.type !== 'image') ||
                    typeof quadro.value !== 'string'
                ) {
                    return false;
                }

                if (quadro.type === 'color') {
                    return /^#[0-9a-fA-F]{6}$/.test(quadro.value);
                }

                return Boolean(obterEnderecoImagemPermitido(quadro.value));
            }).map(quadro => ({
                id: quadro.id,
                name: quadro.name.trim().slice(0, 45),
                type: quadro.type,
                value: quadro.value
            }));

            return [...QUADROS_PREDEFINIDOS, ...validos];
        } catch (erro) {
            console.error('Não foi possível carregar os quadros disponíveis:', erro);
            return QUADROS_PREDEFINIDOS;
        }
    }

    function renderizarSeletorQuadros() {
        gradeSeletorQuadros.replaceChildren();

        carregarQuadrosDisponiveis().forEach(quadro => {
            const opcao = document.createElement('button');
            opcao.className = 'board-choice';
            opcao.type = 'button';
            opcao.setAttribute('aria-pressed', String(quadro.id === ID_QUADRO));
            opcao.setAttribute('aria-label', `Abrir quadro ${quadro.name}`);

            const capa = document.createElement('span');
            capa.className = 'board-choice-cover';

            const tipo = document.createElement('span');
            tipo.className = 'board-choice-type';
            tipo.textContent = quadro.type === 'image' ? 'Imagem' : 'Cor';

            if (quadro.type === 'image') {
                capa.style.backgroundColor = '#334155';
                capa.style.backgroundImage = `linear-gradient(rgba(15, 23, 42, .20), rgba(15, 23, 42, .20)), url("${obterEnderecoImagemPermitido(quadro.value)}")`;
            } else {
                capa.style.background = quadro.value;
            }

            const nome = document.createElement('span');
            nome.className = 'board-choice-name';
            nome.textContent = quadro.name;

            opcao.append(capa, nome, tipo);
            opcao.addEventListener('click', () => selecionarQuadro(quadro));
            gradeSeletorQuadros.append(opcao);
        });
    }

    function abrirSeletorQuadros() {
        renderizarSeletorQuadros();
        modalSeletorQuadros.hidden = false;
        botaoSeletorQuadros.setAttribute('aria-expanded', 'true');
        document.body.classList.add('modal-open');
        const primeiraOpcao = gradeSeletorQuadros.querySelector('.board-choice');
        (primeiraOpcao || botaoFecharSeletor).focus();
    }

    function fecharSeletorQuadros() {
        modalSeletorQuadros.hidden = true;
        botaoSeletorQuadros.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('modal-open');
        botaoSeletorQuadros.focus();
    }

    function selecionarQuadro(quadro) {
        try {
            localStorage.setItem(CHAVE_QUADRO_ATUAL, JSON.stringify(quadro));
        } catch (erro) {
            console.error('Não foi possível salvar o quadro selecionado:', erro);
            alert('Não foi possível salvar a seleção do quadro neste navegador.');
            return;
        }

        const enderecoKanban = new URL(window.location.href);
        enderecoKanban.searchParams.set('quadro', quadro.id);
        window.location.assign(enderecoKanban.href);
    }

    let anexosMantidos = [];
    let novosArquivosSelecionados = [];
    let tarefas = carregarTarefas();
    let idArrastado = null;
    let idTarefaAberta = null;
    let cartaoFoiArrastado = false;

    // ================================================================
    // 2. ARMAZENAMENTO DE ANEXOS (INDEXEDDB)
    // Os dados das tarefas ficam no localStorage; os arquivos ficam no IndexedDB.
    // ================================================================
    const bancoAnexos = abrirBancoAnexos().catch(erro => {
        console.error('Não foi possível inicializar o armazenamento de anexos:', erro);
        return null;
    });

    // Abre o banco e cria a coleção de arquivos quando necessário.
    function abrirBancoAnexos() {
        return new Promise((resolve, reject) => {
            if (!('indexedDB' in window)) {
                reject(new Error('Este navegador não oferece armazenamento local de arquivos.'));
                return;
            }

            const pedido = window.indexedDB.open(BANCO_ANEXOS, 1);

            pedido.onupgradeneeded = () => {
                const banco = pedido.result;
                if (!banco.objectStoreNames.contains('arquivos')) {
                    banco.createObjectStore('arquivos', { keyPath: 'id' });
                }
            };

            pedido.onsuccess = () => resolve(pedido.result);
            pedido.onerror = () => reject(pedido.error || new Error('Falha ao abrir o armazenamento de anexos.'));
        });
    }

    // Retorna a conexão pronta ou informa que o banco não está disponível.
    async function obterBancoAnexos() {
        const banco = await bancoAnexos;
        if (!banco) throw new Error('Não foi possível acessar o armazenamento de arquivos deste navegador.');
        return banco;
    }

    // Salva o conteúdo binário e os metadados de um arquivo.
    function armazenarAnexo(id, arquivo) {
        return obterBancoAnexos().then(banco => new Promise((resolve, reject) => {
            const transacao = banco.transaction('arquivos', 'readwrite');

            transacao.objectStore('arquivos').put({
                id,
                name: arquivo.name,
                type: arquivo.type || 'application/octet-stream',
                size: arquivo.size,
                blob: arquivo
            });

            transacao.oncomplete = () => resolve();
            transacao.onerror = () => reject(transacao.error || new Error('Não foi possível salvar um arquivo anexado.'));
            transacao.onabort = () => reject(transacao.error || new Error('O salvamento do arquivo foi cancelado.'));
        }));
    }

    // Busca um arquivo pelo ID salvo nos dados da tarefa.
    function buscarAnexo(id) {
        return obterBancoAnexos().then(banco => new Promise((resolve, reject) => {
            const transacao = banco.transaction('arquivos', 'readonly');
            const pedido = transacao.objectStore('arquivos').get(id);

            pedido.onsuccess = () => resolve(pedido.result || null);
            pedido.onerror = () => reject(pedido.error || new Error('Não foi possível ler o arquivo anexado.'));
        }));
    }

    // Remove o conteúdo de um anexo do banco local.
    function excluirAnexoDoBanco(id) {
        return obterBancoAnexos().then(banco => new Promise((resolve, reject) => {
            const transacao = banco.transaction('arquivos', 'readwrite');
            transacao.objectStore('arquivos').delete(id);

            transacao.oncomplete = () => resolve();
            transacao.onerror = () => reject(transacao.error || new Error('Não foi possível remover o arquivo anexado.'));
        }));
    }

    // Gera IDs únicos para tarefas e anexos.
    function gerarId() {
        if (window.crypto && typeof window.crypto.randomUUID === 'function') {
            return window.crypto.randomUUID();
        }

        return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    }

    // Mantém nos dados da tarefa apenas os metadados dos anexos.
    function metadadosAnexos(anexos) {
        if (!Array.isArray(anexos)) return [];

        return anexos.filter(anexo => anexo && typeof anexo.name === 'string' && anexo.name.trim())
            .map(anexo => ({
                id: String(anexo.id || gerarId()),
                name: anexo.name.trim().slice(0, 255),
                type: String(anexo.type || 'application/octet-stream'),
                size: Math.max(0, Number(anexo.size) || 0)
            }));
    }

    // ================================================================
    // 3. LEITURA, VALIDAÇÃO E SALVAMENTO DAS TAREFAS
    // ================================================================

    function carregarTarefas() {
        try {
            const dados = localStorage.getItem(CHAVE_ARMAZENAMENTO);
            if (!dados) return [];

            const tarefasSalvas = JSON.parse(dados);
            if (!Array.isArray(tarefasSalvas)) return [];

            return tarefasSalvas
                .filter(tarefa => tarefa && typeof tarefa.title === 'string' && tarefa.title.trim())
                .map(tarefa => ({
                    id: String(tarefa.id || gerarId()),
                    title: String(tarefa.title).trim(),
                    description: String(tarefa.description || ''),
                    detailsDescription: String(tarefa.detailsDescription || ''),
                    responsible: String(tarefa.responsible || ''),
                    priority: ['Baixa', 'Média', 'Alta', 'Urgente'].includes(tarefa.priority) ? tarefa.priority : 'Média',
                    dueDate: validarData(tarefa.dueDate),
                    status: statusPermitidos.includes(tarefa.status) ? tarefa.status : 'A Fazer',
                    attachments: metadadosAnexos(tarefa.attachments),
                    detailsAttachments: metadadosAnexos(tarefa.detailsAttachments),
                    checklist: Array.isArray(tarefa.checklist)
                        ? tarefa.checklist.filter(item => item && typeof item.text === 'string' && item.text.trim())
                            .map(item => ({
                                id: String(item.id || gerarId()),
                                text: item.text.trim().slice(0, 160),
                                completed: Boolean(item.completed)
                            }))
                        : [],
                    comments: Array.isArray(tarefa.comments)
                        ? tarefa.comments.filter(comment => comment && typeof comment.text === 'string' && comment.text.trim())
                            .map(comment => ({
                                id: String(comment.id || gerarId()),
                                text: comment.text.trim().slice(0, 1000),
                                author: String(comment.author || 'Pessoa').slice(0, 100),
                                createdAt: comment.createdAt || new Date().toISOString()
                            }))
                        : [],
                    createdAt: tarefa.createdAt || new Date().toISOString(),
                    updatedAt: tarefa.updatedAt || new Date().toISOString()
                }));
        } catch (erro) {
            console.error('Não foi possível carregar as tarefas salvas:', erro);
            alert('Não foi possível ler as tarefas salvas. O quadro será aberto vazio.');
            return [];
        }
    }

    // Persiste a lista e permite desfazer a operação em caso de erro.
    function salvarTarefas() {
        try {
            localStorage.setItem(CHAVE_ARMAZENAMENTO, JSON.stringify(tarefas));
            return true;
        } catch (erro) {
            console.error('Não foi possível salvar as tarefas:', erro);
            alert('Não foi possível salvar no navegador. Verifique o espaço disponível e as permissões de armazenamento.');
            return false;
        }
    }

    // Valida uma data no formato AAAA-MM-DD.
    function validarData(valor) {
        if (typeof valor !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(valor)) return '';

        const data = new Date(`${valor}T12:00:00`);
        return Number.isNaN(data.getTime()) ? '' : valor;
    }

    // Padroniza textos para que a pesquisa não diferencie maiúsculas de minúsculas.
    function normalizarTexto(valor) {
        return String(valor || '').toLocaleLowerCase('pt-BR').trim();
    }

    function formatarData(valor) {
        if (!valor) return '';

        const partes = valor.split('-');
        if (partes.length !== 3) return valor;

        return `${partes[2]}/${partes[1]}/${partes[0]}`;
    }

    function formatarTamanho(bytes) {
        if (!bytes) return '0 KB';
        if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;

        return `${(bytes / (1024 * 1024)).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} MB`;
    }

    // Verifica se uma tarefa tem prazo anterior ao dia atual.
    function prazoAtrasado(valor) {
        if (!valor) return false;

        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);

        const prazo = new Date(`${valor}T12:00:00`);
        prazo.setHours(0, 0, 0, 0);

        return prazo < hoje;
    }

    // ================================================================
    // 4. ELEMENTOS E ANEXOS DO FORMULÁRIO
    // ================================================================

    function criarElemento(tag, classe, texto) {
        const elemento = document.createElement(tag);
        if (classe) elemento.className = classe;
        if (texto !== undefined) elemento.textContent = texto;

        return elemento;
    }

    function criarBotaoAcao(classe, titulo, icone, rotulo) {
        const botao = document.createElement('button');
        botao.type = 'button';
        botao.className = classe;
        botao.title = titulo;
        botao.setAttribute('aria-label', titulo);

        const simbolo = document.createElement('i');
        simbolo.className = icone;
        simbolo.setAttribute('aria-hidden', 'true');
        botao.append(simbolo);

        if (rotulo) botao.append(document.createTextNode(` ${rotulo}`));

        return botao;
    }

    // Monta uma linha de anexo, incluindo o botão de remoção quando necessário.
    function criarLinhaAnexo(nome, tamanho, textoEstado, aoRemover) {
        const linha = criarElemento('div', 'attachment-row');
        const icone = document.createElement('i');
        icone.className = 'fa-solid fa-paperclip';
        icone.setAttribute('aria-hidden', 'true');

        const envoltorio = criarElemento('div', 'attachment-name-wrap');
        envoltorio.append(
            criarElemento('span', 'attachment-name', nome),
            criarElemento('span', 'attachment-meta', `${formatarTamanho(tamanho)} · ${textoEstado}`)
        );

        linha.append(icone, envoltorio);

        if (aoRemover) {
            const remover = criarBotaoAcao('attachment-remove', 'Remover arquivo', 'fa-solid fa-xmark', 'Remover');
            remover.addEventListener('click', aoRemover);
            linha.append(remover);
        }

        return linha;
    }

    // Atualiza a lista visual de anexos antigos e arquivos selecionados.
    function renderizarAnexosModal() {
        listaAnexos.replaceChildren();

        anexosMantidos.forEach(anexo => {
            listaAnexos.append(criarLinhaAnexo(anexo.name, anexo.size, 'Já anexado', () => {
                anexosMantidos = anexosMantidos.filter(item => item.id !== anexo.id);
                renderizarAnexosModal();
            }));
        });

        novosArquivosSelecionados.forEach((arquivo, indice) => {
            listaAnexos.append(criarLinhaAnexo(arquivo.name, arquivo.size, 'Será anexado ao salvar', () => {
                novosArquivosSelecionados = novosArquivosSelecionados.filter((item, posicao) => posicao !== indice);
                renderizarAnexosModal();
            }));
        });

        if (listaAnexos.childElementCount === 0) {
            listaAnexos.append(criarElemento('p', 'attachment-meta', 'Nenhum arquivo anexado.'));
        }
    }

    // ================================================================
    // 5. CARTÕES, COLUNAS E PESQUISA
    // ================================================================

    // Monta o cartão de uma tarefa e configura ações, anexos e arrastar/soltar.
    function criarCartao(tarefa) {
        const cartao = criarElemento('article', 'card');
        cartao.dataset.id = tarefa.id;
        cartao.draggable = true;
        cartao.tabIndex = 0;
        cartao.setAttribute('aria-label', `Tarefa: ${tarefa.title}. Abra os detalhes ou arraste para outra coluna.`);

        const topo = criarElemento('div', 'card-top');
        const prioridade = criarElemento('span', `priority-badge priority-${classePrioridade(tarefa.priority)}`, tarefa.priority);
        topo.append(prioridade);

        const acoes = criarElemento('div', 'card-actions');
        const botaoEditar = criarBotaoAcao('card-action edit-task', 'Editar tarefa', 'fa-solid fa-pen', '');
        const botaoExcluir = criarBotaoAcao('card-action delete-task', 'Excluir tarefa', 'fa-solid fa-trash', '');

        botaoEditar.addEventListener('click', () => abrirModal(tarefa.status, tarefa));
        botaoExcluir.addEventListener('click', () => excluirTarefa(tarefa.id));

        acoes.append(botaoEditar, botaoExcluir);
        topo.append(acoes);
        cartao.append(topo);

        cartao.append(criarElemento('h3', 'card-title', tarefa.title));

        if (tarefa.description) {
            cartao.append(criarElemento('p', 'card-description', tarefa.description));
        }

        if (Array.isArray(tarefa.attachments) && tarefa.attachments.length) {
            const areaAnexos = criarElemento('div', 'card-attachments');

            tarefa.attachments.forEach(anexo => {
                const botaoAnexo = criarBotaoAcao('card-attachment', `Baixar anexo: ${anexo.name}`, 'fa-solid fa-paperclip', anexo.name);

                botaoAnexo.addEventListener('click', evento => {
                    evento.stopPropagation();
                    baixarAnexo(anexo);
                });

                areaAnexos.append(botaoAnexo);
            });

            cartao.append(areaAnexos);
        }

        const detalhes = criarElemento('div', 'card-details');

        if (tarefa.responsible) {
            const responsavel = criarElemento('span', 'card-detail');
            responsavel.append(document.createElement('i'));
            responsavel.firstElementChild.className = 'fa-regular fa-user';
            responsavel.firstElementChild.setAttribute('aria-hidden', 'true');
            responsavel.append(document.createTextNode(` ${tarefa.responsible}`));
            detalhes.append(responsavel);
        }

        if (tarefa.dueDate) {
            const atrasado = prazoAtrasado(tarefa.dueDate) && tarefa.status !== 'Concluído';
            const prazo = criarElemento('span', `card-detail due-date${atrasado ? ' overdue' : ''}`);
            const iconePrazo = document.createElement('i');

            iconePrazo.className = atrasado ? 'fa-solid fa-triangle-exclamation' : 'fa-regular fa-calendar';
            iconePrazo.setAttribute('aria-hidden', 'true');

            prazo.append(iconePrazo, document.createTextNode(` ${formatarData(tarefa.dueDate)}${atrasado ? ' (atrasada)' : ''}`));
            detalhes.append(prazo);
        }

        if (detalhes.childElementCount) cartao.append(detalhes);

        cartao.addEventListener('click', evento => {
            if (cartaoFoiArrastado || evento.target.closest('button')) return;
            abrirDetalhesTarefa(tarefa.id);
        });

        cartao.addEventListener('keydown', evento => {
            if ((evento.key === 'Enter' || evento.key === ' ') && evento.target === cartao) {
                evento.preventDefault();
                abrirDetalhesTarefa(tarefa.id);
            }
        });

        // Registra o cartão que está sendo arrastado.
        cartao.addEventListener('dragstart', evento => {
            idArrastado = tarefa.id;
            cartaoFoiArrastado = true;
            cartao.classList.add('is-dragging');
            cartao.setAttribute('aria-grabbed', 'true');

            if (evento.dataTransfer) {
                evento.dataTransfer.effectAllowed = 'move';
                evento.dataTransfer.setData('text/plain', tarefa.id);
            }
        });

        cartao.addEventListener('dragend', () => {
            idArrastado = null;
            cartao.classList.remove('is-dragging');
            cartao.setAttribute('aria-grabbed', 'false');
            colunas.forEach(coluna => coluna.classList.remove('is-drag-over'));
            window.setTimeout(() => {
                cartaoFoiArrastado = false;
            }, 0);
        });

        return cartao;
    }

    function classePrioridade(prioridade) {
        return ({ 'Baixa': 'baixa', 'Média': 'media', 'Alta': 'alta', 'Urgente': 'urgente' })[prioridade] || 'media';
    }

    // Redesenha as colunas de acordo com o status e o texto pesquisado.
    function renderizarQuadro() {
        const termo = normalizarTexto(campoPesquisa.value);

        colunas.forEach(coluna => {
            const status = coluna.dataset.status;
            const areaCartoes = coluna.querySelector('.cards-container');
            const tarefasDaColuna = tarefas.filter(tarefa => tarefa.status === status);

            const tarefasVisiveis = tarefasDaColuna.filter(tarefa => {
                const nomesAnexos = (tarefa.attachments || []).map(anexo => anexo.name).join(' ');
                const texto = normalizarTexto(`${tarefa.title} ${tarefa.description} ${tarefa.responsible} ${tarefa.priority} ${nomesAnexos}`);

                return texto.includes(termo);
            });

            areaCartoes.replaceChildren();

            coluna.querySelector('.column-count').textContent = termo
                ? `${tarefasVisiveis.length}/${tarefasDaColuna.length}`
                : String(tarefasDaColuna.length);

            if (tarefasVisiveis.length === 0 && termo) {
                areaCartoes.append(criarElemento('p', 'empty-column-message', 'Nenhuma tarefa encontrada.'));
            } else {
                tarefasVisiveis.forEach(tarefa => areaCartoes.append(criarCartao(tarefa)));
            }
        });
    }

    function abrirDetalhesTarefa(id) {
        const tarefa = tarefas.find(item => item.id === id);
        if (!tarefa) return;

        idTarefaAberta = id;
        tituloDetalhesTarefa.textContent = tarefa.title;
        statusDetalhesTarefa.textContent = tarefa.status;
        campoDescricaoDetalhes.value = tarefa.detailsDescription || '';
        mensagemDetalhesTarefa.textContent = '';
        campoComentarioDetalhes.value = '';
        campoNovoChecklistDetalhes.value = '';
        renderizarAnexosDetalhes(tarefa);
        renderizarChecklistDetalhes(tarefa);
        renderizarComentariosDetalhes(tarefa);
        modalDetalhesTarefa.hidden = false;
        document.body.classList.add('modal-open');
        campoDescricaoDetalhes.focus();
    }

    function fecharDetalhesTarefa() {
        if (!salvarDescricaoDetalhes()) return;

        const idFechado = idTarefaAberta;
        idTarefaAberta = null;
        modalDetalhesTarefa.hidden = true;
        document.body.classList.remove('modal-open');
        Array.from(document.querySelectorAll('.card')).find(cartao => cartao.dataset.id === idFechado)?.focus();
    }

    function tarefaAbertaDetalhes() {
        return tarefas.find(item => item.id === idTarefaAberta) || null;
    }

    function persistirAlteracaoDetalhes(tarefa, alterar) {
        const anterior = JSON.parse(JSON.stringify(tarefa));
        alterar(tarefa);
        tarefa.updatedAt = new Date().toISOString();

        if (!salvarTarefas()) {
            Object.assign(tarefa, anterior);
            return false;
        }

        renderizarQuadro();
        return true;
    }

    function renderizarAnexosDetalhes(tarefa) {
        listaAnexosDetalhes.replaceChildren();

        if (!tarefa.detailsAttachments.length) {
            listaAnexosDetalhes.append(criarElemento('p', 'details-empty', 'Nenhum anexo adicionado.'));
            return;
        }

        tarefa.detailsAttachments.forEach(anexo => {
            const linha = criarElemento('div', 'details-attachment-row');
            const baixar = criarBotaoAcao('details-attachment', `Baixar anexo: ${anexo.name}`, 'fa-solid fa-download', anexo.name);
            baixar.addEventListener('click', () => baixarAnexo(anexo));
            const remover = criarBotaoAcao('details-attachment-remove', `Remover anexo: ${anexo.name}`, 'fa-solid fa-trash', 'Remover');
            remover.dataset.id = anexo.id;
            linha.append(baixar, remover);
            listaAnexosDetalhes.append(linha);
        });
    }

    function renderizarChecklistDetalhes(tarefa) {
        listaChecklistDetalhes.replaceChildren();

        if (!tarefa.checklist.length) {
            listaChecklistDetalhes.append(criarElemento('li', 'details-empty', 'Nenhum item no checklist.'));
            return;
        }

        tarefa.checklist.forEach(item => {
            const linha = criarElemento('li', `checklist-item${item.completed ? ' is-complete' : ''}`);
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.checked = item.completed;
            checkbox.dataset.id = item.id;
            checkbox.setAttribute('aria-label', `Marcar ${item.text} como ${item.completed ? 'incompleto' : 'concluído'}`);
            const texto = criarElemento('span', 'checklist-text', item.text);
            const remover = criarBotaoAcao('checklist-remove', 'Remover item do checklist', 'fa-solid fa-xmark', '');
            remover.dataset.id = item.id;
            linha.append(checkbox, texto, remover);
            listaChecklistDetalhes.append(linha);
        });
    }

    function renderizarComentariosDetalhes(tarefa) {
        listaComentariosDetalhes.replaceChildren();

        if (!tarefa.comments.length) {
            listaComentariosDetalhes.append(criarElemento('p', 'details-empty', 'Ainda não há comentários.'));
            return;
        }

        tarefa.comments.forEach(comment => {
            const bloco = criarElemento('article', 'task-comment');
            const cabecalho = criarElemento('div', 'task-comment-header');
            cabecalho.append(
                criarElemento('strong', '', comment.author),
                criarElemento('time', '', new Date(comment.createdAt).toLocaleString('pt-BR', {
                    dateStyle: 'short',
                    timeStyle: 'short'
                }))
            );
            bloco.append(cabecalho, criarElemento('p', '', comment.text));
            listaComentariosDetalhes.append(bloco);
        });

        listaComentariosDetalhes.scrollTop = listaComentariosDetalhes.scrollHeight;
    }

    function obterNomeUsuarioDetalhes() {
        try {
            const usuario = JSON.parse(localStorage.getItem('teamwave_usuario_logado') || 'null');
            return typeof usuario?.nome === 'string' && usuario.nome.trim() ? usuario.nome.trim() : 'Pessoa';
        } catch (erro) {
            console.warn('Não foi possível ler o nome do usuário conectado:', erro);
            return 'Pessoa';
        }
    }

    function salvarDescricaoDetalhes() {
        const tarefa = tarefaAbertaDetalhes();
        if (!tarefa) return true;

        const descricao = campoDescricaoDetalhes.value.trim();
        if (descricao === tarefa.detailsDescription) return true;

        const descricaoAnterior = tarefa.detailsDescription;
        const atualizadoAnteriormente = tarefa.updatedAt;
        tarefa.detailsDescription = descricao;
        tarefa.updatedAt = new Date().toISOString();

        if (!salvarTarefas()) {
            tarefa.detailsDescription = descricaoAnterior;
            tarefa.updatedAt = atualizadoAnteriormente;
            campoDescricaoDetalhes.value = descricaoAnterior;
            return false;
        }

        mensagemDetalhesTarefa.textContent = 'Descrição salva automaticamente.';
        return true;
    }

    campoDescricaoDetalhes.addEventListener('change', salvarDescricaoDetalhes);

    formularioChecklistDetalhes.addEventListener('submit', evento => {
        evento.preventDefault();
        const tarefa = tarefaAbertaDetalhes();
        const texto = campoNovoChecklistDetalhes.value.trim();
        if (!tarefa || !texto) return;

        if (tarefa.status === 'Concluído') {
            mensagemDetalhesTarefa.textContent = 'Tire a tarefa da coluna "Concluído" antes de adicionar itens ao checklist.';
            return;
        }

        if (persistirAlteracaoDetalhes(tarefa, item => {
            item.checklist.push({ id: gerarId(), text: texto, completed: false });
        })) {
            campoNovoChecklistDetalhes.value = '';
            renderizarChecklistDetalhes(tarefa);
            mensagemDetalhesTarefa.textContent = 'Item adicionado ao checklist.';
        }
    });

    listaChecklistDetalhes.addEventListener('change', evento => {
        const checkbox = evento.target.closest('input[type="checkbox"][data-id]');
        const tarefa = tarefaAbertaDetalhes();
        if (!checkbox || !tarefa) return;

        const item = tarefa.checklist.find(registro => registro.id === checkbox.dataset.id);
        if (!item) return;
        if (tarefa.status === 'Concluído' && !checkbox.checked) {
            checkbox.checked = true;
            mensagemDetalhesTarefa.textContent = 'Tire a tarefa da coluna "Concluído" antes de desmarcar itens do checklist.';
            return;
        }

        persistirAlteracaoDetalhes(tarefa, () => {
            item.completed = checkbox.checked;
        });
        renderizarChecklistDetalhes(tarefa);
    });

    listaChecklistDetalhes.addEventListener('click', evento => {
        const botao = evento.target.closest('.checklist-remove[data-id]');
        const tarefa = tarefaAbertaDetalhes();
        if (!botao || !tarefa) return;

        if (persistirAlteracaoDetalhes(tarefa, item => {
            item.checklist = item.checklist.filter(registro => registro.id !== botao.dataset.id);
        })) {
            renderizarChecklistDetalhes(tarefa);
            mensagemDetalhesTarefa.textContent = 'Item removido do checklist.';
        }
    });

    formularioComentarioDetalhes.addEventListener('submit', evento => {
        evento.preventDefault();
        const tarefa = tarefaAbertaDetalhes();
        const texto = campoComentarioDetalhes.value.trim();
        if (!tarefa || !texto) return;

        if (persistirAlteracaoDetalhes(tarefa, item => {
            item.comments.push({
                id: gerarId(),
                text: texto,
                author: obterNomeUsuarioDetalhes(),
                createdAt: new Date().toISOString()
            });
        })) {
            campoComentarioDetalhes.value = '';
            renderizarComentariosDetalhes(tarefa);
            mensagemDetalhesTarefa.textContent = 'Comentário publicado.';
        }
    });

    botaoAdicionarArquivosDetalhes.addEventListener('click', () => campoArquivosDetalhes.click());

    listaAnexosDetalhes.addEventListener('click', async evento => {
        const botao = evento.target.closest('.details-attachment-remove[data-id]');
        const tarefa = tarefaAbertaDetalhes();
        if (!botao || !tarefa) return;

        const anexo = tarefa.detailsAttachments.find(item => item.id === botao.dataset.id);
        if (!anexo) return;

        if (!persistirAlteracaoDetalhes(tarefa, item => {
            item.detailsAttachments = item.detailsAttachments.filter(registro => registro.id !== anexo.id);
        })) return;

        try {
            await excluirAnexoDoBanco(anexo.id);
            mensagemDetalhesTarefa.textContent = 'Anexo removido.';
        } catch (erro) {
            console.error('O anexo foi removido do quadro, mas não do armazenamento local:', erro);
            mensagemDetalhesTarefa.textContent = 'Anexo removido do quadro, mas não foi possível apagar o arquivo do armazenamento local.';
        }

        renderizarAnexosDetalhes(tarefa);
    });

    campoArquivosDetalhes.addEventListener('change', async () => {
        const tarefa = tarefaAbertaDetalhes();
        const arquivos = Array.from(campoArquivosDetalhes.files || []);
        campoArquivosDetalhes.value = '';
        if (!tarefa || !arquivos.length) return;

        if (tarefa.detailsAttachments.length + arquivos.length > LIMITE_ANEXOS_TAREFA) {
            alert(`Cada tarefa pode ter no máximo ${LIMITE_ANEXOS_TAREFA} arquivos anexados aos detalhes.`);
            return;
        }

        const anexosAdicionados = [];
        try {
            for (const arquivo of arquivos) {
                if (arquivo.size > LIMITE_ARQUIVO) {
                    alert(`O arquivo "${arquivo.name}" ultrapassa o limite de 25 MB.`);
                    continue;
                }

                const anexo = {
                    id: gerarId(),
                    name: arquivo.name,
                    type: arquivo.type || 'application/octet-stream',
                    size: arquivo.size
                };
                await armazenarAnexo(anexo.id, arquivo);
                anexosAdicionados.push(anexo);
            }
        } catch (erro) {
            console.error('Não foi possível armazenar os anexos dos detalhes da tarefa:', erro);
            await Promise.all(anexosAdicionados.map(anexo =>
                excluirAnexoDoBanco(anexo.id).catch(erroRemocao => {
                    console.warn('Não foi possível limpar um anexo que não foi salvo:', erroRemocao);
                })
            ));
            alert('Não foi possível armazenar os anexos. Verifique o espaço disponível no navegador.');
            return;
        }

        if (!anexosAdicionados.length) return;

        if (!persistirAlteracaoDetalhes(tarefa, item => {
            item.detailsAttachments.push(...anexosAdicionados);
        })) {
            await Promise.all(anexosAdicionados.map(anexo =>
                excluirAnexoDoBanco(anexo.id).catch(erro => {
                    console.warn('Não foi possível limpar um anexo que não foi salvo:', erro);
                })
            ));
            return;
        }

        renderizarAnexosDetalhes(tarefa);
        mensagemDetalhesTarefa.textContent = 'Anexo(s) adicionado(s).';
    });

    // ================================================================
    // 6. CRIAÇÃO, EDIÇÃO E EXCLUSÃO DE TAREFAS
    // ================================================================

    function abrirModal(status = 'A Fazer', tarefa = null) {
        formulario.reset();
        anexosMantidos = tarefa ? metadadosAnexos(tarefa.attachments) : [];
        novosArquivosSelecionados = [];

        campoId.value = tarefa ? tarefa.id : '';
        campoTitulo.value = tarefa ? tarefa.title : '';
        campoDescricao.value = tarefa ? tarefa.description : '';
        campoResponsavel.value = tarefa ? tarefa.responsible : '';
        campoPrioridade.value = tarefa ? tarefa.priority : 'Média';
        campoPrazo.value = tarefa ? tarefa.dueDate : '';

        campoStatus.value = statusPermitidos.includes(tarefa ? tarefa.status : status)
            ? (tarefa ? tarefa.status : status)
            : 'A Fazer';

        tituloModal.textContent = tarefa ? 'Editar tarefa' : 'Nova tarefa';

        renderizarAnexosModal();
        modal.hidden = false;
        document.body.classList.add('modal-open');
        window.setTimeout(() => campoTitulo.focus(), 0);
    }

    function fecharModal() {
        modal.hidden = true;
        document.body.classList.remove('modal-open');
        formulario.reset();
        anexosMantidos = [];
        novosArquivosSelecionados = [];
        listaAnexos.replaceChildren();
    }

    // Valida e salva uma tarefa, controlando também seus anexos.
    async function salvarTarefa(evento) {
        evento.preventDefault();

        const titulo = campoTitulo.value.trim();

        if (!titulo) {
            campoTitulo.focus();
            return;
        }

        const arquivosNovos = novosArquivosSelecionados;

        if (anexosMantidos.length + arquivosNovos.length > LIMITE_ANEXOS_TAREFA) {
            alert(`Cada tarefa pode ter no máximo ${LIMITE_ANEXOS_TAREFA} arquivos anexados.`);
            return;
        }

        const arquivoGrande = arquivosNovos.find(arquivo => arquivo.size > LIMITE_ARQUIVO);

        if (arquivoGrande) {
            alert(`O arquivo "${arquivoGrande.name}" ultrapassa o limite de 25 MB.`);
            return;
        }

        const id = campoId.value;
        const tarefaExistente = id ? tarefas.find(tarefa => tarefa.id === id) : null;
        if (
            campoStatus.value === 'Concluído' &&
            tarefaExistente &&
            !todosItensChecklistConcluidos(tarefaExistente)
        ) {
            alert('Conclua todos os itens do checklist antes de concluir a tarefa.');
            return;
        }

        const agora = new Date().toISOString();

        const novosMetadados = arquivosNovos.map(arquivo => ({
            id: gerarId(),
            name: arquivo.name,
            type: arquivo.type || 'application/octet-stream',
            size: arquivo.size
        }));

        const anexosMantidosIds = new Set(anexosMantidos.map(anexo => anexo.id));
        const anexosRemovidos = (tarefaExistente?.attachments || [])
            .filter(anexo => !anexosMantidosIds.has(anexo.id));

        const arquivosArmazenados = [];

        try {
            for (let indice = 0; indice < arquivosNovos.length; indice++) {
                await armazenarAnexo(novosMetadados[indice].id, arquivosNovos[indice]);
                arquivosArmazenados.push(novosMetadados[indice].id);
            }
        } catch (erro) {
            console.error('Erro ao guardar os anexos:', erro);

            await Promise.all(
                arquivosArmazenados.map(idAnexo =>
                    excluirAnexoDoBanco(idAnexo).catch(() => {})
                )
            );

            alert(`Não foi possível guardar os anexos. Verifique o espaço disponível no navegador. ${erro.message || ''}`);
            return;
        }

        const novaTarefa = {
            id: tarefaExistente ? tarefaExistente.id : gerarId(),
            title: titulo,
            description: campoDescricao.value.trim(),
            responsible: campoResponsavel.value.trim(),
            priority: ['Baixa', 'Média', 'Alta', 'Urgente'].includes(campoPrioridade.value)
                ? campoPrioridade.value
                : 'Média',
            dueDate: validarData(campoPrazo.value),
            status: statusPermitidos.includes(campoStatus.value) ? campoStatus.value : 'A Fazer',
            attachments: [...anexosMantidos, ...novosMetadados],
            detailsDescription: tarefaExistente ? tarefaExistente.detailsDescription : '',
            detailsAttachments: tarefaExistente ? tarefaExistente.detailsAttachments : [],
            checklist: tarefaExistente ? tarefaExistente.checklist : [],
            comments: tarefaExistente ? tarefaExistente.comments : [],
            createdAt: tarefaExistente ? tarefaExistente.createdAt : agora,
            updatedAt: agora
        };

        const tarefasAnteriores = tarefas;
        tarefas = tarefas.slice();

        if (tarefaExistente) {
            const indice = tarefas.findIndex(tarefa => tarefa.id === id);
            tarefas[indice] = novaTarefa;
        } else {
            tarefas.push(novaTarefa);
        }

        if (!salvarTarefas()) {
            tarefas = tarefasAnteriores;

            await Promise.all(
                arquivosArmazenados.map(idAnexo =>
                    excluirAnexoDoBanco(idAnexo).catch(() => {})
                )
            );

            return;
        }

        for (const anexo of anexosRemovidos) {
            try {
                await excluirAnexoDoBanco(anexo.id);
            } catch (erro) {
                console.warn('Não foi possível apagar um arquivo removido:', erro);
            }
        }

        fecharModal();
        renderizarQuadro();
    }

    // Recupera um arquivo salvo e inicia seu download.
    async function baixarAnexo(anexo) {
        try {
            const registro = await buscarAnexo(anexo.id);

            if (!registro || !registro.blob) {
                alert(`O arquivo "${anexo.name}" não foi encontrado neste navegador. Se você mudou de computador ou limpou os dados do navegador, será necessário anexá-lo novamente.`);
                return;
            }

            const url = URL.createObjectURL(registro.blob);
            const link = document.createElement('a');

            link.href = url;
            link.download = anexo.name;

            document.body.append(link);
            link.click();
            link.remove();

            window.setTimeout(() => URL.revokeObjectURL(url), 1000);
        } catch (erro) {
            console.error('Não foi possível baixar o anexo:', erro);
            alert('Não foi possível abrir o anexo. Verifique as permissões de armazenamento do navegador.');
        }
    }

    // Pede confirmação e apaga a tarefa e seus arquivos anexados.
    async function excluirTarefa(id) {
        const tarefa = tarefas.find(item => item.id === id);
        if (!tarefa) return;

        const confirmou = window.confirm(`Deseja excluir a tarefa "${tarefa.title}"? Essa ação não pode ser desfeita.`);
        if (!confirmou) return;

        const tarefasAnteriores = tarefas;
        tarefas = tarefas.filter(item => item.id !== id);

        if (!salvarTarefas()) {
            tarefas = tarefasAnteriores;
            return;
        }

        for (const anexo of [...(tarefa.attachments || []), ...(tarefa.detailsAttachments || [])]) {
            try {
                await excluirAnexoDoBanco(anexo.id);
            } catch (erro) {
                console.warn('Não foi possível apagar um anexo da tarefa excluída:', erro);
            }
        }

        renderizarQuadro();
    }

    // ================================================================
    // 7. MOVIMENTAÇÃO ENTRE COLUNAS (DRAG AND DROP)
    // ================================================================

    function todosItensChecklistConcluidos(tarefa) {
        return !Array.isArray(tarefa.checklist) || tarefa.checklist.every(item => item && item.completed);
    }

    function moverTarefa(id, novoStatus) {
        if (!statusPermitidos.includes(novoStatus)) return;

        const tarefa = tarefas.find(item => item.id === id);
        if (!tarefa || tarefa.status === novoStatus) return;
        if (novoStatus === 'Concluído' && !todosItensChecklistConcluidos(tarefa)) {
            alert('Conclua todos os itens do checklist antes de concluir a tarefa.');
            return;
        }

        const statusAnterior = tarefa.status;
        tarefa.status = novoStatus;
        tarefa.updatedAt = new Date().toISOString();

        if (!salvarTarefas()) {
            tarefa.status = statusAnterior;
            return;
        }

        renderizarQuadro();
    }

    // ================================================================
    // 8. EXPORTAÇÃO E IMPORTAÇÃO DE BACKUP JSON
    // ================================================================

    function blobParaDataURL(blob) {
        return new Promise((resolve, reject) => {
            const leitor = new FileReader();

            leitor.onload = () => resolve(String(leitor.result || ''));
            leitor.onerror = () => reject(leitor.error || new Error('Não foi possível preparar um anexo para exportação.'));

            leitor.readAsDataURL(blob);
        });
    }

    // Converte uma Data URL do backup novamente em Blob.
    function dataURLParaBlob(dataURL) {
        if (typeof dataURL !== 'string' || !dataURL.startsWith('data:')) {
            throw new Error('Um anexo do arquivo JSON possui formato inválido.');
        }

        const separador = dataURL.indexOf(',');
        if (separador < 0) throw new Error('Um anexo do arquivo JSON possui formato inválido.');

        const cabecalho = dataURL.slice(0, separador);
        const conteudo = dataURL.slice(separador + 1);
        const tipo = (cabecalho.match(/^data:([^;]+)/) || [])[1] || 'application/octet-stream';

        let blob;

        if (cabecalho.includes(';base64')) {
            const binario = atob(conteudo);
            const bytes = new Uint8Array(binario.length);

            for (let i = 0; i < binario.length; i++) {
                bytes[i] = binario.charCodeAt(i);
            }

            blob = new Blob([bytes], { type: tipo });
        } else {
            blob = new Blob([decodeURIComponent(conteudo)], { type: tipo });
        }

        return blob;
    }

    // Gera e baixa um backup JSON com as tarefas e os arquivos disponíveis.
    async function exportarJSON() {
        try {
            const tarefasExportadas = [];

            for (const tarefa of tarefas) {
                const anexosExportados = [];

                for (const anexo of tarefa.attachments || []) {
                    const registro = await buscarAnexo(anexo.id).catch(() => null);

                    if (registro && registro.blob) {
                        anexosExportados.push({
                            ...anexo,
                            dataUrl: await blobParaDataURL(registro.blob)
                        });
                    } else {
                        anexosExportados.push({ ...anexo });
                    }
                }

                const anexosDetalhesExportados = [];
                for (const anexo of tarefa.detailsAttachments || []) {
                    const registro = await buscarAnexo(anexo.id).catch(() => null);

                    if (registro && registro.blob) {
                        anexosDetalhesExportados.push({
                            ...anexo,
                            dataUrl: await blobParaDataURL(registro.blob)
                        });
                    } else {
                        anexosDetalhesExportados.push({ ...anexo });
                    }
                }

                tarefasExportadas.push({
                    ...tarefa,
                    attachments: anexosExportados,
                    detailsAttachments: anexosDetalhesExportados
                });
            }

            const conteudo = JSON.stringify(tarefasExportadas, null, 2);
            const arquivo = new Blob([conteudo], { type: 'application/json;charset=utf-8' });
            const url = URL.createObjectURL(arquivo);
            const link = document.createElement('a');

            link.href = url;
            link.download = `teamwave-kanban-${ID_QUADRO}-${new Date().toISOString().slice(0, 10)}.json`;

            document.body.append(link);
            link.click();
            link.remove();

            window.setTimeout(() => URL.revokeObjectURL(url), 1000);
        } catch (erro) {
            console.error('Erro ao exportar o quadro:', erro);
            alert('Não foi possível exportar o quadro. Tente novamente ou reduza o tamanho dos anexos.');
        }
    }

    // Valida um backup e substitui o quadro atual após confirmação.
    async function importarJSON(arquivo) {
        if (!arquivo) return;

        const leitor = new FileReader();

        leitor.onload = async () => {
            const anexosArmazenados = [];

            try {
                const dados = JSON.parse(String(leitor.result || ''));

                if (!Array.isArray(dados)) {
                    throw new Error('O arquivo deve conter uma lista de tarefas.');
                }

                const linhasImportadas = dados
                    .filter(item => item && typeof item.title === 'string' && item.title.trim())
                    .map(item => ({
                        tarefa: {
                            id: gerarId(),
                            title: item.title.trim().slice(0, 120),
                            description: String(item.description || '').slice(0, 1000),
                            detailsDescription: String(item.detailsDescription || '').slice(0, 1000),
                            responsible: String(item.responsible || '').slice(0, 100),
                            priority: ['Baixa', 'Média', 'Alta', 'Urgente'].includes(item.priority)
                                ? item.priority
                                : 'Média',
                            dueDate: validarData(item.dueDate),
                            status: statusPermitidos.includes(item.status) ? item.status : 'A Fazer',
                            attachments: [],
                            detailsAttachments: [],
                            checklist: Array.isArray(item.checklist)
                                ? item.checklist.filter(checklistItem => checklistItem && typeof checklistItem.text === 'string' && checklistItem.text.trim())
                                    .map(checklistItem => ({
                                        id: gerarId(),
                                        text: checklistItem.text.trim().slice(0, 160),
                                        completed: Boolean(checklistItem.completed)
                                    }))
                                : [],
                            comments: Array.isArray(item.comments)
                                ? item.comments.filter(comment => comment && typeof comment.text === 'string' && comment.text.trim())
                                    .map(comment => ({
                                        id: gerarId(),
                                        text: comment.text.trim().slice(0, 1000),
                                        author: String(comment.author || 'Pessoa').slice(0, 100),
                                        createdAt: comment.createdAt || new Date().toISOString()
                                    }))
                                : [],
                            createdAt: item.createdAt || new Date().toISOString(),
                            updatedAt: new Date().toISOString()
                        },
                        anexos: Array.isArray(item.attachments)
                            ? item.attachments.filter(anexo =>
                                anexo &&
                                typeof anexo.name === 'string' &&
                                typeof anexo.dataUrl === 'string'
                            )
                            : [],
                        anexosDetalhes: Array.isArray(item.detailsAttachments)
                            ? item.detailsAttachments.filter(anexo =>
                                anexo &&
                                typeof anexo.name === 'string' &&
                                typeof anexo.dataUrl === 'string'
                            )
                            : []
                    }));

                if (linhasImportadas.length === 0 && dados.length > 0) {
                    throw new Error('Nenhuma tarefa válida foi encontrada no arquivo.');
                }

                const tarefaComChecklistPendente = linhasImportadas.find(({ tarefa }) =>
                    tarefa.status === 'Concluído' && !todosItensChecklistConcluidos(tarefa)
                );
                if (tarefaComChecklistPendente) {
                    throw new Error(`A tarefa "${tarefaComChecklistPendente.tarefa.title}" está concluída, mas possui itens pendentes no checklist.`);
                }

                const substituir = window.confirm(
                    `O arquivo contém ${linhasImportadas.length} tarefa(s). Deseja substituir todas as tarefas atuais? Faça uma exportação antes para manter uma cópia do quadro atual.`
                );

                if (!substituir) return;

                let anexosIgnorados = 0;

                for (const linha of linhasImportadas) {
                    for (const [anexos, propriedadeDestino] of [
                        [linha.anexos.slice(0, LIMITE_ANEXOS_TAREFA), 'attachments'],
                        [linha.anexosDetalhes.slice(0, LIMITE_ANEXOS_TAREFA), 'detailsAttachments']
                    ]) {
                        for (const anexo of anexos) {
                            let blob;

                            try {
                                blob = dataURLParaBlob(anexo.dataUrl);
                            } catch (erro) {
                                anexosIgnorados++;
                                continue;
                            }

                            if (blob.size > LIMITE_ARQUIVO) {
                                anexosIgnorados++;
                                continue;
                            }

                            const novoAnexo = {
                                id: gerarId(),
                                name: String(anexo.name).slice(0, 255),
                                type: String(anexo.type || blob.type || 'application/octet-stream'),
                                size: blob.size
                            };

                            try {
                                await armazenarAnexo(
                                    novoAnexo.id,
                                    new File([blob], novoAnexo.name, { type: novoAnexo.type })
                                );

                                anexosArmazenados.push(novoAnexo.id);
                                linha.tarefa[propriedadeDestino].push(novoAnexo);
                            } catch (erro) {
                                console.warn('Um anexo não pôde ser importado:', erro);
                                anexosIgnorados++;
                            }
                        }
                    }
                }

                const tarefasAnteriores = tarefas;
                const anexosAnteriores = Array.from(new Map(
                    tarefas.flatMap(tarefa => [
                        ...(tarefa.attachments || []),
                        ...(tarefa.detailsAttachments || [])
                    ]).map(anexo => [anexo.id, anexo])
                ).values());

                tarefas = linhasImportadas.map(linha => linha.tarefa);

                if (!salvarTarefas()) {
                    tarefas = tarefasAnteriores;

                    await Promise.all(
                        anexosArmazenados.map(idAnexo =>
                            excluirAnexoDoBanco(idAnexo).catch(() => {})
                        )
                    );

                    return;
                }

                // Apaga os anexos antigos somente depois de salvar a nova lista.
                for (const anexo of anexosAnteriores) {
                    try {
                        await excluirAnexoDoBanco(anexo.id);
                    } catch (erro) {
                        console.warn('Não foi possível limpar um anexo antigo:', erro);
                    }
                }

                renderizarQuadro();

                alert(anexosIgnorados
                    ? `Tarefas importadas. ${anexosIgnorados} anexo(s) não puderam ser importados; confira se estavam incluídos no JSON e se respeitam o limite de 25 MB.`
                    : 'Tarefas importadas com sucesso.');
            } catch (erro) {
                console.error('Erro ao importar o arquivo:', erro);

                await Promise.all(
                    anexosArmazenados.map(idAnexo =>
                        excluirAnexoDoBanco(idAnexo).catch(() => {})
                    )
                );

                alert(`Não foi possível importar o arquivo JSON. ${erro.message || 'Verifique se o arquivo está correto.'}`);
            } finally {
                arquivoImportacao.value = '';
            }
        };

        leitor.onerror = () => {
            alert('Não foi possível ler o arquivo selecionado.');
            arquivoImportacao.value = '';
        };

        leitor.readAsText(arquivo, 'UTF-8');
    }

    // ================================================================
    // 9. EVENTOS DA INTERFACE
    // ================================================================

    botaoSeletorQuadros.addEventListener('click', abrirSeletorQuadros);
    botaoFecharSeletor.addEventListener('click', fecharSeletorQuadros);

    modalSeletorQuadros.addEventListener('click', evento => {
        if (evento.target === modalSeletorQuadros) fecharSeletorQuadros();
    });

    document.addEventListener('keydown', evento => {
        if (evento.key === 'Escape' && !modalSeletorQuadros.hidden) fecharSeletorQuadros();
    });

    document.querySelectorAll('.btn-add-card').forEach(botao => {
        botao.addEventListener('click', () => abrirModal(botao.dataset.status || 'A Fazer'));
    });

    formulario.addEventListener('submit', salvarTarefa);

    campoAnexos.addEventListener('change', () => {
        const arquivos = Array.from(campoAnexos.files || []);
        const grande = arquivos.find(arquivo => arquivo.size > LIMITE_ARQUIVO);

        novosArquivosSelecionados.push(...arquivos);
        campoAnexos.value = '';

        if (grande) {
            alert(`O arquivo "${grande.name}" ultrapassa o limite de 25 MB.`);
        }

        renderizarAnexosModal();
    });

    document.getElementById('close-modal').addEventListener('click', fecharModal);
    document.getElementById('cancel-task').addEventListener('click', fecharModal);

    modal.addEventListener('click', evento => {
        if (evento.target === modal) fecharModal();
    });

    document.addEventListener('keydown', evento => {
        if (evento.key === 'Escape' && !modal.hidden) fecharModal();
    });

    botaoFecharDetalhesTarefa.addEventListener('click', fecharDetalhesTarefa);

    modalDetalhesTarefa.addEventListener('click', evento => {
        if (evento.target === modalDetalhesTarefa) fecharDetalhesTarefa();
    });

    document.addEventListener('keydown', evento => {
        if (evento.key === 'Escape' && !modalDetalhesTarefa.hidden) fecharDetalhesTarefa();
    });

    campoPesquisa.addEventListener('input', renderizarQuadro);

    // Controla o arraste dos cartões e a movimentação entre colunas.
    colunas.forEach(coluna => {
        coluna.addEventListener('dragover', evento => {
            evento.preventDefault();

            if (evento.dataTransfer) {
                evento.dataTransfer.dropEffect = 'move';
            }

            coluna.classList.add('is-drag-over');
        });

        coluna.addEventListener('dragleave', evento => {
            if (!coluna.contains(evento.relatedTarget)) {
                coluna.classList.remove('is-drag-over');
            }
        });

        coluna.addEventListener('drop', evento => {
            evento.preventDefault();
            coluna.classList.remove('is-drag-over');

            const id = (evento.dataTransfer && evento.dataTransfer.getData('text/plain')) || idArrastado;

            if (id) {
                moverTarefa(id, coluna.dataset.status);
            }
        });
    });

    document.getElementById('export-button').addEventListener('click', exportarJSON);

    document.getElementById('import-button').addEventListener('click', () => {
        arquivoImportacao.click();
    });

    arquivoImportacao.addEventListener('change', () => {
        importarJSON(arquivoImportacao.files[0]);
    });

    // ================================================================
    // 10. FAVORITOS E INICIALIZAÇÃO DO QUADRO
    // ================================================================

    const botaoFavorito = document.getElementById('favorite-board');

    function atualizarFavorito(favorito) {
        botaoFavorito.setAttribute('aria-pressed', String(favorito));
        botaoFavorito.classList.toggle('is-favorite', favorito);

        const icone = botaoFavorito.querySelector('i');
        icone.className = favorito ? 'fa-solid fa-star' : 'fa-regular fa-star';

        botaoFavorito.title = favorito ? 'Remover dos favoritos' : 'Favoritar quadro';
        botaoFavorito.setAttribute('aria-label', botaoFavorito.title);
    }

    try {
        atualizarFavorito(localStorage.getItem(CHAVE_FAVORITO) === 'true');
    } catch (erro) {
        atualizarFavorito(false);
    }

    botaoFavorito.addEventListener('click', () => {
        const favorito = botaoFavorito.getAttribute('aria-pressed') !== 'true';

        atualizarFavorito(favorito);

        try {
            localStorage.setItem(CHAVE_FAVORITO, String(favorito));
        } catch (erro) {
            console.warn('Não foi possível salvar o favorito:', erro);
        }
    });

    // Exibe as tarefas salvas assim que a página termina de carregar.
    renderizarQuadro();
});