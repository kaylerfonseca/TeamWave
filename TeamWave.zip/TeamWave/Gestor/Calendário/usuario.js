document.addEventListener('DOMContentLoaded', () => {
    const nomeUsuario = document.querySelector('.user-profile .name');
    if (!nomeUsuario) return;

    try {
        const usuarioLogado = JSON.parse(localStorage.getItem('teamwave_usuario_logado') || 'null');
        if (usuarioLogado && typeof usuarioLogado.nome === 'string' && usuarioLogado.nome.trim()) {
            nomeUsuario.textContent = usuarioLogado.nome.trim();
        }
    } catch (erro) {
        console.error('Não foi possível carregar o nome do usuário conectado:', erro);
    }
});
