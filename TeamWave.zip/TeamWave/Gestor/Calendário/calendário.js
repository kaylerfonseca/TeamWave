/* =========================================================
   TeamWave - Calendário mensal integrado ao Kanban
   Exibe os dias do mês selecionado e destaca tarefas e eventos.
   Os eventos são salvos no navegador; as tarefas vêm dos quadros.
========================================================= */
document.addEventListener('DOMContentLoaded', () => {
    // ================================================================
    // 1. CONFIGURAÇÕES E ELEMENTOS DA PÁGINA
    // ================================================================
    const CHAVE_EVENTOS = 'teamwave_calendario_eventos_v1';
    const PREFIXO_TAREFAS = 'teamwave_kanban_tarefas_v1';

    const gradeCalendario = document.getElementById('calendar-grid');
    const seletorMes = document.getElementById('month-select');
    const seletorAno = document.getElementById('year-select');
    const textoDataSelecionada = document.getElementById('selected-date-label');
    const tituloDataSelecionada = document.getElementById('selected-date-title');
    const listaAgenda = document.getElementById('day-agenda');
    const listaProgramacaoGeral = document.getElementById('all-schedule-list');
    const contadorProgramacaoGeral = document.getElementById('all-schedule-count');
    const ordemProgramacaoGeral = document.getElementById('all-schedule-order');
    const campoPesquisa = document.getElementById('calendar-search');
    const filtroCalendario = document.getElementById('calendar-filter');

    const modal = document.getElementById('event-modal');
    const formulario = document.getElementById('event-form');
    const tituloModal = document.getElementById('event-modal-title');
    const campoId = document.getElementById('event-id');
    const campoTitulo = document.getElementById('event-title');
    const campoDescricao = document.getElementById('event-description');
    const campoData = document.getElementById('event-date');
    const campoHorario = document.getElementById('event-time');
    const campoTipo = document.getElementById('event-type');
    const campoResponsavel = document.getElementById('event-responsible');
    const botaoExcluirEvento = document.getElementById('delete-event-button');

    const botaoAbrirModal = document.getElementById('open-event-modal');
    const botaoAdicionarDia = document.getElementById('add-event-selected');
    const botaoFecharModal = document.getElementById('close-event-modal');
    const botaoCancelarModal = document.getElementById('cancel-event-modal');
    const botaoMesAnterior = document.getElementById('previous-month');
    const botaoProximoMes = document.getElementById('next-month');
    const botaoHoje = document.getElementById('today-button');

    const hoje = obterDataAtual();
    let mesExibido = hoje.getMonth();
    let anoExibido = hoje.getFullYear();
    let dataSelecionada = formatarChaveData(hoje);
    let eventos = carregarEventos();
    let tarefas = [];

    // Nomes dos quadros padrão. Os quadros personalizados são carregados do navegador.
    const nomesQuadros = {
        'team-wave': 'TeamWave',
        'estrategia': 'Estratégia',
        'operacoes': 'Operações',
        'marketing': 'Marketing',
        'projeto': 'Projeto',
        'reunioes': 'Reuniões',
        'design': 'Design',
        'planejamento': 'Planejamento',
        'natureza': 'Natureza',
        'montanhas': 'Montanhas',
        'praia': 'Praia',
        'amanhecer': 'Amanhecer',
        'ceu-estrelado': 'Céu estrelado'
    };

    carregarNomesQuadrosPersonalizados();
    tarefas = carregarTarefasDoKanban();
    preencherSeletorAnos();
    atualizarSeletores();
    renderizarTudo();

    // ================================================================
    // 2. FUNÇÕES DE DATA
    // ================================================================

    // Cria uma data local sem depender do fuso horário do navegador.
    function obterDataAtual() {
        const agora = new Date();
        return new Date(agora.getFullYear(), agora.getMonth(), agora.getDate());
    }

    // Converte Date para AAAA-MM-DD.
    function formatarChaveData(data) {
        const ano = data.getFullYear();
        const mes = String(data.getMonth() + 1).padStart(2, '0');
        const dia = String(data.getDate()).padStart(2, '0');
        return `${ano}-${mes}-${dia}`;
    }

    // Confere se a data está no formato AAAA-MM-DD e se ela existe.
    function validarData(valor) {
        if (typeof valor !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(valor)) return false;
        const partes = valor.split('-').map(Number);
        const data = new Date(partes[0], partes[1] - 1, partes[2]);
        return data.getFullYear() === partes[0] &&
            data.getMonth() === partes[1] - 1 &&
            data.getDate() === partes[2];
    }

    // Converte AAAA-MM-DD em Date local para evitar alteração de dia pelo fuso horário.
    function converterData(valor) {
        const partes = valor.split('-').map(Number);
        return new Date(partes[0], partes[1] - 1, partes[2]);
    }

    function formatarDataCompleta(valor) {
        if (!validarData(valor)) return 'Data não informada';
        return converterData(valor).toLocaleDateString('pt-BR', {
            weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
        });
    }

    function formatarDataCurta(valor) {
        if (!validarData(valor)) return '';
        return converterData(valor).toLocaleDateString('pt-BR');
    }

    function normalizarTexto(valor) {
        return String(valor || '').toLocaleLowerCase('pt-BR').trim();
    }

    // ================================================================
    // 3. SELEÇÃO DE MÊS E ANO
    // ================================================================

    // Mantém o seletor de anos no intervalo disponível para navegação.
    function preencherSeletorAnos() {
        seletorAno.replaceChildren();
        for (let ano = 1952; ano <= 2100; ano++) {
            const opcao = document.createElement('option');
            opcao.value = ano;
            opcao.textContent = ano;
            seletorAno.append(opcao);
        }
    }

    function atualizarSeletores() {
        seletorMes.value = String(mesExibido);
        seletorAno.value = String(anoExibido);
    }

    // Mantém o número do dia ao trocar mês, ajustando para o último dia se necessário.
    function selecionarMesEAno(novoMes, novoAno) {
        const diaAtual = validarData(dataSelecionada) ? converterData(dataSelecionada).getDate() : 1;
        mesExibido = novoMes;
        anoExibido = novoAno;
        const ultimoDia = new Date(anoExibido, mesExibido + 1, 0).getDate();
        dataSelecionada = formatarChaveData(new Date(anoExibido, mesExibido, Math.min(diaAtual, ultimoDia)));
        atualizarSeletores();
        renderizarTudo();
    }

    function navegarMes(quantidade) {
        const novaData = new Date(anoExibido, mesExibido + quantidade, 1);
        selecionarMesEAno(novaData.getMonth(), novaData.getFullYear());
    }

    // ================================================================
    // 4. LEITURA DOS QUADROS E DAS TAREFAS DO KANBAN
    // ================================================================

    function carregarNomesQuadrosPersonalizados() {
        try {
            const personalizados = JSON.parse(localStorage.getItem('teamwave_quadros_personalizados_v1') || '[]');
            if (!Array.isArray(personalizados)) return;

            personalizados.forEach(quadro => {
                if (quadro && typeof quadro.id === 'string' && typeof quadro.name === 'string') {
                    nomesQuadros[quadro.id] = quadro.name.trim() || quadro.id;
                }
            });
        } catch (erro) {
            console.warn('Não foi possível ler os nomes dos quadros personalizados:', erro);
        }
    }

    // Percorre as chaves criadas pelo Kanban e reúne tarefas de todos os quadros.
    function carregarTarefasDoKanban() {
        const tarefasEncontradas = [];
        const chavesTarefas = [];

        try {
            if (localStorage.getItem(PREFIXO_TAREFAS) !== null) {
                chavesTarefas.push(PREFIXO_TAREFAS);
            }

            for (let indice = 0; indice < localStorage.length; indice++) {
                const chave = localStorage.key(indice);
                if (chave && chave.startsWith(`${PREFIXO_TAREFAS}_`)) {
                    chavesTarefas.push(chave);
                }
            }

            [...new Set(chavesTarefas)].forEach(chave => {
                try {
                    const idQuadro = chave === PREFIXO_TAREFAS
                        ? 'team-wave'
                        : chave.slice(`${PREFIXO_TAREFAS}_`.length);
                    const nomeQuadro = nomesQuadros[idQuadro] || idQuadro;
                    const dados = localStorage.getItem(chave);
                    if (dados === null) return;

                    const tarefasSalvas = JSON.parse(dados);
                    if (!Array.isArray(tarefasSalvas)) {
                        throw new Error('Os dados salvos não são uma lista de tarefas.');
                    }

                    tarefasSalvas.forEach(tarefa => {
                        if (!tarefa || typeof tarefa.title !== 'string' || !tarefa.title.trim()) return;

                        tarefasEncontradas.push({
                            id: String(tarefa.id || `${idQuadro}-${tarefasEncontradas.length}`),
                            title: tarefa.title.trim(),
                            description: String(tarefa.description || ''),
                            responsible: String(tarefa.responsible || ''),
                            priority: ['Baixa', 'Média', 'Alta', 'Urgente'].includes(tarefa.priority) ? tarefa.priority : 'Média',
                            status: String(tarefa.status || 'A Fazer'),
                            dueDate: validarData(tarefa.dueDate) ? tarefa.dueDate : '',
                            boardId: idQuadro,
                            boardName: nomesQuadros[idQuadro] || nomeQuadro
                        });
                    });
                } catch (erro) {
                    console.error(`Não foi possível ler as tarefas do quadro associado à chave "${chave}":`, erro);
                }
            });
        } catch (erro) {
            console.error('Não foi possível carregar as tarefas do Kanban:', erro);
        }

        return tarefasEncontradas;
    }

    // ================================================================
    // 5. ARMAZENAMENTO DOS EVENTOS DO CALENDÁRIO
    // ================================================================

    function carregarEventos() {
        try {
            const dados = JSON.parse(localStorage.getItem(CHAVE_EVENTOS) || '[]');
            if (!Array.isArray(dados)) return [];

            return dados.filter(evento =>
                evento &&
                typeof evento.title === 'string' && evento.title.trim() &&
                validarData(evento.date)
            ).map(evento => ({
                id: String(evento.id || gerarId()),
                title: evento.title.trim(),
                description: String(evento.description || ''),
                date: evento.date,
                time: /^([01]\d|2[0-3]):[0-5]\d$/.test(evento.time) ? evento.time : '',
                type: typeof evento.type === 'string' && evento.type.trim()
                    ? evento.type.trim().slice(0, 40)
                    : 'Outro',
                responsible: String(evento.responsible || ''),
                createdAt: evento.createdAt || new Date().toISOString(),
                updatedAt: evento.updatedAt || new Date().toISOString()
            }));
        } catch (erro) {
            console.error('Não foi possível carregar os eventos do calendário:', erro);
            return [];
        }
    }

    function salvarEventos() {
        try {
            localStorage.setItem(CHAVE_EVENTOS, JSON.stringify(eventos));
            return true;
        } catch (erro) {
            console.error('Não foi possível salvar os eventos:', erro);
            alert('Não foi possível salvar o evento neste navegador. Verifique o espaço disponível.');
            return false;
        }
    }

    function gerarId() {
        if (window.crypto && typeof window.crypto.randomUUID === 'function') {
            return window.crypto.randomUUID();
        }
        return `evento-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    }

    // ================================================================
    // 6. CONSULTA DOS ITENS E MARCAÇÕES DO CALENDÁRIO
    // ================================================================

    // Une tarefas do Kanban e eventos do calendário em uma única estrutura.
    function obterTodosOsItens() {
        const itensTarefas = tarefas.map(tarefa => ({
            id: tarefa.id,
            title: tarefa.title,
            description: tarefa.description,
            responsible: tarefa.responsible,
            priority: tarefa.priority,
            status: tarefa.status,
            date: tarefa.dueDate,
            time: '',
            itemType: 'tarefa',
            boardId: tarefa.boardId,
            boardName: tarefa.boardName
        }));

        const itensEventos = eventos.map(evento => ({
            id: evento.id,
            title: evento.title,
            description: evento.description,
            responsible: evento.responsible,
            date: evento.date,
            time: evento.time,
            type: evento.type,
            itemType: 'evento'
        }));

        return [...itensTarefas, ...itensEventos];
    }

    function itemEstaAtrasado(item) {
        const hojeFormatado = formatarChaveData(obterDataAtual());
        return item.itemType === 'tarefa' && Boolean(item.date) && item.status !== 'Concluído' && item.date < hojeFormatado;
    }

    // Aplica a pesquisa e o filtro antes de desenhar as marcações e a agenda.
    function obterItensVisiveis() {
        const pesquisa = normalizarTexto(campoPesquisa.value);
        const tipo = filtroCalendario.value;
        let itens = obterTodosOsItens();

        if (tipo === 'tarefas') itens = itens.filter(item => item.itemType === 'tarefa');
        if (tipo === 'eventos') itens = itens.filter(item => item.itemType === 'evento');

        if (pesquisa) {
            itens = itens.filter(item => {
                const conteudo = [item.title, item.description, item.responsible, item.boardName, item.type, item.status, item.priority]
                    .filter(Boolean).join(' ');
                return normalizarTexto(conteudo).includes(pesquisa);
            });
        }

        return itens;
    }

    function obterItensDaData(data) {
        return obterItensVisiveis()
            .filter(item => item.date === data)
            .sort((a, b) => {
                const horarioA = a.time || '23:59';
                const horarioB = b.time || '23:59';
                return horarioA.localeCompare(horarioB) || a.title.localeCompare(b.title, 'pt-BR');
            });
    }

    // ================================================================
    // 7. RENDERIZAÇÃO DO CALENDÁRIO MENSAL
    // ================================================================

    function renderizarCalendario() {
        gradeCalendario.replaceChildren();
        atualizarSeletores();

        const primeiroDia = new Date(anoExibido, mesExibido, 1);
        const deslocamento = (primeiroDia.getDay() + 6) % 7; // Segunda-feira é a primeira coluna.
        const totalDias = new Date(anoExibido, mesExibido + 1, 0).getDate();
        const quantidadeCelulas = Math.ceil((deslocamento + totalDias) / 7) * 7;
        const hojeFormatado = formatarChaveData(obterDataAtual());

        for (let indice = 0; indice < quantidadeCelulas; indice++) {
            const numeroDia = indice - deslocamento + 1;

            // Espaços antes do primeiro dia e depois do último mantêm as semanas alinhadas.
            if (numeroDia < 1 || numeroDia > totalDias) {
                const espaco = document.createElement('div');
                espaco.className = 'calendar-empty-day';
                espaco.setAttribute('aria-hidden', 'true');
                gradeCalendario.append(espaco);
                continue;
            }

            const data = new Date(anoExibido, mesExibido, numeroDia);
            const chaveData = formatarChaveData(data);
            const itens = obterItensDaData(chaveData);
            const temTarefa = itens.some(item => item.itemType === 'tarefa');
            const temEvento = itens.some(item => item.itemType === 'evento');
            const temAtrasada = itens.some(item => itemEstaAtrasado(item));

            const dia = document.createElement('button');
            dia.type = 'button';
            dia.className = 'calendar-day';
            dia.dataset.date = chaveData;

            if (temTarefa) dia.classList.add('has-task');
            if (temEvento) dia.classList.add('has-event');
            if (temAtrasada) dia.classList.add('has-overdue');
            if (chaveData === hojeFormatado) dia.classList.add('today');
            if (chaveData === dataSelecionada) dia.classList.add('selected');

            dia.setAttribute('aria-label', `${formatarDataCompleta(chaveData)}. ${itens.length} ${itens.length === 1 ? 'item programado' : 'itens programados'}.`);
            dia.setAttribute('aria-pressed', String(chaveData === dataSelecionada));

            const linhaNumero = document.createElement('span');
            linhaNumero.className = 'day-number-row';

            const numero = document.createElement('span');
            numero.className = 'day-number';
            numero.textContent = numeroDia;
            linhaNumero.append(numero);

            const marcadores = document.createElement('span');
            marcadores.className = 'day-status-markers';
            if (temTarefa) marcadores.append(criarMarcador('task', 'Dia com tarefa'));
            if (temEvento) marcadores.append(criarMarcador('event', 'Dia com evento'));
            if (temAtrasada) marcadores.append(criarMarcador('overdue', 'Dia com tarefa atrasada'));
            linhaNumero.append(marcadores);

            const listaItens = document.createElement('span');
            listaItens.className = 'day-item-list';
            itens.slice(0, 2).forEach(item => {
                const etiqueta = document.createElement('span');
                etiqueta.className = 'day-item';
                if (item.itemType === 'evento') etiqueta.classList.add('event');
                if (itemEstaAtrasado(item)) etiqueta.classList.add('overdue');
                etiqueta.textContent = item.itemType === 'evento' && item.time
                    ? `${item.time} ${item.title}`
                    : item.title;
                listaItens.append(etiqueta);
            });

            if (itens.length > 2) {
                const mais = document.createElement('span');
                mais.className = 'more-items';
                mais.textContent = `+${itens.length - 2} mais`;
                listaItens.append(mais);
            }

            dia.append(linhaNumero, listaItens);
            dia.addEventListener('click', () => selecionarData(chaveData));
            gradeCalendario.append(dia);
        }
    }

    function criarMarcador(tipo, descricao) {
        const marcador = document.createElement('span');
        marcador.className = `day-status-marker ${tipo}`;
        marcador.title = descricao;
        marcador.setAttribute('aria-hidden', 'true');
        return marcador;
    }

    // ================================================================
    // 8. RENDERIZAÇÃO DA AGENDA DO DIA SELECIONADO
    // ================================================================

    function criarElemento(tag, classe, texto = '') {
        const elemento = document.createElement(tag);
        if (classe) elemento.className = classe;
        if (texto !== '') elemento.textContent = texto;
        return elemento;
    }

    function criarIcone(classe) {
        const icone = document.createElement('i');
        icone.className = classe;
        icone.setAttribute('aria-hidden', 'true');
        return icone;
    }

    function criarCartaoAgenda(item) {
        const ehEvento = item.itemType === 'evento';
        const atrasado = itemEstaAtrasado(item);
        const cartao = criarElemento('article', `agenda-item${ehEvento ? ' event' : ''}${atrasado ? ' overdue' : ''}`);

        const topo = criarElemento('div', 'agenda-item-top');
        const titulo = criarElemento('h3', '', item.title);
        const etiqueta = criarElemento('span', 'agenda-tag', ehEvento ? item.type : (atrasado ? 'Atrasada' : item.status));
        topo.append(titulo, etiqueta);
        cartao.append(topo);

        if (item.description) cartao.append(criarElemento('p', 'agenda-item-description', item.description));

        const metadados = criarElemento('div', 'agenda-item-meta');
        const horario = criarElemento('span');
        horario.append(
            criarIcone('fa-regular fa-clock'),
            document.createTextNode(ehEvento && item.time
                ? ` ${item.time}`
                : (ehEvento ? ' Dia todo' : (item.date ? ' Prazo da tarefa' : ' Sem prazo definido')))
        );
        metadados.append(horario);

        if (item.responsible) {
            const responsavel = criarElemento('span');
            responsavel.append(criarIcone('fa-regular fa-user'), document.createTextNode(` ${item.responsible}`));
            metadados.append(responsavel);
        }

        if (!ehEvento) {
            const quadro = criarElemento('span');
            quadro.append(criarIcone('fa-solid fa-table-columns'), document.createTextNode(` ${item.boardName}`));
            metadados.append(quadro);

            const prioridade = criarElemento('span');
            prioridade.append(criarIcone('fa-solid fa-flag'), document.createTextNode(` ${item.priority}`));
            metadados.append(prioridade);
        }

        cartao.append(metadados);
        const acoes = criarElemento('div', 'agenda-actions');

        if (ehEvento) {
            const editar = criarElemento('button', '', 'Editar evento');
            editar.type = 'button';
            editar.addEventListener('click', () => abrirModalEvento(item.id));

            const excluir = criarElemento('button', '', 'Excluir');
            excluir.type = 'button';
            excluir.addEventListener('click', () => excluirEvento(item.id));
            acoes.append(editar, excluir);
        } else {
            const abrirQuadro = criarElemento('a');
            abrirQuadro.href = `../Kanban/kanban.html?quadro=${encodeURIComponent(item.boardId)}`;
            abrirQuadro.innerHTML = '<i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i> Abrir quadro no Kanban';
            acoes.append(abrirQuadro);
        }

        cartao.append(acoes);
        return cartao;
    }

    function renderizarAgenda() {
        const dataFormatada = formatarDataCompleta(dataSelecionada);
        tituloDataSelecionada.textContent = 'Agenda do dia';
        textoDataSelecionada.textContent = dataFormatada;
        listaAgenda.replaceChildren();

        const itens = obterItensDaData(dataSelecionada);
        if (itens.length === 0) {
            const vazio = criarElemento('p', 'agenda-empty');
            vazio.textContent = campoPesquisa.value.trim() || filtroCalendario.value !== 'todos'
                ? 'Nenhum item corresponde à pesquisa ou ao filtro nesta data.'
                : 'Nenhuma tarefa ou evento nesta data. Use o botão + para adicionar um evento.';
            listaAgenda.append(vazio);
            return;
        }

        itens.forEach(item => listaAgenda.append(criarCartaoAgenda(item)));
    }

    // Exibe a programação completa, sem limitar os resultados ao mês selecionado.
    function renderizarProgramacaoGeral() {
        listaProgramacaoGeral.replaceChildren();

        const itens = obterItensVisiveis()
            .sort((a, b) => {
                const aTemData = validarData(a.date);
                const bTemData = validarData(b.date);
                if (aTemData !== bTemData) return aTemData ? -1 : 1;

                const diferencaData = a.date.localeCompare(b.date);
                if (diferencaData !== 0) {
                    return ordemProgramacaoGeral.value === 'desc' ? -diferencaData : diferencaData;
                }

                const horarioA = a.time || '23:59';
                const horarioB = b.time || '23:59';
                const diferencaHorario = horarioA.localeCompare(horarioB);
                if (diferencaHorario !== 0) return diferencaHorario;
                return a.title.localeCompare(b.title, 'pt-BR');
            });

        contadorProgramacaoGeral.textContent = `${itens.length} ${itens.length === 1 ? 'item' : 'itens'}`;

        if (itens.length === 0) {
            const vazio = criarElemento('p', 'agenda-empty');
            vazio.textContent = campoPesquisa.value.trim() || filtroCalendario.value !== 'todos'
                ? 'Nenhuma tarefa ou evento corresponde à pesquisa ou ao filtro.'
                : 'Ainda não existem tarefas com prazo ou eventos cadastrados.';
            listaProgramacaoGeral.append(vazio);
            return;
        }

        // Agrupa os cartões por data, preservando a ordenação escolhida.
        const gruposPorData = new Map();
        itens.forEach(item => {
            if (!gruposPorData.has(item.date)) gruposPorData.set(item.date, []);
            gruposPorData.get(item.date).push(item);
        });

        gruposPorData.forEach((itensDoDia, data) => {
            const grupo = criarElemento('section', 'all-date-group');
            const cabecalho = criarElemento('div', 'all-date-heading');
            const tituloData = criarElemento('h3', '', formatarDataCompleta(data));
            const quantidade = criarElemento('span', 'all-date-count', `${itensDoDia.length} ${itensDoDia.length === 1 ? 'item' : 'itens'}`);
            cabecalho.append(tituloData, quantidade);

            const gradeItens = criarElemento('div', 'all-date-items');
            itensDoDia.forEach(item => gradeItens.append(criarCartaoAgenda(item)));

            grupo.append(cabecalho, gradeItens);
            listaProgramacaoGeral.append(grupo);
        });
    }

    // ================================================================
    // 9. INDICADORES GERAIS E ATUALIZAÇÃO DA PÁGINA
    // ================================================================

    function renderizarResumo() {
        const hojeFormatado = formatarChaveData(obterDataAtual());
        const tarefasComPrazo = tarefas.filter(tarefa => validarData(tarefa.dueDate));
        const eventosComData = eventos.filter(evento => validarData(evento.date));
        const tarefasAtrasadas = tarefasComPrazo.filter(tarefa =>
            tarefa.status !== 'Concluído' && tarefa.dueDate < hojeFormatado
        );

        document.getElementById('summary-tasks').textContent = tarefasComPrazo.length;
        document.getElementById('summary-events').textContent = eventosComData.length;
        document.getElementById('summary-overdue').textContent = tarefasAtrasadas.length;
    }

    function renderizarTudo() {
        renderizarResumo();
        renderizarCalendario();
        renderizarAgenda();
        renderizarProgramacaoGeral();
    }

    function selecionarData(data) {
        if (!validarData(data)) return;
        const dataEscolhida = converterData(data);
        mesExibido = dataEscolhida.getMonth();
        anoExibido = dataEscolhida.getFullYear();
        dataSelecionada = data;

        preencherSeletorAnos();
        atualizarSeletores();
        renderizarTudo();
    }

    // ================================================================
    // 10. CRIAÇÃO, EDIÇÃO E EXCLUSÃO DE EVENTOS
    // ================================================================

    function abrirModalEvento(idEvento = '') {
        formulario.reset();
        campoId.value = '';
        tituloModal.textContent = idEvento ? 'Editar evento' : 'Novo evento';
        botaoExcluirEvento.hidden = !idEvento;

        if (idEvento) {
            const evento = eventos.find(item => item.id === idEvento);
            if (!evento) return;

            campoId.value = evento.id;
            campoTitulo.value = evento.title;
            campoDescricao.value = evento.description;
            campoData.value = evento.date;
            campoHorario.value = evento.time;
            campoTipo.value = evento.type;
            campoResponsavel.value = evento.responsible;
        } else {
            campoData.value = dataSelecionada || formatarChaveData(obterDataAtual());
        }

        modal.hidden = false;
        document.body.classList.add('modal-open');
        campoTitulo.focus();
    }

    function fecharModalEvento() {
        modal.hidden = true;
        document.body.classList.remove('modal-open');
        botaoAbrirModal.focus();
    }

    function excluirEvento(idEvento) {
        const evento = eventos.find(item => item.id === idEvento);
        if (!evento) return;
        if (!confirm(`Deseja excluir o evento "${evento.title}"?`)) return;

        const eventosAnteriores = eventos;
        eventos = eventos.filter(item => item.id !== idEvento);
        if (!salvarEventos()) {
            eventos = eventosAnteriores;
            return;
        }

        if (campoId.value === idEvento) fecharModalEvento();
        preencherSeletorAnos();
        renderizarTudo();
    }

    formulario.addEventListener('submit', evento => {
        evento.preventDefault();

        const titulo = campoTitulo.value.trim();
        const data = campoData.value;
        const tipo = campoTipo.value.trim().slice(0, 40);
        if (!titulo || !validarData(data)) {
            alert('Preencha o nome e uma data válida para o evento.');
            return;
        }

        const id = campoId.value;
        const existente = eventos.find(item => item.id === id);
        const agora = new Date().toISOString();

        const novoEvento = {
            id: existente ? existente.id : gerarId(),
            title: titulo,
            description: campoDescricao.value.trim(),
            date: data,
            time: campoHorario.value || '00:00',
            type: tipo,
            responsible: campoResponsavel.value.trim(),
            createdAt: existente ? existente.createdAt : agora,
            updatedAt: agora
        };

        const eventosAnteriores = eventos;
        eventos = eventos.slice();
        if (existente) {
            const indice = eventos.findIndex(item => item.id === id);
            eventos[indice] = novoEvento;
        } else {
            eventos.push(novoEvento);
        }

        if (!salvarEventos()) {
            eventos = eventosAnteriores;
            return;
        }

        const dataEvento = converterData(data);
        mesExibido = dataEvento.getMonth();
        anoExibido = dataEvento.getFullYear();
        dataSelecionada = data;
        preencherSeletorAnos();
        atualizarSeletores();
        fecharModalEvento();
        renderizarTudo();
    });

    botaoExcluirEvento.addEventListener('click', () => {
        if (campoId.value) excluirEvento(campoId.value);
    });

    // ================================================================
    // 11. CONTROLES, PESQUISA E SINCRONIZAÇÃO
    // ================================================================

    seletorMes.addEventListener('change', () => {
        selecionarMesEAno(Number(seletorMes.value), anoExibido);
    });

    seletorAno.addEventListener('change', () => {
        selecionarMesEAno(mesExibido, Number(seletorAno.value));
    });

    botaoMesAnterior.addEventListener('click', () => navegarMes(-1));
    botaoProximoMes.addEventListener('click', () => navegarMes(1));

    botaoHoje.addEventListener('click', () => {
        const dataHoje = obterDataAtual();
        mesExibido = dataHoje.getMonth();
        anoExibido = dataHoje.getFullYear();
        dataSelecionada = formatarChaveData(dataHoje);
        preencherSeletorAnos();
        atualizarSeletores();
        renderizarTudo();
    });

    botaoAbrirModal.addEventListener('click', () => abrirModalEvento());
    botaoAdicionarDia.addEventListener('click', () => abrirModalEvento());
    botaoFecharModal.addEventListener('click', fecharModalEvento);
    botaoCancelarModal.addEventListener('click', fecharModalEvento);

    modal.addEventListener('click', evento => {
        if (evento.target === modal) fecharModalEvento();
    });

    document.addEventListener('keydown', evento => {
        if (evento.key === 'Escape' && !modal.hidden) fecharModalEvento();
    });

    campoPesquisa.addEventListener('input', () => {
        renderizarCalendario();
        renderizarAgenda();
        renderizarProgramacaoGeral();
    });

    filtroCalendario.addEventListener('change', () => {
        renderizarCalendario();
        renderizarAgenda();
        renderizarProgramacaoGeral();
    });

    ordemProgramacaoGeral.addEventListener('change', renderizarProgramacaoGeral);

    // Atualiza tarefas e eventos quando outra aba modifica os dados.
    window.addEventListener('storage', evento => {
        if (evento.key === null || evento.key.startsWith(PREFIXO_TAREFAS) || evento.key === 'teamwave_quadros_personalizados_v1') {
            carregarNomesQuadrosPersonalizados();
            tarefas = carregarTarefasDoKanban();
            preencherSeletorAnos();
            renderizarTudo();
        }

        if (evento.key === CHAVE_EVENTOS) {
            eventos = carregarEventos();
            preencherSeletorAnos();
            renderizarTudo();
        }
    });

    // Atualiza as informações ao voltar para a página.
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            carregarNomesQuadrosPersonalizados();
            tarefas = carregarTarefasDoKanban();
            eventos = carregarEventos();
            preencherSeletorAnos();
            renderizarTudo();
        }
    });
});
