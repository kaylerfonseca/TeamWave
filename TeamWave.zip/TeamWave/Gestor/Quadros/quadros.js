/* TeamWave - seleção, pesquisa e criação de quadros. */
document.addEventListener('DOMContentLoaded', () => {
    // ================================================================
    // 1. CONFIGURAÇÕES E ELEMENTOS
    // ================================================================
    const CHAVE_QUADROS_PERSONALIZADOS = 'teamwave_quadros_personalizados_v1';
    const CHAVE_QUADRO_ATUAL = 'teamwave_quadro_atual_v1';
    const PREFIXO_FAVORITOS = 'teamwave_kanban_favorito_v1_';
    const CHAVE_FAVORITO_LEGADO = 'teamwave_kanban_favorito_v1';
    const ENDERECO_KANBAN = '../Kanban/kanban.html';
    const VALOR_IMAGEM_ATUAL = '__imagem-atual__';

    const gradeCores = document.getElementById('color-boards');
    const gradeImagens = document.getElementById('image-boards');
    const gradePersonalizados = document.getElementById('custom-boards');
    const secaoPersonalizados = document.getElementById('custom-section');
    const pesquisa = document.getElementById('board-search');
    const modal = document.getElementById('create-board-modal');
    const formulario = document.getElementById('create-board-form');
    const tituloModal = document.getElementById('create-modal-title');
    const botaoSalvarQuadro = formulario.querySelector('[type="submit"]');
    const campoNome = document.getElementById('new-board-name');
    const campoCategoria = document.getElementById('new-board-category');
    const tipoFundo = document.getElementById('board-background-type');
    const campoCor = document.getElementById('board-color-field');
    const campoImagem = document.getElementById('board-image-field');
    const listaCores = document.getElementById('board-color');
    const listaImagens = document.getElementById('board-image');
    const campoImagemUrl = document.getElementById('board-image-url');
    const campoImagemArquivo = document.getElementById('board-image-file');
    const campoCorValor = document.getElementById('board-color-value');
    const avisoSemResultados = document.getElementById('no-results');
    const gradeFavoritos = document.getElementById('favorite-boards');
    const contadorFavoritos = document.getElementById('favorite-board-count');

    // Os quadros coloridos usam cores sólidas como fundo do Kanban.
    const quadrosColoridos = [
        { id: 'team-wave', name: 'TeamWave', category: 'Equipe', type: 'color', value: '#2563eb' },
        { id: 'estrategia', name: 'Estratégia', category: 'Planejamento', type: 'color', value: '#7c3aed' },
        { id: 'operacoes', name: 'Operações', category: 'Equipe', type: 'color', value: '#ea580c' },
        { id: 'marketing', name: 'Marketing', category: 'Equipe', type: 'color', value: '#0f766e' },
        { id: 'projeto', name: 'Projeto', category: 'Projeto', type: 'color', value: '#be123c' },
        { id: 'reunioes', name: 'Reuniões', category: 'Equipe', type: 'color', value: '#334155' },
        { id: 'design', name: 'Design', category: 'Criação', type: 'color', value: '#0891b2' },
        { id: 'planejamento', name: 'Planejamento', category: 'Organização', type: 'color', value: '#4d7c0f' }
    ];

    // Imagens de demonstração usadas nos cartões e como fundo do Kanban.
    const quadrosComImagens = [
        {
            id: 'natureza', name: 'Natureza', category: 'Imagem', type: 'image',
            value: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=85'
        },
        {
            id: 'montanhas', name: 'Montanhas', category: 'Imagem', type: 'image',
            value: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1600&q=85'
        },
        {
            id: 'praia', name: 'Praia', category: 'Imagem', type: 'image',
            value: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1600&q=85'
        },
        {
            id: 'amanhecer', name: 'Amanhecer', category: 'Imagem', type: 'image',
            value: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&w=1600&q=85'
        },
        {
            id: 'ceu-estrelado', name: 'Céu estrelado', category: 'Imagem', type: 'image',
            value: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1600&q=85'
        }
    ];

    // ================================================================
    // 2. ARMAZENAMENTO DOS QUADROS PERSONALIZADOS
    // ================================================================
    function carregarQuadrosPersonalizados() {
        try {
            const dados = JSON.parse(localStorage.getItem(CHAVE_QUADROS_PERSONALIZADOS) || '[]');
            if (!Array.isArray(dados)) return [];

            return dados.filter(quadro =>
                quadro &&
                typeof quadro.id === 'string' &&
                typeof quadro.name === 'string' &&
                quadro.name.trim() &&
                (quadro.type === 'color' || quadro.type === 'image') &&
                typeof quadro.value === 'string'
            ).map(quadro => ({
                id: quadro.id,
                name: quadro.name.trim().slice(0, 45),
                category: typeof quadro.category === 'string' && quadro.category.trim()
                    ? quadro.category.trim().slice(0, 30)
                    : 'Personalizado',
                type: quadro.type,
                value: quadro.value
            }));
        } catch (erro) {
            console.error('Não foi possível carregar os quadros personalizados:', erro);
            return [];
        }
    }

    let quadrosPersonalizados = carregarQuadrosPersonalizados();
    let quadroEmEdicaoId = null;

    function salvarQuadrosPersonalizados() {
        try {
            localStorage.setItem(CHAVE_QUADROS_PERSONALIZADOS, JSON.stringify(quadrosPersonalizados));
            return true;
        } catch (erro) {
            console.error('Não foi possível salvar o quadro personalizado:', erro);
            alert('Não foi possível salvar o quadro neste navegador. Verifique o espaço disponível.');
            return false;
        }
    }

    function excluirAnexosDoQuadro(idsAnexos) {
        if (!idsAnexos.length) return Promise.resolve();

        return new Promise((resolve, reject) => {
            if (!('indexedDB' in window)) {
                reject(new Error('Este navegador não oferece armazenamento de arquivos.'));
                return;
            }

            const pedido = window.indexedDB.open('teamwave_kanban_arquivos_db', 1);
            pedido.onupgradeneeded = () => {
                if (!pedido.result.objectStoreNames.contains('arquivos')) {
                    pedido.result.createObjectStore('arquivos', { keyPath: 'id' });
                }
            };
            pedido.onerror = () => reject(pedido.error || new Error('Não foi possível abrir o armazenamento de anexos.'));
            pedido.onsuccess = () => {
                const banco = pedido.result;
                if (!banco.objectStoreNames.contains('arquivos')) {
                    banco.close();
                    resolve();
                    return;
                }

                let transacao;
                try {
                    transacao = banco.transaction('arquivos', 'readwrite');
                    const armazenagem = transacao.objectStore('arquivos');
                    idsAnexos.forEach(id => armazenagem.delete(id));
                } catch (erro) {
                    banco.close();
                    reject(erro);
                    return;
                }

                transacao.oncomplete = () => {
                    banco.close();
                    resolve();
                };
                transacao.onerror = () => {
                    banco.close();
                    reject(transacao.error || new Error('Não foi possível remover os anexos do quadro.'));
                };
                transacao.onabort = () => {
                    banco.close();
                    reject(transacao.error || new Error('A remoção dos anexos foi cancelada.'));
                };
            };
        });
    }

    async function excluirQuadroPersonalizado(quadro) {
        if (!quadrosPersonalizados.some(item => item.id === quadro.id)) return;
        if (!quadro.id.startsWith('personalizado-') || !/^[a-zA-Z0-9_-]{1,80}$/.test(quadro.id)) {
            alert('Não foi possível excluir este quadro porque seu identificador é inválido.');
            return;
        }

        const chaveTarefas = `teamwave_kanban_tarefas_v1_${quadro.id}`;
        let tarefas;
        try {
            const dados = localStorage.getItem(chaveTarefas);
            tarefas = dados ? JSON.parse(dados) : [];
            if (!Array.isArray(tarefas)) throw new Error('Os dados das tarefas do quadro estão inválidos.');
        } catch (erro) {
            console.error('Não foi possível ler as tarefas do quadro antes da exclusão:', erro);
            alert('Não foi possível ler as tarefas deste quadro. O quadro não foi excluído.');
            return;
        }

        if (tarefas.length > 0) {
            alert('Não é possível excluir este quadro enquanto houver tarefas associadas. Remova ou mova as tarefas primeiro.');
            return;
        }

        if (!window.confirm(`Excluir o quadro "${quadro.name}"? Essa ação não pode ser desfeita.`)) {
            return;
        }

        const idsAnexos = new Set();
        tarefas.forEach(tarefa => {
            ['attachments', 'detailsAttachments'].forEach(chave => {
                if (!Array.isArray(tarefa && tarefa[chave])) return;
                tarefa[chave].forEach(anexo => {
                    if (anexo && typeof anexo.id === 'string') idsAnexos.add(anexo.id);
                });
            });
        });

        const quadrosAnteriores = quadrosPersonalizados;
        quadrosPersonalizados = quadrosPersonalizados.filter(item => item.id !== quadro.id);
        if (!salvarQuadrosPersonalizados()) {
            quadrosPersonalizados = quadrosAnteriores;
            return;
        }

        let erroLimpeza = null;
        try {
            localStorage.removeItem(chaveTarefas);
            localStorage.removeItem(`teamwave_kanban_favorito_v1_${quadro.id}`);

            const quadroAtual = JSON.parse(localStorage.getItem(CHAVE_QUADRO_ATUAL) || 'null');
            if (quadroAtual && quadroAtual.id === quadro.id) {
                localStorage.removeItem(CHAVE_QUADRO_ATUAL);
            }
        } catch (erro) {
            erroLimpeza = erro;
            console.error('O quadro foi removido, mas não foi possível limpar todos os dados locais:', erro);
        }

        try {
            await excluirAnexosDoQuadro([...idsAnexos]);
        } catch (erro) {
            erroLimpeza = erroLimpeza || erro;
            console.error('O quadro foi removido, mas alguns anexos não puderam ser apagados:', erro);
        }

        renderizarQuadros();
        if (erroLimpeza) {
            alert('O quadro foi removido, mas não foi possível limpar todos os dados e anexos vinculados. Consulte o console para mais detalhes.');
        }
    }

    // ================================================================
    // 3. CRIAÇÃO VISUAL DOS CARTÕES
    // ================================================================
    function criarCartaoPersonalizado(quadro) {
        const envoltorio = document.createElement('div');
        envoltorio.className = 'custom-board-card-wrapper';

        const cartao = criarCartaoQuadro(quadro);
        const botaoEditar = document.createElement('button');
        botaoEditar.type = 'button';
        botaoEditar.className = 'edit-custom-board';
        botaoEditar.setAttribute('aria-label', `Editar quadro ${quadro.name}`);
        botaoEditar.title = 'Editar quadro';
        botaoEditar.innerHTML = '<i class="fa-solid fa-pen" aria-hidden="true"></i>';
        botaoEditar.addEventListener('click', evento => {
            evento.preventDefault();
            evento.stopPropagation();
            abrirEdicaoQuadro(quadro);
        });

        const botaoExcluir = document.createElement('button');
        botaoExcluir.type = 'button';
        botaoExcluir.className = 'delete-custom-board';
        botaoExcluir.setAttribute('aria-label', `Excluir quadro ${quadro.name}`);
        botaoExcluir.title = 'Excluir quadro';
        botaoExcluir.innerHTML = '<i class="fa-solid fa-xmark" aria-hidden="true"></i>';
        botaoExcluir.addEventListener('click', evento => {
            evento.preventDefault();
            evento.stopPropagation();
            excluirQuadroPersonalizado(quadro);
        });

        envoltorio.append(cartao, botaoEditar, botaoExcluir);
        return envoltorio;
    }

    function criarCartaoQuadro(quadro) {
        const cartao = document.createElement('a');
        cartao.className = 'board-card';
        cartao.href = `${ENDERECO_KANBAN}?quadro=${encodeURIComponent(quadro.id)}`;
        cartao.dataset.boardName = quadro.name.toLocaleLowerCase('pt-BR');
        cartao.dataset.boardCategory = (quadro.category || '').toLocaleLowerCase('pt-BR');
        cartao.setAttribute('aria-label', `Abrir o quadro ${quadro.name} no Kanban`);

        const capa = document.createElement('div');
        capa.className = 'board-cover';

        if (quadro.type === 'image') {
            capa.style.backgroundImage = `url("${quadro.value}")`;
            capa.style.backgroundColor = '#334155';
        } else {
            capa.style.background = `linear-gradient(135deg, ${quadro.value}, ${quadro.value})`;
        }

        const conteudo = document.createElement('div');
        conteudo.className = 'board-card-content';

        const etiqueta = document.createElement('span');
        etiqueta.className = 'card-tag';
        etiqueta.textContent = quadro.category || (quadro.type === 'image' ? 'Imagem' : 'Quadro');

        const nome = document.createElement('span');
        nome.className = 'card-name';
        nome.textContent = quadro.name;

        const abrir = document.createElement('span');
        abrir.className = 'card-open-hint';
        abrir.innerHTML = '<i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i> Abrir Kanban';

        conteudo.append(etiqueta, nome, abrir);
        cartao.append(capa, conteudo);

        // Salva a identidade e o fundo escolhidos antes de abrir o Kanban.
        cartao.addEventListener('click', () => {
            try {
                localStorage.setItem(CHAVE_QUADRO_ATUAL, JSON.stringify(quadro));
            } catch (erro) {
                console.warn('Não foi possível salvar a aparência do quadro:', erro);
            }
        });

        return cartao;
    }

    function renderizarFavoritos() {
        gradeFavoritos.replaceChildren();

        let idsFavoritos;
        try {
            idsFavoritos = new Set();
            if (localStorage.getItem(CHAVE_FAVORITO_LEGADO) === 'true') {
                idsFavoritos.add('team-wave');
            }

            for (let indice = 0; indice < localStorage.length; indice++) {
                const chave = localStorage.key(indice);
                if (!chave || !chave.startsWith(PREFIXO_FAVORITOS)) continue;

                const id = chave.slice(PREFIXO_FAVORITOS.length);
                if (/^[a-zA-Z0-9_-]{1,80}$/.test(id) && localStorage.getItem(chave) === 'true') {
                    idsFavoritos.add(id);
                }
            }
        } catch (erro) {
            console.error('Não foi possível carregar os quadros favoritos:', erro);
            contadorFavoritos.textContent = 'Indisponível';
            const mensagem = document.createElement('p');
            mensagem.className = 'favorite-boards-empty';
            mensagem.textContent = 'Não foi possível carregar os favoritos neste navegador.';
            gradeFavoritos.append(mensagem);
            return;
        }

        const todosQuadros = [...quadrosColoridos, ...quadrosComImagens, ...quadrosPersonalizados];
        const quadrosFavoritos = todosQuadros.filter(quadro => idsFavoritos.has(quadro.id));
        contadorFavoritos.textContent = `${quadrosFavoritos.length} ${quadrosFavoritos.length === 1 ? 'quadro' : 'quadros'}`;

        if (quadrosFavoritos.length === 0) {
            const mensagem = document.createElement('p');
            mensagem.className = 'favorite-boards-empty';
            mensagem.append(document.createTextNode('Nenhum quadro favoritado ainda. Favorite um quadro no Kanban para encontrá-lo aqui.'));
            gradeFavoritos.append(mensagem);
            return;
        }

        quadrosFavoritos.sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
        quadrosFavoritos.forEach(quadro => {
            const cartao = document.createElement('a');
            cartao.className = 'favorite-board-card';
            cartao.href = `${ENDERECO_KANBAN}?quadro=${encodeURIComponent(quadro.id)}`;
            cartao.dataset.boardName = quadro.name.toLocaleLowerCase('pt-BR');
            cartao.dataset.boardCategory = (quadro.category || '').toLocaleLowerCase('pt-BR');
            cartao.setAttribute('aria-label', `Abrir quadro favorito ${quadro.name} no Kanban`);

            if (quadro.type === 'image') {
                try {
                    let imagemDeFundo = quadro.value;
                    if (imagemDeFundo.startsWith('data:image/')) {
                        cartao.style.backgroundImage = `linear-gradient(rgba(10, 20, 36, .18), rgba(10, 20, 36, .18)), url("${imagemDeFundo}")`;
                    } else {
                        const enderecoImagem = new URL(imagemDeFundo);
                        if (!['https:', 'http:'].includes(enderecoImagem.protocol)) throw new Error('Endereço de imagem não permitido.');
                        cartao.style.backgroundImage = `linear-gradient(rgba(10, 20, 36, .18), rgba(10, 20, 36, .18)), url("${enderecoImagem.href}")`;
                    }
                } catch (erro) {
                    console.warn(`Não foi possível exibir o fundo do quadro "${quadro.name}":`, erro);
                    cartao.style.backgroundColor = '#334155';
                }
            } else if (/^#[0-9a-fA-F]{6}$/.test(quadro.value)) {
                cartao.style.backgroundColor = quadro.value;
            } else {
                cartao.style.backgroundColor = '#334155';
            }

            const nome = document.createElement('span');
            nome.className = 'favorite-board-name';
            nome.textContent = quadro.name;

            const tipo = document.createElement('span');
            tipo.className = 'favorite-board-type';
            tipo.textContent = quadro.type === 'image' ? 'Imagem de fundo' : 'Fundo colorido';
            cartao.append(nome, tipo);

            cartao.addEventListener('click', () => {
                try {
                    localStorage.setItem(CHAVE_QUADRO_ATUAL, JSON.stringify(quadro));
                } catch (erro) {
                    console.warn('Não foi possível salvar a aparência do quadro:', erro);
                }
            });

            gradeFavoritos.append(cartao);
        });
    }

    function renderizarQuadros() {
        gradeCores.replaceChildren();
        gradeImagens.replaceChildren();
        gradePersonalizados.replaceChildren();

        quadrosColoridos.forEach(quadro => gradeCores.append(criarCartaoQuadro(quadro)));
        quadrosComImagens.forEach(quadro => gradeImagens.append(criarCartaoQuadro(quadro)));

        quadrosPersonalizados.forEach(quadro => {
            gradePersonalizados.append(criarCartaoPersonalizado(quadro));
        });

        secaoPersonalizados.hidden = quadrosPersonalizados.length === 0;
        document.getElementById('color-board-count').textContent = `${quadrosColoridos.length} quadros`;
        document.getElementById('image-board-count').textContent = `${quadrosComImagens.length} quadros`;
        document.getElementById('custom-board-count').textContent = `${quadrosPersonalizados.length} quadros`;
        renderizarFavoritos();
        aplicarPesquisa();
    }

    // ================================================================
    // 4. PESQUISA DOS QUADROS
    // ================================================================
    function aplicarPesquisa() {
        const termo = pesquisa.value.toLocaleLowerCase('pt-BR').trim();
        let quantidadeVisivel = 0;

        document.querySelectorAll('.board-card').forEach(cartao => {
            const corresponde = cartao.dataset.boardName.includes(termo) ||
                cartao.dataset.boardCategory.includes(termo);
            cartao.hidden = !corresponde;
            const envoltorio = cartao.closest('.custom-board-card-wrapper');
            if (envoltorio) envoltorio.hidden = !corresponde;
            if (corresponde) quantidadeVisivel++;
        });

        document.querySelectorAll('.favorite-board-card').forEach(cartao => {
            cartao.hidden = !cartao.dataset.boardName.includes(termo) &&
                !cartao.dataset.boardCategory.includes(termo);
        });

        document.querySelectorAll('[data-board-section]').forEach(secao => {
            const cartoesVisiveis = secao.querySelectorAll('.board-card:not([hidden])').length;
            secao.hidden = cartoesVisiveis === 0;
        });

        const secaoFavoritos = document.querySelector('.favorite-boards-section');
        if (secaoFavoritos) {
            const favoritosVisiveis = secaoFavoritos.querySelectorAll('.favorite-board-card:not([hidden])').length;
            secaoFavoritos.hidden = favoritosVisiveis === 0 && Boolean(termo);
        }

        avisoSemResultados.hidden = quantidadeVisivel > 0;
    }

    pesquisa.addEventListener('input', aplicarPesquisa);

    // ================================================================
    // 5. MODAL DE CRIAÇÃO DE QUADROS
    // ================================================================
    function removerOpcaoImagemAtual() {
        const opcaoAtual = listaImagens.querySelector('option[data-current-image]');
        if (opcaoAtual) opcaoAtual.remove();
    }

    function abrirModal() {
        quadroEmEdicaoId = null;
        removerOpcaoImagemAtual();
        formulario.reset();
        tituloModal.textContent = 'Criar quadro';
        botaoSalvarQuadro.innerHTML = '<i class="fa-solid fa-check" aria-hidden="true"></i> Criar quadro';
        atualizarCamposDeFundo();
        modal.hidden = false;
        document.body.classList.add('modal-open');
        campoNome.focus();
    }

    function fecharModal() {
        modal.hidden = true;
        document.body.classList.remove('modal-open');
        quadroEmEdicaoId = null;
        removerOpcaoImagemAtual();
        formulario.reset();
        tituloModal.textContent = 'Criar quadro';
        botaoSalvarQuadro.innerHTML = '<i class="fa-solid fa-check" aria-hidden="true"></i> Criar quadro';
        atualizarCamposDeFundo();
    }

    function abrirEdicaoQuadro(quadro) {
        const quadroAtual = quadrosPersonalizados.find(item => item.id === quadro.id);
        if (!quadroAtual) {
            alert('Não foi possível encontrar este quadro para edição.');
            return;
        }

        quadroEmEdicaoId = quadroAtual.id;
        removerOpcaoImagemAtual();
        formulario.reset();
        campoNome.value = quadroAtual.name;
        campoCategoria.value = quadroAtual.category;
        tipoFundo.value = quadroAtual.type;

        if (quadroAtual.type === 'image') {
            const opcaoDisponivel = Array.from(listaImagens.options)
                .some(opcao => opcao.value === quadroAtual.value);
            if (opcaoDisponivel) {
                listaImagens.value = quadroAtual.value;
            } else {
                const opcaoAtual = document.createElement('option');
                opcaoAtual.value = VALOR_IMAGEM_ATUAL;
                opcaoAtual.dataset.currentImage = 'true';
                opcaoAtual.textContent = 'Manter imagem atual';
                listaImagens.append(opcaoAtual);
                listaImagens.value = VALOR_IMAGEM_ATUAL;
            }
            if (validarEnderecoImagem(quadroAtual.value)) {
                campoImagemUrl.value = quadroAtual.value;
            }
        } else {
            listaCores.value = quadroAtual.value;
        }

        if (campoCorValor) campoCorValor.textContent = listaCores.value.toUpperCase();
        tituloModal.textContent = 'Editar quadro';
        botaoSalvarQuadro.innerHTML = '<i class="fa-solid fa-check" aria-hidden="true"></i> Salvar alterações';
        atualizarCamposDeFundo();
        modal.hidden = false;
        document.body.classList.add('modal-open');
        campoNome.focus();
    }

    function atualizarCamposDeFundo() {
        const usarImagem = tipoFundo.value === 'image';
        campoImagem.hidden = !usarImagem;
        campoCor.hidden = usarImagem;
    }

    document.getElementById('open-create-modal').addEventListener('click', abrirModal);
    document.getElementById('close-create-modal').addEventListener('click', fecharModal);
    document.getElementById('cancel-create-board').addEventListener('click', fecharModal);
    tipoFundo.addEventListener('change', atualizarCamposDeFundo);
    listaImagens.addEventListener('change', () => {
        if (listaImagens.value !== VALOR_IMAGEM_ATUAL) {
            campoImagemUrl.value = '';
            campoImagemArquivo.value = '';
        }
    });

    listaCores.addEventListener('input', () => {
        if (campoCorValor) campoCorValor.textContent = listaCores.value.toUpperCase();
    });

    // Redimensiona imagens enviadas para economizar espaço no armazenamento local.
    function converterImagemParaBase64(arquivo) {
        return new Promise((resolve, reject) => {
            if (!arquivo || !arquivo.type.startsWith('image/')) {
                reject(new Error('Selecione um arquivo de imagem válido.'));
                return;
            }
            if (arquivo.size > 12 * 1024 * 1024) {
                reject(new Error('A imagem deve ter no máximo 12 MB.'));
                return;
            }
            const leitor = new FileReader();
            leitor.onerror = () => reject(new Error('Não foi possível ler a imagem.'));
            leitor.onload = () => {
                const imagem = new Image();
                imagem.onerror = () => reject(new Error('O arquivo selecionado não é uma imagem válida.'));
                imagem.onload = () => {
                    const escala = Math.min(1, 1600 / Math.max(imagem.width, imagem.height));
                    const canvas = document.createElement('canvas');
                    canvas.width = Math.max(1, Math.round(imagem.width * escala));
                    canvas.height = Math.max(1, Math.round(imagem.height * escala));
                    canvas.getContext('2d').drawImage(imagem, 0, 0, canvas.width, canvas.height);
                    resolve(canvas.toDataURL('image/jpeg', 0.78));
                };
                imagem.src = leitor.result;
            };
            leitor.readAsDataURL(arquivo);
        });
    }

    function validarEnderecoImagem(endereco) {
        try {
            const url = new URL(endereco);
            return url.protocol === 'https:' || url.protocol === 'http:';
        } catch (erro) {
            return false;
        }
    }

    modal.addEventListener('click', evento => {
        if (evento.target === modal) fecharModal();
    });

    document.addEventListener('keydown', evento => {
        if (evento.key === 'Escape' && !modal.hidden) fecharModal();
    });

    formulario.addEventListener('submit', async evento => {
        evento.preventDefault();

        const nome = campoNome.value.trim();
        if (!nome) {
            alert('Digite um nome para o quadro.');
            campoNome.focus();
            return;
        }

        const categoria = campoCategoria.value.trim();
        if (!categoria) {
            alert('Digite uma categoria para o quadro.');
            campoCategoria.focus();
            return;
        }

        const quadroExistente = quadroEmEdicaoId
            ? quadrosPersonalizados.find(item => item.id === quadroEmEdicaoId)
            : null;
        if (quadroEmEdicaoId && !quadroExistente) {
            alert('Este quadro não está mais disponível para edição. Atualize a página e tente novamente.');
            fecharModal();
            return;
        }

        const ehImagem = tipoFundo.value === 'image';
        let valorFundo = listaCores.value;

        if (ehImagem) {
            const arquivo = campoImagemArquivo.files[0];
            const enderecoDigitado = campoImagemUrl.value.trim();
            try {
                if (arquivo) {
                    valorFundo = await converterImagemParaBase64(arquivo);
                    if (valorFundo.length > 2500000) {
                        alert('A imagem ficou muito grande para ser salva. Escolha uma imagem menor.');
                        return;
                    }
                } else if (enderecoDigitado) {
                    if (!validarEnderecoImagem(enderecoDigitado)) {
                        alert('Informe um endereço válido começando com http:// ou https://.');
                        campoImagemUrl.focus();
                        return;
                    }
                    valorFundo = enderecoDigitado;
                } else if (
                    quadroExistente &&
                    quadroExistente.type === 'image' &&
                    listaImagens.value === VALOR_IMAGEM_ATUAL
                ) {
                    valorFundo = quadroExistente.value;
                } else {
                    valorFundo = listaImagens.value;
                }
            } catch (erro) {
                alert(erro.message || 'Não foi possível carregar a imagem escolhida.');
                return;
            }
        }

        const dadosAtualizados = {
            name: nome.slice(0, 45),
            category: categoria.slice(0, 30),
            type: ehImagem ? 'image' : 'color',
            value: valorFundo
        };

        if (quadroExistente) {
            const dadosAnteriores = { ...quadroExistente };
            Object.assign(quadroExistente, dadosAtualizados);
            if (!salvarQuadrosPersonalizados()) {
                Object.assign(quadroExistente, dadosAnteriores);
                return;
            }

            try {
                const quadroAtual = JSON.parse(localStorage.getItem(CHAVE_QUADRO_ATUAL) || 'null');
                if (quadroAtual && quadroAtual.id === quadroExistente.id) {
                    localStorage.setItem(CHAVE_QUADRO_ATUAL, JSON.stringify(quadroExistente));
                }
            } catch (erro) {
                console.warn('O quadro foi atualizado, mas não foi possível sincronizar sua aparência atual:', erro);
                alert('O quadro foi atualizado, mas talvez seja necessário reabri-lo para atualizar sua aparência.');
            }
        } else {
            const quadro = {
                id: `personalizado-${Date.now()}-${Math.random().toString(16).slice(2, 7)}`,
                ...dadosAtualizados
            };
            quadrosPersonalizados.push(quadro);
            if (!salvarQuadrosPersonalizados()) {
                quadrosPersonalizados = quadrosPersonalizados.filter(item => item.id !== quadro.id);
                return;
            }
        }

        renderizarQuadros();
        fecharModal();
    });

    // Inicializa a galeria.
    renderizarQuadros();

    window.addEventListener('storage', evento => {
        if (
            evento.key === null ||
            evento.key === CHAVE_QUADROS_PERSONALIZADOS ||
            evento.key === CHAVE_FAVORITO_LEGADO ||
            (evento.key && evento.key.startsWith(PREFIXO_FAVORITOS))
        ) {
            quadrosPersonalizados = carregarQuadrosPersonalizados();
            renderizarQuadros();
        }
    });

    window.addEventListener('focus', () => {
        quadrosPersonalizados = carregarQuadrosPersonalizados();
        renderizarQuadros();
    });
});