// Conteúdos exibidos nos modais ao clicar no rodapé
const conteudosModais = {
    termos: {
        titulo: "Termos de Uso",
        texto: "Bem-vindo ao TeamWave. Ao utilizar nossa plataforma de gestão de projetos, você concorda em cumprir e respeitar todas as diretrizes de uso responsável, segurança de dados e boas práticas colaborativas estabelecidas pela nossa equipe."
    },
    privacidade: {
        titulo: "Política de Privacidade",
        texto: "Na TeamWave, a proteção dos seus dados é prioridade. Garantimos que todas as informações cadastrais e corporativas informadas em nossa plataforma são tratadas com criptografia e confidencialidade absoluta, em conformidade com as leis de privacidade vigentes."
    },
    suporte: {
        titulo: "Central de Suporte",
        texto: "Precisa de ajuda com a sua conta, recuperação de senha ou configuração de equipes? Nossa equipe de suporte está disponível de segunda a sexta, das 13h às 18h, através do e-mail teamwave@grupo.com ou telefone (13) 99999-9999."
    }
};

// Função para abrir o modal de acordo com a opção selecionada
function abrirModal(tipo) {
    const overlay = document.getElementById('modalOverlay');
    const titulo = document.getElementById('modalTitulo');
    const texto = document.getElementById('modalTexto');

    if (conteudosModais[tipo]) {
        titulo.innerText = conteudosModais[tipo].titulo;
        texto.innerText = conteudosModais[tipo].texto;
        overlay.classList.add('ativo');
    }
}

// Função para fechar o modal
function fecharModal() {
    const overlay = document.getElementById('modalOverlay');
    overlay.classList.remove('ativo');
}

// Fecha o modal se o usuário clicar no fundo escuro fora da caixa
function fecharModalFora(event) {
    const overlay = document.getElementById('modalOverlay');
    if (event.target === overlay) {
        fecharModal();
    }
}



// Interação dos cartões de recursos:
// hover/foco mostra a descrição; clique mantém aberta em telas sensíveis ao toque.
document.addEventListener('DOMContentLoaded', function () {
    const itensRecursos = document.querySelectorAll('.item-recurso');

    itensRecursos.forEach(function (item) {
        const botao = item.querySelector('.cartao-recurso');
        if (!botao) return;

        function atualizarEstado() {
            const expandido = item.classList.contains('ativo') ||
                item.matches(':hover') ||
                item.contains(document.activeElement);

            botao.setAttribute('aria-expanded', String(expandido));
        }

        botao.addEventListener('click', function () {
            item.classList.toggle('ativo');
            atualizarEstado();
        });

        item.addEventListener('pointerenter', atualizarEstado);
        item.addEventListener('pointerleave', atualizarEstado);
        item.addEventListener('focusin', atualizarEstado);
        item.addEventListener('focusout', function () {
            requestAnimationFrame(atualizarEstado);
        });
    });
});

// Manipulação do envio do formulário de contato com aviso de sucesso
document.addEventListener('DOMContentLoaded', function() {
    const formContato = document.getElementById('formContato');
    if (formContato) {
        formContato.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
            this.reset();
        });
    }
});