/* TeamWave - funcionamento do quadro Kanban (JavaScript puro) */
document.addEventListener('DOMContentLoaded', () => {
    // ================================================================
    // 1. CONFIGURAÇÕES E ELEMENTOS DA INTERFACE
    // ================================================================
    // Cada quadro recebe uma chave própria. O quadro TeamWave mantém a chave
    // antiga para preservar as tarefas já cadastradas antes desta atualização.
    const parametros = new URLSearchParams(window.location.search);
    const ID_QUADRO = (parametros.get('quadro') || 'team-wave').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80) || 'team-wave';
    const CHAVE_QUADRO_ATUAL = 'teamwave_quadro_atual_v1';
    const CHAVE_QUADROS_PERSONALIZADOS = 'teamwave_quadros_personalizados_v1';
    const CHAVE_USUARIOS = 'teamwave_usuarios';
    const QUADRO_LEGADO = ID_QUADRO === 'team-wave';
    const CHAVE_ARMAZENAMENTO = QUADRO_LEGADO
        ? 'teamwave_kanban_tarefas_v1'
        : `teamwave_kanban_tarefas_v1_${ID_QUADRO}`;
    const CHAVE_FAVORITO = QUADRO_LEGADO
        ? 'teamwave_kanban_favorito_v1'
        : `teamwave_kanban_favorito_v1_${ID_QUADRO}`;
    const BANCO_ANEXOS = 'teamwave_kanban_arquivos_db';
    const colunas = Array.from(document.querySelectorAll('.column[data-status]'));
    const statusPermitidos = colunas.map(coluna => coluna.dataset.status);
    const campoPesquisa = document.getElementById('search-input');
    const areaKanban = document.querySelector('.board-container');
    const nomeQuadro = document.getElementById('board-name');
    const areaMembrosEquipe = document.querySelector('.team-members');
    const botaoMembrosEquipe = document.getElementById('open-team-members');
    const painelMembrosEquipe = document.getElementById('team-members-panel');
    const listaMembrosEquipe = document.getElementById('team-members-list');
    const mensagemMembrosEquipe = document.getElementById('team-members-message');
    const botaoSeletorQuadros = document.getElementById('open-board-selector');
    const modalSeletorQuadros = document.getElementById('board-selector-modal');
    const gradeSeletorQuadros = document.getElementById('board-choices');
    const botaoFecharSeletor = document.getElementById('close-board-selector');
    const modalDetalhesTarefa = document.getElementById('task-details-modal');
    const tituloDetalhesTarefa = document.getElementById('task-details-title');
    const statusDetalhesTarefa = document.getElementById('task-details-status');
    const campoDescricaoTarefa = document.getElementById('task-details-description');
    const campoArquivosTarefa = document.getElementById('task-details-files');
    const botaoAdicionarArquivos = document.getElementById('open-task-details-files');
    const listaAnexosTarefa = document.getElementById('task-details-attachments');
    const formularioChecklist = document.getElementById('task-checklist-form');
    const campoNovoChecklist = document.getElementById('task-checklist-input');
    const listaChecklist = document.getElementById('task-checklist');
    const listaComentarios = document.getElementById('task-comments-list');
    const formularioComentario = document.getElementById('task-comment-form');
    const campoComentario = document.getElementById('task-comment-input');
    const mensagemDetalhes = document.getElementById('task-details-message');
    const botaoFecharDetalhes = document.getElementById('close-task-details');
    const LIMITE_ARQUIVO = 25 * 1024 * 1024;
    const LIMITE_ANEXOS_DETALHES = 10;
    const anexosDetalhesEmProcessamento = new Map();

    function renderizarMembrosEquipe() {
        listaMembrosEquipe.replaceChildren();
        mensagemMembrosEquipe.hidden = true;
        mensagemMembrosEquipe.textContent = '';

        try {
            const dados = JSON.parse(localStorage.getItem(CHAVE_USUARIOS) || '[]');
            if (!Array.isArray(dados)) {
                throw new Error('A lista de pessoas cadastradas não é válida.');
            }

            const nomes = dados
                .filter(usuario => usuario && typeof usuario.nome === 'string' && usuario.nome.trim())
                .map(usuario => usuario.nome.trim())
                .sort((a, b) => a.localeCompare(b, 'pt-BR'));

            if (nomes.length === 0) {
                mensagemMembrosEquipe.textContent = 'Nenhuma pessoa cadastrada foi encontrada.';
                mensagemMembrosEquipe.hidden = false;
                return;
            }

            nomes.forEach(nome => {
                const item = document.createElement('li');
                item.textContent = nome;
                listaMembrosEquipe.append(item);
            });
        } catch (erro) {
            console.error('Não foi possível carregar as pessoas cadastradas:', erro);
            mensagemMembrosEquipe.textContent = 'Não foi possível carregar a lista de pessoas cadastradas.';
            mensagemMembrosEquipe.hidden = false;
        }
    }

    function fecharPainelMembrosEquipe() {
        painelMembrosEquipe.hidden = true;
        botaoMembrosEquipe.setAttribute('aria-expanded', 'false');
    }

    botaoMembrosEquipe.addEventListener('click', () => {
        const abrir = painelMembrosEquipe.hidden;
        if (abrir) renderizarMembrosEquipe();
        painelMembrosEquipe.hidden = !abrir;
        botaoMembrosEquipe.setAttribute('aria-expanded', String(abrir));
    });

    document.addEventListener('click', evento => {
        if (!areaMembrosEquipe.contains(evento.target)) fecharPainelMembrosEquipe();
    });

    document.addEventListener('keydown', evento => {
        if (evento.key === 'Escape' && !painelMembrosEquipe.hidden) {
            fecharPainelMembrosEquipe();
            botaoMembrosEquipe.focus();
        }
    });

    window.addEventListener('storage', evento => {
        if (evento.key === CHAVE_USUARIOS || evento.key === null) renderizarMembrosEquipe();
    });

    const QUADROS_PREDEFINIDOS = [
        { id: 'team-wave', name: 'TeamWave', type: 'color', value: '#2563eb' },
        { id: 'estrategia', name: 'Estratégia', type: 'color', value: '#7c3aed' },
        { id: 'operacoes', name: 'Operações', type: 'color', value: '#ea580c' },
        { id: 'marketing', name: 'Marketing', type: 'color', value: '#0f766e' },
        { id: 'projeto', name: 'Projeto', type: 'color', value: '#be123c' },
        { id: 'reunioes', name: 'Reuniões', type: 'color', value: '#334155' },
        { id: 'design', name: 'Design', type: 'color', value: '#0891b2' },
        { id: 'planejamento', name: 'Planejamento', type: 'color', value: '#4d7c0f' },
        { id: 'natureza', name: 'Natureza', type: 'image', value: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=85' },
        { id: 'montanhas', name: 'Montanhas', type: 'image', value: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1600&q=85' },
        { id: 'praia', name: 'Praia', type: 'image', value: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1600&q=85' },
        { id: 'amanhecer', name: 'Amanhecer', type: 'image', value: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&w=1600&q=85' },
        { id: 'ceu-estrelado', name: 'Céu estrelado', type: 'image', value: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1600&q=85' }
    ];

    function obterEnderecoImagemPermitido(valor) {
        if (typeof valor !== 'string') return '';
        if (/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(valor)) return valor;

        try {
            const endereco = new URL(valor);
            return endereco.protocol === 'https:' || endereco.protocol === 'http:' ? endereco.href : '';
        } catch {
            return '';
        }
    }

    // Recupera os dados que a página Quadros salvou antes de abrir este Kanban.
    function carregarConfiguracaoQuadro() {
        try {
            const salvo = JSON.parse(localStorage.getItem(CHAVE_QUADRO_ATUAL) || 'null');
            if (salvo && salvo.id === ID_QUADRO) return salvo;
        } catch (erro) {
            console.warn('Não foi possível ler a aparência do quadro:', erro);
        }

        return { id: ID_QUADRO, name: ID_QUADRO === 'team-wave' ? 'TeamWave' : ID_QUADRO, type: 'color', value: '#2563eb' };
    }

    const quadroAtual = carregarConfiguracaoQuadro();

    function aplicarConfiguracaoQuadro() {
        const nome = String(quadroAtual.name || 'TeamWave').trim().slice(0, 45) || 'TeamWave';
        nomeQuadro.textContent = nome;
        document.title = `TeamWave | ${nome}`;

        if (quadroAtual.type === 'image') {
            try {
                const enderecoImagem = obterEnderecoImagemPermitido(quadroAtual.value);
                if (!enderecoImagem) throw new Error('Endereço de imagem não permitido.');

                areaKanban.style.backgroundColor = '#334155';
                areaKanban.style.backgroundImage = `linear-gradient(rgba(15, 23, 42, .28), rgba(15, 23, 42, .28)), url("${enderecoImagem}")`;
                areaKanban.style.backgroundPosition = 'center';
                areaKanban.style.backgroundSize = 'cover';
                areaKanban.style.backgroundRepeat = 'no-repeat';
                areaKanban.classList.add('has-image-background');
                areaKanban.classList.remove('has-color-background');
            } catch (erro) {
                console.warn('A imagem de fundo não pôde ser aplicada:', erro);
            }
        } else {
            const cor = /^#[0-9a-fA-F]{6}$/.test(String(quadroAtual.value)) ? quadroAtual.value : '#2563eb';
            areaKanban.style.backgroundColor = cor;
            areaKanban.style.backgroundImage = 'none';
            areaKanban.classList.add('has-color-background');
            areaKanban.classList.remove('has-image-background');
        }
    }

    aplicarConfiguracaoQuadro();

    function carregarQuadrosDisponiveis() {
        try {
            const personalizados = JSON.parse(localStorage.getItem(CHAVE_QUADROS_PERSONALIZADOS) || '[]');
            if (!Array.isArray(personalizados)) {
                throw new Error('A lista de quadros personalizados não é válida.');
            }

            const validos = personalizados.filter(quadro => {
                if (
                    !quadro ||
                    typeof quadro.id !== 'string' ||
                    !/^[a-zA-Z0-9_-]{1,80}$/.test(quadro.id) ||
                    typeof quadro.name !== 'string' ||
                    !quadro.name.trim() ||
                    (quadro.type !== 'color' && quadro.type !== 'image') ||
                    typeof quadro.value !== 'string'
                ) {
                    return false;
                }

                if (quadro.type === 'color') {
                    return /^#[0-9a-fA-F]{6}$/.test(quadro.value);
                }

                return Boolean(obterEnderecoImagemPermitido(quadro.value));
            }).map(quadro => ({
                id: quadro.id,
                name: quadro.name.trim().slice(0, 45),
                type: quadro.type,
                value: quadro.value
            }));

            return [...QUADROS_PREDEFINIDOS, ...validos];
        } catch (erro) {
            console.error('Não foi possível carregar os quadros disponíveis:', erro);
            return QUADROS_PREDEFINIDOS;
        }
    }

    function renderizarSeletorQuadros() {
        gradeSeletorQuadros.replaceChildren();

        carregarQuadrosDisponiveis().forEach(quadro => {
            const opcao = document.createElement('button');
            opcao.className = 'board-choice';
            opcao.type = 'button';
            opcao.setAttribute('aria-pressed', String(quadro.id === ID_QUADRO));
            opcao.setAttribute('aria-label', `Abrir quadro ${quadro.name}`);

            const capa = document.createElement('span');
            capa.className = 'board-choice-cover';

            const tipo = document.createElement('span');
            tipo.className = 'board-choice-type';
            tipo.textContent = quadro.type === 'image' ? 'Imagem' : 'Cor';

            if (quadro.type === 'image') {
                capa.style.backgroundColor = '#334155';
                capa.style.backgroundImage = `linear-gradient(rgba(15, 23, 42, .20), rgba(15, 23, 42, .20)), url("${obterEnderecoImagemPermitido(quadro.value)}")`;
            } else {
                capa.style.background = quadro.value;
            }

            const nome = document.createElement('span');
            nome.className = 'board-choice-name';
            nome.textContent = quadro.name;

            opcao.append(capa, nome, tipo);
            opcao.addEventListener('click', () => selecionarQuadro(quadro));
            gradeSeletorQuadros.append(opcao);
        });
    }

    function abrirSeletorQuadros() {
        renderizarSeletorQuadros();
        modalSeletorQuadros.hidden = false;
        botaoSeletorQuadros.setAttribute('aria-expanded', 'true');
        document.body.classList.add('modal-open');
        const primeiraOpcao = gradeSeletorQuadros.querySelector('.board-choice');
        (primeiraOpcao || botaoFecharSeletor).focus();
    }

    function fecharSeletorQuadros() {
        modalSeletorQuadros.hidden = true;
        botaoSeletorQuadros.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('modal-open');
        botaoSeletorQuadros.focus();
    }

    function selecionarQuadro(quadro) {
        try {
            localStorage.setItem(CHAVE_QUADRO_ATUAL, JSON.stringify(quadro));
        } catch (erro) {
            console.error('Não foi possível salvar o quadro selecionado:', erro);
            alert('Não foi possível salvar a seleção do quadro neste navegador.');
            return;
        }

        const enderecoKanban = new URL(window.location.href);
        enderecoKanban.searchParams.set('quadro', quadro.id);
        window.location.assign(enderecoKanban.href);
    }

    let tarefas = carregarTarefas();
    let idArrastado = null;
    let idTarefaAberta = null;
    let cartaoFoiArrastado = false;

    // ================================================================
    // 2. ARMAZENAMENTO DE ANEXOS (INDEXEDDB)
    // Os dados das tarefas ficam no localStorage; os arquivos ficam no IndexedDB.
    // ================================================================
    const bancoAnexos = abrirBancoAnexos().catch(erro => {
        console.error('Não foi possível inicializar o armazenamento de anexos:', erro);
        return null;
    });

    // Abre o banco e cria a coleção de arquivos quando necessário.
    function abrirBancoAnexos() {
        return new Promise((resolve, reject) => {
            if (!('indexedDB' in window)) {
                reject(new Error('Este navegador não oferece armazenamento local de arquivos.'));
                return;
            }

            const pedido = window.indexedDB.open(BANCO_ANEXOS, 1);

            pedido.onupgradeneeded = () => {
                const banco = pedido.result;
                if (!banco.objectStoreNames.contains('arquivos')) {
                    banco.createObjectStore('arquivos', { keyPath: 'id' });
                }
            };

            pedido.onsuccess = () => resolve(pedido.result);
            pedido.onerror = () => reject(pedido.error || new Error('Falha ao abrir o armazenamento de anexos.'));
        });
    }

    // Retorna a conexão pronta ou informa que o banco não está disponível.
    async function obterBancoAnexos() {
        const banco = await bancoAnexos;
        if (!banco) throw new Error('Não foi possível acessar o armazenamento de arquivos deste navegador.');
        return banco;
    }

    // Busca um arquivo pelo ID salvo nos dados da tarefa.
    function buscarAnexo(id) {
        return obterBancoAnexos().then(banco => new Promise((resolve, reject) => {
            const transacao = banco.transaction('arquivos', 'readonly');
            const pedido = transacao.objectStore('arquivos').get(id);

            pedido.onsuccess = () => resolve(pedido.result || null);
            pedido.onerror = () => reject(pedido.error || new Error('Não foi possível ler o arquivo anexado.'));
        }));
    }

    function armazenarAnexo(id, arquivo) {
        return obterBancoAnexos().then(banco => new Promise((resolve, reject) => {
            const transacao = banco.transaction('arquivos', 'readwrite');
            transacao.objectStore('arquivos').put({
                id,
                name: arquivo.name,
                type: arquivo.type || 'application/octet-stream',
                size: arquivo.size,
                blob: arquivo
            });

            transacao.oncomplete = () => resolve();
            transacao.onerror = () => reject(transacao.error || new Error('Não foi possível salvar o arquivo anexado.'));
            transacao.onabort = () => reject(transacao.error || new Error('O salvamento do arquivo foi cancelado.'));
        }));
    }

    function excluirAnexoDoBanco(id) {
        return obterBancoAnexos().then(banco => new Promise((resolve, reject) => {
            const transacao = banco.transaction('arquivos', 'readwrite');
            transacao.objectStore('arquivos').delete(id);

            transacao.oncomplete = () => resolve();
            transacao.onerror = () => reject(transacao.error || new Error('Não foi possível remover o arquivo anexado.'));
        }));
    }

    // Gera IDs únicos para tarefas e anexos.
    function gerarId() {
        if (window.crypto && typeof window.crypto.randomUUID === 'function') {
            return window.crypto.randomUUID();
        }

        return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    }

    // Mantém nos dados da tarefa apenas os metadados dos anexos.
    function metadadosAnexos(anexos) {
        if (!Array.isArray(anexos)) return [];

        return anexos.filter(anexo => anexo && typeof anexo.name === 'string' && anexo.name.trim())
            .map(anexo => ({
                id: String(anexo.id || gerarId()),
                name: anexo.name.trim().slice(0, 255),
                type: String(anexo.type || 'application/octet-stream'),
                size: Math.max(0, Number(anexo.size) || 0)
            }));
    }

    // ================================================================
    // 3. LEITURA, VALIDAÇÃO E SALVAMENTO DAS TAREFAS
    // ================================================================

    function carregarTarefas() {
        try {
            const dados = localStorage.getItem(CHAVE_ARMAZENAMENTO);
            if (!dados) return [];

            const tarefasSalvas = JSON.parse(dados);
            if (!Array.isArray(tarefasSalvas)) return [];

            return tarefasSalvas
                .filter(tarefa => tarefa && typeof tarefa.title === 'string' && tarefa.title.trim())
                .map(tarefa => ({
                    id: String(tarefa.id || gerarId()),
                    title: String(tarefa.title).trim(),
                    description: String(tarefa.description || ''),
                    detailsDescription: String(tarefa.detailsDescription || ''),
                    responsible: String(tarefa.responsible || ''),
                    priority: ['Baixa', 'Média', 'Alta', 'Urgente'].includes(tarefa.priority) ? tarefa.priority : 'Média',
                    dueDate: validarData(tarefa.dueDate),
                    status: statusPermitidos.includes(tarefa.status) ? tarefa.status : 'A Fazer',
                    attachments: metadadosAnexos(tarefa.attachments),
                    detailsAttachments: metadadosAnexos(tarefa.detailsAttachments),
                    checklist: Array.isArray(tarefa.checklist)
                        ? tarefa.checklist.filter(item => item && typeof item.text === 'string' && item.text.trim())
                            .map(item => ({
                                id: String(item.id || gerarId()),
                                text: item.text.trim().slice(0, 160),
                                completed: Boolean(item.completed)
                            }))
                        : [],
                    comments: Array.isArray(tarefa.comments)
                        ? tarefa.comments.filter(comment => comment && typeof comment.text === 'string' && comment.text.trim())
                            .map(comment => ({
                                id: String(comment.id || gerarId()),
                                text: comment.text.trim().slice(0, 1000),
                                author: String(comment.author || 'Pessoa').slice(0, 100),
                                createdAt: comment.createdAt || new Date().toISOString()
                            }))
                        : [],
                    createdAt: tarefa.createdAt || new Date().toISOString(),
                    updatedAt: tarefa.updatedAt || new Date().toISOString()
                }));
        } catch (erro) {
            console.error('Não foi possível carregar as tarefas salvas:', erro);
            alert('Não foi possível ler as tarefas salvas. O quadro será aberto vazio.');
            return [];
        }
    }

    function salvarTarefas() {
        try {
            localStorage.setItem(CHAVE_ARMAZENAMENTO, JSON.stringify(tarefas));
            return true;
        } catch (erro) {
            console.error('Não foi possível salvar a movimentação da tarefa:', erro);
            alert('Não foi possível salvar as alterações da tarefa. Verifique o espaço disponível e as permissões de armazenamento.');
            return false;
        }
    }

    // Valida uma data no formato AAAA-MM-DD.
    function validarData(valor) {
        if (typeof valor !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(valor)) return '';

        const data = new Date(`${valor}T12:00:00`);
        return Number.isNaN(data.getTime()) ? '' : valor;
    }

    // Padroniza textos para que a pesquisa não diferencie maiúsculas de minúsculas.
    function normalizarTexto(valor) {
        return String(valor || '').toLocaleLowerCase('pt-BR').trim();
    }

    function formatarData(valor) {
        if (!valor) return '';

        const partes = valor.split('-');
        if (partes.length !== 3) return valor;

        return `${partes[2]}/${partes[1]}/${partes[0]}`;
    }

    // Verifica se uma tarefa tem prazo anterior ao dia atual.
    function prazoAtrasado(valor) {
        if (!valor) return false;

        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);

        const prazo = new Date(`${valor}T12:00:00`);
        prazo.setHours(0, 0, 0, 0);

        return prazo < hoje;
    }

    // ================================================================
    // 4. ELEMENTOS E ANEXOS DO FORMULÁRIO
    // ================================================================

    function criarElemento(tag, classe, texto) {
        const elemento = document.createElement(tag);
        if (classe) elemento.className = classe;
        if (texto !== undefined) elemento.textContent = texto;

        return elemento;
    }

    function criarBotaoAcao(classe, titulo, icone, rotulo) {
        const botao = document.createElement('button');
        botao.type = 'button';
        botao.className = classe;
        botao.title = titulo;
        botao.setAttribute('aria-label', titulo);

        const simbolo = document.createElement('i');
        simbolo.className = icone;
        simbolo.setAttribute('aria-hidden', 'true');
        botao.append(simbolo);

        if (rotulo) botao.append(document.createTextNode(` ${rotulo}`));

        return botao;
    }

    // ================================================================
    // 5. CARTÕES, COLUNAS E PESQUISA
    // ================================================================

    // Monta um cartão para consulta, movimentação e download dos anexos.
    function criarCartao(tarefa) {
        const cartao = criarElemento('article', 'card');
        cartao.dataset.id = tarefa.id;
        cartao.draggable = true;
        cartao.tabIndex = 0;
        cartao.setAttribute('aria-label', `Tarefa: ${tarefa.title}. Abra os detalhes ou arraste para outra coluna.`);

        const topo = criarElemento('div', 'card-top');
        const prioridade = criarElemento('span', `priority-badge priority-${classePrioridade(tarefa.priority)}`, tarefa.priority);
        topo.append(prioridade);

        cartao.append(topo);

        cartao.append(criarElemento('h3', 'card-title', tarefa.title));

        if (tarefa.description) {
            cartao.append(criarElemento('p', 'card-description', tarefa.description));
        }

        if (Array.isArray(tarefa.attachments) && tarefa.attachments.length) {
            const areaAnexos = criarElemento('div', 'card-attachments');

            tarefa.attachments.forEach(anexo => {
                const botaoAnexo = criarBotaoAcao('card-attachment', `Baixar anexo: ${anexo.name}`, 'fa-solid fa-paperclip', anexo.name);

                botaoAnexo.addEventListener('click', evento => {
                    evento.stopPropagation();
                    baixarAnexo(anexo);
                });

                areaAnexos.append(botaoAnexo);
            });

            cartao.append(areaAnexos);
        }

        const detalhes = criarElemento('div', 'card-details');

        if (tarefa.responsible) {
            const responsavel = criarElemento('span', 'card-detail');
            responsavel.append(document.createElement('i'));
            responsavel.firstElementChild.className = 'fa-regular fa-user';
            responsavel.firstElementChild.setAttribute('aria-hidden', 'true');
            responsavel.append(document.createTextNode(` ${tarefa.responsible}`));
            detalhes.append(responsavel);
        }

        if (tarefa.dueDate) {
            const atrasado = prazoAtrasado(tarefa.dueDate) && tarefa.status !== 'Concluído';
            const prazo = criarElemento('span', `card-detail due-date${atrasado ? ' overdue' : ''}`);
            const iconePrazo = document.createElement('i');

            iconePrazo.className = atrasado ? 'fa-solid fa-triangle-exclamation' : 'fa-regular fa-calendar';
            iconePrazo.setAttribute('aria-hidden', 'true');

            prazo.append(iconePrazo, document.createTextNode(` ${formatarData(tarefa.dueDate)}${atrasado ? ' (atrasada)' : ''}`));
            detalhes.append(prazo);
        }

        if (detalhes.childElementCount) cartao.append(detalhes);

        const abrirDetalhes = criarElemento('span', 'card-open-details');
        abrirDetalhes.append(
            document.createElement('i'),
            document.createTextNode(' Abrir detalhes')
        );
        abrirDetalhes.firstElementChild.className = 'fa-regular fa-pen-to-square';
        abrirDetalhes.firstElementChild.setAttribute('aria-hidden', 'true');
        cartao.append(abrirDetalhes);

        cartao.addEventListener('click', evento => {
            if (cartaoFoiArrastado || evento.target.closest('button')) return;
            abrirDetalhesTarefa(tarefa.id);
        });

        cartao.addEventListener('keydown', evento => {
            if ((evento.key === 'Enter' || evento.key === ' ') && evento.target === cartao) {
                evento.preventDefault();
                abrirDetalhesTarefa(tarefa.id);
            }
        });

        cartao.addEventListener('dragstart', evento => {
            idArrastado = tarefa.id;
            cartaoFoiArrastado = true;
            cartao.classList.add('is-dragging');
            cartao.setAttribute('aria-grabbed', 'true');

            if (evento.dataTransfer) {
                evento.dataTransfer.effectAllowed = 'move';
                evento.dataTransfer.setData('text/plain', tarefa.id);
            }
        });

        cartao.addEventListener('dragend', () => {
            idArrastado = null;
            cartao.classList.remove('is-dragging');
            cartao.setAttribute('aria-grabbed', 'false');
            colunas.forEach(coluna => coluna.classList.remove('is-drag-over'));
            window.setTimeout(() => {
                cartaoFoiArrastado = false;
            }, 0);
        });

        return cartao;
    }

    function classePrioridade(prioridade) {
        return ({ 'Baixa': 'baixa', 'Média': 'media', 'Alta': 'alta', 'Urgente': 'urgente' })[prioridade] || 'media';
    }

    // Redesenha as colunas de acordo com o status e o texto pesquisado.
    function renderizarQuadro() {
        const termo = normalizarTexto(campoPesquisa.value);

        colunas.forEach(coluna => {
            const status = coluna.dataset.status;
            const areaCartoes = coluna.querySelector('.cards-container');
            const tarefasDaColuna = tarefas.filter(tarefa => tarefa.status === status);

            const tarefasVisiveis = tarefasDaColuna.filter(tarefa => {
                const nomesAnexos = (tarefa.attachments || []).map(anexo => anexo.name).join(' ');
                const texto = normalizarTexto(`${tarefa.title} ${tarefa.description} ${tarefa.responsible} ${tarefa.priority} ${nomesAnexos}`);

                return texto.includes(termo);
            });

            areaCartoes.replaceChildren();

            coluna.querySelector('.column-count').textContent = termo
                ? `${tarefasVisiveis.length}/${tarefasDaColuna.length}`
                : String(tarefasDaColuna.length);

            if (tarefasVisiveis.length === 0 && termo) {
                areaCartoes.append(criarElemento('p', 'empty-column-message', 'Nenhuma tarefa encontrada.'));
            } else {
                tarefasVisiveis.forEach(tarefa => areaCartoes.append(criarCartao(tarefa)));
            }
        });
    }

    function abrirDetalhesTarefa(id) {
        const tarefa = tarefas.find(item => item.id === id);
        if (!tarefa) return;

        idTarefaAberta = id;
        tituloDetalhesTarefa.textContent = tarefa.title;
        statusDetalhesTarefa.textContent = tarefa.status;
        campoDescricaoTarefa.value = tarefa.detailsDescription || '';
        mensagemDetalhes.textContent = '';
        campoComentario.value = '';
        campoNovoChecklist.value = '';
        renderizarAnexosDetalhes(tarefa);
        renderizarChecklist(tarefa);
        renderizarComentarios(tarefa);
        modalDetalhesTarefa.hidden = false;
        document.body.classList.add('modal-open');
        campoDescricaoTarefa.focus();
    }

    function fecharDetalhesTarefa() {
        if (!salvarDescricaoDetalhes()) return;

        const idFechado = idTarefaAberta;
        idTarefaAberta = null;
        modalDetalhesTarefa.hidden = true;
        document.body.classList.remove('modal-open');
        Array.from(document.querySelectorAll('.card')).find(cartao => cartao.dataset.id === idFechado)?.focus();
    }

    function persistirAlteracaoTarefa(tarefa, alterar) {
        const anterior = JSON.parse(JSON.stringify(tarefa));
        alterar(tarefa);
        tarefa.updatedAt = new Date().toISOString();

        if (!salvarTarefas()) {
            Object.assign(tarefa, anterior);
            return false;
        }

        renderizarQuadro();
        return true;
    }

    function renderizarAnexosDetalhes(tarefa) {
        listaAnexosTarefa.replaceChildren();

        if (!tarefa.detailsAttachments.length) {
            listaAnexosTarefa.append(criarElemento('p', 'details-empty', 'Nenhum anexo adicionado.'));
            return;
        }

        tarefa.detailsAttachments.forEach(anexo => {
            const linha = criarElemento('div', 'details-attachment-row');
            const baixar = criarBotaoAcao('details-attachment', `Baixar anexo: ${anexo.name}`, 'fa-solid fa-download', anexo.name);
            baixar.addEventListener('click', () => baixarAnexo(anexo));
            const remover = criarBotaoAcao('details-attachment-remove', `Remover anexo: ${anexo.name}`, 'fa-solid fa-trash', 'Remover');
            remover.dataset.id = anexo.id;
            linha.append(baixar, remover);
            listaAnexosTarefa.append(linha);
        });
    }

    function renderizarChecklist(tarefa) {
        listaChecklist.replaceChildren();

        if (!tarefa.checklist.length) {
            listaChecklist.append(criarElemento('li', 'details-empty', 'Nenhum item no checklist.'));
            return;
        }

        tarefa.checklist.forEach(item => {
            const linha = criarElemento('li', `checklist-item${item.completed ? ' is-complete' : ''}`);
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.checked = item.completed;
            checkbox.dataset.id = item.id;
            checkbox.setAttribute('aria-label', `Marcar ${item.text} como ${item.completed ? 'incompleto' : 'concluído'}`);
            const texto = criarElemento('span', 'checklist-text', item.text);
            const remover = criarBotaoAcao('checklist-remove', 'Remover item do checklist', 'fa-solid fa-xmark', '');
            remover.dataset.id = item.id;
            linha.append(checkbox, texto, remover);
            listaChecklist.append(linha);
        });
    }

    function renderizarComentarios(tarefa) {
        listaComentarios.replaceChildren();

        if (!tarefa.comments.length) {
            listaComentarios.append(criarElemento('p', 'details-empty', 'Ainda não há comentários.'));
            return;
        }

        tarefa.comments.forEach(comment => {
            const bloco = criarElemento('article', 'task-comment');
            const cabecalho = criarElemento('div', 'task-comment-header');
            cabecalho.append(
                criarElemento('strong', '', comment.author),
                criarElemento('time', '', new Date(comment.createdAt).toLocaleString('pt-BR', {
                    dateStyle: 'short',
                    timeStyle: 'short'
                }))
            );
            bloco.append(cabecalho, criarElemento('p', '', comment.text));
            listaComentarios.append(bloco);
        });

        listaComentarios.scrollTop = listaComentarios.scrollHeight;
    }

    function obterNomeUsuario() {
        try {
            const usuario = JSON.parse(localStorage.getItem('teamwave_usuario_logado') || 'null');
            return typeof usuario?.nome === 'string' && usuario.nome.trim() ? usuario.nome.trim() : 'Pessoa';
        } catch (erro) {
            console.warn('Não foi possível ler o nome do usuário conectado:', erro);
            return 'Pessoa';
        }
    }

    function tarefaAberta() {
        return tarefas.find(item => item.id === idTarefaAberta) || null;
    }

    function salvarDescricaoDetalhes() {
        const tarefa = tarefaAberta();
        if (!tarefa) return true;

        const descricao = campoDescricaoTarefa.value.trim();
        if (descricao === tarefa.detailsDescription) return true;

        const descricaoAnterior = tarefa.detailsDescription;
        const atualizadoAnteriormente = tarefa.updatedAt;
        tarefa.detailsDescription = descricao;
        tarefa.updatedAt = new Date().toISOString();

        if (!salvarTarefas()) {
            tarefa.detailsDescription = descricaoAnterior;
            tarefa.updatedAt = atualizadoAnteriormente;
            campoDescricaoTarefa.value = descricaoAnterior;
            return false;
        }

        mensagemDetalhes.textContent = 'Descrição salva automaticamente.';
        return true;
    }

    campoDescricaoTarefa.addEventListener('change', salvarDescricaoDetalhes);

    formularioChecklist.addEventListener('submit', evento => {
        evento.preventDefault();
        const tarefa = tarefaAberta();
        const texto = campoNovoChecklist.value.trim();
        if (!tarefa || !texto) return;

        if (tarefa.status === 'Concluído') {
            mensagemDetalhes.textContent = 'Tire a tarefa da coluna "Concluído" antes de adicionar itens ao checklist.';
            return;
        }

        if (persistirAlteracaoTarefa(tarefa, item => {
            item.checklist.push({ id: gerarId(), text: texto, completed: false });
        })) {
            campoNovoChecklist.value = '';
            renderizarChecklist(tarefa);
            mensagemDetalhes.textContent = 'Item adicionado ao checklist.';
        }
    });

    listaChecklist.addEventListener('change', evento => {
        const checkbox = evento.target.closest('input[type="checkbox"][data-id]');
        const tarefa = tarefaAberta();
        if (!checkbox || !tarefa) return;

        const item = tarefa.checklist.find(registro => registro.id === checkbox.dataset.id);
        if (!item) return;
        if (tarefa.status === 'Concluído' && !checkbox.checked) {
            checkbox.checked = true;
            mensagemDetalhes.textContent = 'Tire a tarefa da coluna "Concluído" antes de desmarcar itens do checklist.';
            return;
        }

        persistirAlteracaoTarefa(tarefa, () => {
            item.completed = checkbox.checked;
        });
        renderizarChecklist(tarefa);
    });

    listaChecklist.addEventListener('click', evento => {
        const botao = evento.target.closest('.checklist-remove[data-id]');
        const tarefa = tarefaAberta();
        if (!botao || !tarefa) return;

        if (persistirAlteracaoTarefa(tarefa, item => {
            item.checklist = item.checklist.filter(registro => registro.id !== botao.dataset.id);
        })) {
            renderizarChecklist(tarefa);
            mensagemDetalhes.textContent = 'Item removido do checklist.';
        }
    });

    formularioComentario.addEventListener('submit', evento => {
        evento.preventDefault();
        const tarefa = tarefaAberta();
        const texto = campoComentario.value.trim();
        if (!tarefa || !texto) return;

        if (persistirAlteracaoTarefa(tarefa, item => {
            item.comments.push({
                id: gerarId(),
                text: texto,
                author: obterNomeUsuario(),
                createdAt: new Date().toISOString()
            });
        })) {
            campoComentario.value = '';
            renderizarComentarios(tarefa);
            mensagemDetalhes.textContent = 'Comentário publicado.';
        }
    });

    botaoAdicionarArquivos.addEventListener('click', () => campoArquivosTarefa.click());

    listaAnexosTarefa.addEventListener('click', async evento => {
        const botao = evento.target.closest('.details-attachment-remove[data-id]');
        const tarefa = tarefaAberta();
        if (!botao || !tarefa) return;

        const anexo = tarefa.detailsAttachments.find(item => item.id === botao.dataset.id);
        if (!anexo) return;

        if (!persistirAlteracaoTarefa(tarefa, item => {
            item.detailsAttachments = item.detailsAttachments.filter(registro => registro.id !== anexo.id);
        })) return;

        try {
            await excluirAnexoDoBanco(anexo.id);
            mensagemDetalhes.textContent = 'Anexo removido.';
        } catch (erro) {
            console.error('O anexo foi removido do quadro, mas não do armazenamento local:', erro);
            mensagemDetalhes.textContent = 'Anexo removido do quadro, mas não foi possível apagar o arquivo do armazenamento local.';
        }

        renderizarAnexosDetalhes(tarefa);
    });

    campoArquivosTarefa.addEventListener('change', async () => {
        const tarefa = tarefaAberta();
        const arquivos = Array.from(campoArquivosTarefa.files || []);
        campoArquivosTarefa.value = '';
        if (!tarefa || !arquivos.length) return;

        const anexosProcessando = anexosDetalhesEmProcessamento.get(tarefa.id) || 0;
        const quantidadeDisponivel = LIMITE_ANEXOS_DETALHES - tarefa.detailsAttachments.length - anexosProcessando;
        if (quantidadeDisponivel <= 0) {
            mensagemDetalhes.textContent = `Cada cartão pode ter no máximo ${LIMITE_ANEXOS_DETALHES} anexos nos detalhes.`;
            return;
        }

        const anexosAdicionados = [];
        const arquivosAceitos = [];
        let limiteAtingido = false;
        for (const arquivo of arquivos) {
            if (arquivo.size > LIMITE_ARQUIVO) {
                alert(`O arquivo "${arquivo.name}" ultrapassa o limite de 25 MB.`);
                continue;
            }

            if (arquivosAceitos.length >= quantidadeDisponivel) {
                limiteAtingido = true;
                continue;
            }

            arquivosAceitos.push(arquivo);
        }

        if (limiteAtingido) {
            mensagemDetalhes.textContent = `O limite é de ${LIMITE_ANEXOS_DETALHES} anexos nos detalhes. Os arquivos excedentes não serão adicionados.`;
        }
        if (!arquivosAceitos.length) return;

        anexosDetalhesEmProcessamento.set(tarefa.id, anexosProcessando + arquivosAceitos.length);
        try {
            try {
                for (const arquivo of arquivosAceitos) {
                    const anexo = {
                        id: gerarId(),
                        name: arquivo.name,
                        type: arquivo.type || 'application/octet-stream',
                        size: arquivo.size
                    };
                    await armazenarAnexo(anexo.id, arquivo);
                    anexosAdicionados.push(anexo);
                }
            } catch (erro) {
                console.error('Não foi possível armazenar os anexos da tarefa:', erro);
                await Promise.all(anexosAdicionados.map(anexo =>
                    excluirAnexoDoBanco(anexo.id).catch(erroRemocao => {
                        console.warn('Não foi possível limpar um anexo que não foi salvo:', erroRemocao);
                    })
                ));
                mensagemDetalhes.textContent = 'Não foi possível armazenar os anexos. Verifique o espaço disponível no navegador.';
                return;
            }

            if (!anexosAdicionados.length) return;

            if (!persistirAlteracaoTarefa(tarefa, item => {
                item.detailsAttachments.push(...anexosAdicionados);
            })) {
                await Promise.all(anexosAdicionados.map(anexo =>
                    excluirAnexoDoBanco(anexo.id).catch(erro => {
                        console.warn('Não foi possível limpar um anexo que não foi salvo:', erro);
                    })
                ));
                return;
            }

            renderizarAnexosDetalhes(tarefa);
            mensagemDetalhes.textContent = limiteAtingido
                ? `O limite é de ${LIMITE_ANEXOS_DETALHES} anexos nos detalhes. Os arquivos excedentes não foram adicionados.`
                : 'Anexo(s) adicionado(s).';
        } finally {
            const quantidadeEmProcessamento = (anexosDetalhesEmProcessamento.get(tarefa.id) || 0) - arquivosAceitos.length;
            if (quantidadeEmProcessamento > 0) {
                anexosDetalhesEmProcessamento.set(tarefa.id, quantidadeEmProcessamento);
            } else {
                anexosDetalhesEmProcessamento.delete(tarefa.id);
            }
        }
    });

    botaoFecharDetalhes.addEventListener('click', fecharDetalhesTarefa);
    modalDetalhesTarefa.addEventListener('click', evento => {
        if (evento.target === modalDetalhesTarefa) fecharDetalhesTarefa();
    });
    document.addEventListener('keydown', evento => {
        if (evento.key === 'Escape' && !modalDetalhesTarefa.hidden) fecharDetalhesTarefa();
    });

    function todosItensChecklistConcluidos(tarefa) {
        return !Array.isArray(tarefa.checklist) || tarefa.checklist.every(item => item && item.completed);
    }

    function moverTarefa(id, novoStatus) {
        if (!statusPermitidos.includes(novoStatus)) return;

        const tarefa = tarefas.find(item => item.id === id);
        if (!tarefa || tarefa.status === novoStatus) return;
        if (novoStatus === 'Concluído' && !todosItensChecklistConcluidos(tarefa)) {
            alert('Conclua todos os itens do checklist antes de concluir a tarefa.');
            return;
        }

        const statusAnterior = tarefa.status;
        const atualizadoAnteriormente = tarefa.updatedAt;
        tarefa.status = novoStatus;
        tarefa.updatedAt = new Date().toISOString();

        if (!salvarTarefas()) {
            tarefa.status = statusAnterior;
            tarefa.updatedAt = atualizadoAnteriormente;
            return;
        }

        renderizarQuadro();
    }

    // Recupera um arquivo salvo e inicia seu download.
    async function baixarAnexo(anexo) {
        try {
            const registro = await buscarAnexo(anexo.id);

            if (!registro || !registro.blob) {
                alert(`O arquivo "${anexo.name}" não foi encontrado neste navegador. Se você mudou de computador ou limpou os dados do navegador, será necessário anexá-lo novamente.`);
                return;
            }

            const url = URL.createObjectURL(registro.blob);
            const link = document.createElement('a');

            link.href = url;
            link.download = anexo.name;

            document.body.append(link);
            link.click();
            link.remove();

            window.setTimeout(() => URL.revokeObjectURL(url), 1000);
        } catch (erro) {
            console.error('Não foi possível baixar o anexo:', erro);
            alert('Não foi possível abrir o anexo. Verifique as permissões de armazenamento do navegador.');
        }
    }

    // ================================================================
    // 6. EXPORTAÇÃO DO QUADRO EM BACKUP JSON
    // ================================================================

    function blobParaDataURL(blob) {
        return new Promise((resolve, reject) => {
            const leitor = new FileReader();

            leitor.onload = () => resolve(String(leitor.result || ''));
            leitor.onerror = () => reject(leitor.error || new Error('Não foi possível preparar um anexo para exportação.'));

            leitor.readAsDataURL(blob);
        });
    }

    // Gera e baixa um backup JSON com as tarefas e os arquivos disponíveis.
    async function exportarJSON() {
        try {
            const tarefasExportadas = [];

            for (const tarefa of tarefas) {
                const anexosExportados = [];

                for (const anexo of tarefa.attachments || []) {
                    const registro = await buscarAnexo(anexo.id).catch(() => null);

                    if (registro && registro.blob) {
                        anexosExportados.push({
                            ...anexo,
                            dataUrl: await blobParaDataURL(registro.blob)
                        });
                    } else {
                        anexosExportados.push({ ...anexo });
                    }
                }

                const anexosDetalhesExportados = [];
                for (const anexo of tarefa.detailsAttachments || []) {
                    const registro = await buscarAnexo(anexo.id).catch(() => null);

                    if (registro && registro.blob) {
                        anexosDetalhesExportados.push({
                            ...anexo,
                            dataUrl: await blobParaDataURL(registro.blob)
                        });
                    } else {
                        anexosDetalhesExportados.push({ ...anexo });
                    }
                }

                tarefasExportadas.push({
                    ...tarefa,
                    attachments: anexosExportados,
                    detailsAttachments: anexosDetalhesExportados
                });
            }

            const conteudo = JSON.stringify(tarefasExportadas, null, 2);
            const arquivo = new Blob([conteudo], { type: 'application/json;charset=utf-8' });
            const url = URL.createObjectURL(arquivo);
            const link = document.createElement('a');

            link.href = url;
            link.download = `teamwave-kanban-${ID_QUADRO}-${new Date().toISOString().slice(0, 10)}.json`;

            document.body.append(link);
            link.click();
            link.remove();

            window.setTimeout(() => URL.revokeObjectURL(url), 1000);
        } catch (erro) {
            console.error('Erro ao exportar o quadro:', erro);
            alert('Não foi possível exportar o quadro. Tente novamente ou reduza o tamanho dos anexos.');
        }
    }

    // ================================================================
    // 7. EVENTOS DA INTERFACE
    // ================================================================

    botaoSeletorQuadros.addEventListener('click', abrirSeletorQuadros);
    botaoFecharSeletor.addEventListener('click', fecharSeletorQuadros);

    modalSeletorQuadros.addEventListener('click', evento => {
        if (evento.target === modalSeletorQuadros) fecharSeletorQuadros();
    });

    document.addEventListener('keydown', evento => {
        if (evento.key === 'Escape' && !modalSeletorQuadros.hidden) fecharSeletorQuadros();
    });

    campoPesquisa.addEventListener('input', renderizarQuadro);

    colunas.forEach(coluna => {
        coluna.addEventListener('dragover', evento => {
            evento.preventDefault();
            if (evento.dataTransfer) evento.dataTransfer.dropEffect = 'move';
            coluna.classList.add('is-drag-over');
        });

        coluna.addEventListener('dragleave', evento => {
            if (!coluna.contains(evento.relatedTarget)) {
                coluna.classList.remove('is-drag-over');
            }
        });

        coluna.addEventListener('drop', evento => {
            evento.preventDefault();
            coluna.classList.remove('is-drag-over');

            const id = (evento.dataTransfer && evento.dataTransfer.getData('text/plain')) || idArrastado;
            if (id) moverTarefa(id, coluna.dataset.status);
        });
    });

    document.getElementById('export-button').addEventListener('click', exportarJSON);

    // ================================================================
    // 8. FAVORITOS E INICIALIZAÇÃO DO QUADRO
    // ================================================================

    const botaoFavorito = document.getElementById('favorite-board');

    function atualizarFavorito(favorito) {
        botaoFavorito.setAttribute('aria-pressed', String(favorito));
        botaoFavorito.classList.toggle('is-favorite', favorito);

        const icone = botaoFavorito.querySelector('i');
        icone.className = favorito ? 'fa-solid fa-star' : 'fa-regular fa-star';

        botaoFavorito.title = favorito ? 'Remover dos favoritos' : 'Favoritar quadro';
        botaoFavorito.setAttribute('aria-label', botaoFavorito.title);
    }

    try {
        atualizarFavorito(localStorage.getItem(CHAVE_FAVORITO) === 'true');
    } catch (erro) {
        atualizarFavorito(false);
    }

    botaoFavorito.addEventListener('click', () => {
        const favorito = botaoFavorito.getAttribute('aria-pressed') !== 'true';

        atualizarFavorito(favorito);

        try {
            localStorage.setItem(CHAVE_FAVORITO, String(favorito));
        } catch (erro) {
            console.warn('Não foi possível salvar o favorito:', erro);
        }
    });

    // Exibe as tarefas salvas assim que a página termina de carregar.
    renderizarQuadro();
});