/* TeamWave - seleção e pesquisa de quadros. */
document.addEventListener('DOMContentLoaded', () => {
    // ================================================================
    // 1. CONFIGURAÇÕES E ELEMENTOS
    // ================================================================
    const CHAVE_QUADROS_PERSONALIZADOS = 'teamwave_quadros_personalizados_v1';
    const CHAVE_QUADRO_ATUAL = 'teamwave_quadro_atual_v1';
    const PREFIXO_FAVORITOS = 'teamwave_kanban_favorito_v1_';
    const CHAVE_FAVORITO_LEGADO = 'teamwave_kanban_favorito_v1';
    const ENDERECO_KANBAN = '../Kanban/kanban.html';

    const gradeCores = document.getElementById('color-boards');
    const gradeImagens = document.getElementById('image-boards');
    const gradePersonalizados = document.getElementById('custom-boards');
    const secaoPersonalizados = document.getElementById('custom-section');
    const pesquisa = document.getElementById('board-search');
    const avisoSemResultados = document.getElementById('no-results');
    const gradeFavoritos = document.getElementById('favorite-boards');
    const contadorFavoritos = document.getElementById('favorite-board-count');

    // Os quadros coloridos usam cores sólidas como fundo do Kanban.
    const quadrosColoridos = [
        { id: 'team-wave', name: 'TeamWave', category: 'Equipe', type: 'color', value: '#2563eb' },
        { id: 'estrategia', name: 'Estratégia', category: 'Planejamento', type: 'color', value: '#7c3aed' },
        { id: 'operacoes', name: 'Operações', category: 'Equipe', type: 'color', value: '#ea580c' },
        { id: 'marketing', name: 'Marketing', category: 'Equipe', type: 'color', value: '#0f766e' },
        { id: 'projeto', name: 'Projeto', category: 'Projeto', type: 'color', value: '#be123c' },
        { id: 'reunioes', name: 'Reuniões', category: 'Equipe', type: 'color', value: '#334155' },
        { id: 'design', name: 'Design', category: 'Criação', type: 'color', value: '#0891b2' },
        { id: 'planejamento', name: 'Planejamento', category: 'Organização', type: 'color', value: '#4d7c0f' }
    ];

    // Imagens de demonstração usadas nos cartões e como fundo do Kanban.
    const quadrosComImagens = [
        {
            id: 'natureza', name: 'Natureza', category: 'Imagem', type: 'image',
            value: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=85'
        },
        {
            id: 'montanhas', name: 'Montanhas', category: 'Imagem', type: 'image',
            value: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1600&q=85'
        },
        {
            id: 'praia', name: 'Praia', category: 'Imagem', type: 'image',
            value: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1600&q=85'
        },
        {
            id: 'amanhecer', name: 'Amanhecer', category: 'Imagem', type: 'image',
            value: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&w=1600&q=85'
        },
        {
            id: 'ceu-estrelado', name: 'Céu estrelado', category: 'Imagem', type: 'image',
            value: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1600&q=85'
        }
    ];

    // ================================================================
    // 2. ARMAZENAMENTO DOS QUADROS PERSONALIZADOS
    // ================================================================
    function carregarQuadrosPersonalizados() {
        try {
            const dados = JSON.parse(localStorage.getItem(CHAVE_QUADROS_PERSONALIZADOS) || '[]');
            if (!Array.isArray(dados)) return [];

            return dados.filter(quadro =>
                quadro &&
                typeof quadro.id === 'string' &&
                typeof quadro.name === 'string' &&
                quadro.name.trim() &&
                (quadro.type === 'color' || quadro.type === 'image') &&
                typeof quadro.value === 'string'
            ).map(quadro => ({
                id: quadro.id,
                name: quadro.name.trim().slice(0, 45),
                category: typeof quadro.category === 'string' && quadro.category.trim()
                    ? quadro.category.trim().slice(0, 30)
                    : 'Personalizado',
                type: quadro.type,
                value: quadro.value
            }));
        } catch (erro) {
            console.error('Não foi possível carregar os quadros personalizados:', erro);
            return [];
        }
    }

    let quadrosPersonalizados = carregarQuadrosPersonalizados();

    // ================================================================
    // 3. CRIAÇÃO VISUAL DOS CARTÕES
    // ================================================================
    function criarCartaoQuadro(quadro) {
        const cartao = document.createElement('a');
        cartao.className = 'board-card';
        cartao.href = `${ENDERECO_KANBAN}?quadro=${encodeURIComponent(quadro.id)}`;
        cartao.dataset.boardName = quadro.name.toLocaleLowerCase('pt-BR');
        cartao.dataset.boardCategory = (quadro.category || '').toLocaleLowerCase('pt-BR');
        cartao.setAttribute('aria-label', `Abrir o quadro ${quadro.name} no Kanban`);

        const capa = document.createElement('div');
        capa.className = 'board-cover';

        if (quadro.type === 'image') {
            capa.style.backgroundImage = `url("${quadro.value}")`;
            capa.style.backgroundColor = '#334155';
        } else {
            capa.style.background = `linear-gradient(135deg, ${quadro.value}, ${quadro.value})`;
        }

        const conteudo = document.createElement('div');
        conteudo.className = 'board-card-content';

        const etiqueta = document.createElement('span');
        etiqueta.className = 'card-tag';
        etiqueta.textContent = quadro.category || (quadro.type === 'image' ? 'Imagem' : 'Quadro');

        const nome = document.createElement('span');
        nome.className = 'card-name';
        nome.textContent = quadro.name;

        const abrir = document.createElement('span');
        abrir.className = 'card-open-hint';
        abrir.innerHTML = '<i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i> Abrir Kanban';

        conteudo.append(etiqueta, nome, abrir);
        cartao.append(capa, conteudo);

        // Salva a identidade e o fundo escolhidos antes de abrir o Kanban.
        cartao.addEventListener('click', () => {
            try {
                localStorage.setItem(CHAVE_QUADRO_ATUAL, JSON.stringify(quadro));
            } catch (erro) {
                console.warn('Não foi possível salvar a aparência do quadro:', erro);
            }
        });

        return cartao;
    }

    function renderizarFavoritos() {
        gradeFavoritos.replaceChildren();

        let idsFavoritos;
        try {
            idsFavoritos = new Set();
            if (localStorage.getItem(CHAVE_FAVORITO_LEGADO) === 'true') {
                idsFavoritos.add('team-wave');
            }

            for (let indice = 0; indice < localStorage.length; indice++) {
                const chave = localStorage.key(indice);
                if (!chave || !chave.startsWith(PREFIXO_FAVORITOS)) continue;

                const id = chave.slice(PREFIXO_FAVORITOS.length);
                if (/^[a-zA-Z0-9_-]{1,80}$/.test(id) && localStorage.getItem(chave) === 'true') {
                    idsFavoritos.add(id);
                }
            }
        } catch (erro) {
            console.error('Não foi possível carregar os quadros favoritos:', erro);
            contadorFavoritos.textContent = 'Indisponível';
            const mensagem = document.createElement('p');
            mensagem.className = 'favorite-boards-empty';
            mensagem.textContent = 'Não foi possível carregar os favoritos neste navegador.';
            gradeFavoritos.append(mensagem);
            return;
        }

        const todosQuadros = [...quadrosColoridos, ...quadrosComImagens, ...quadrosPersonalizados];
        const quadrosFavoritos = todosQuadros.filter(quadro => idsFavoritos.has(quadro.id));
        contadorFavoritos.textContent = `${quadrosFavoritos.length} ${quadrosFavoritos.length === 1 ? 'quadro' : 'quadros'}`;

        if (quadrosFavoritos.length === 0) {
            const mensagem = document.createElement('p');
            mensagem.className = 'favorite-boards-empty';
            mensagem.append(document.createTextNode('Nenhum quadro favoritado ainda. Favorite um quadro no Kanban para encontrá-lo aqui.'));
            gradeFavoritos.append(mensagem);
            return;
        }

        quadrosFavoritos.sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
        quadrosFavoritos.forEach(quadro => {
            const cartao = document.createElement('a');
            cartao.className = 'favorite-board-card';
            cartao.href = `${ENDERECO_KANBAN}?quadro=${encodeURIComponent(quadro.id)}`;
            cartao.dataset.boardName = quadro.name.toLocaleLowerCase('pt-BR');
            cartao.dataset.boardCategory = (quadro.category || '').toLocaleLowerCase('pt-BR');
            cartao.setAttribute('aria-label', `Abrir quadro favorito ${quadro.name} no Kanban`);

            if (quadro.type === 'image') {
                try {
                    const enderecoImagem = new URL(quadro.value);
                    if (enderecoImagem.protocol !== 'https:') throw new Error('Endereço de imagem não permitido.');
                    cartao.style.backgroundImage = `linear-gradient(rgba(10, 20, 36, .18), rgba(10, 20, 36, .18)), url("${enderecoImagem.href}")`;
                } catch (erro) {
                    console.warn(`Não foi possível exibir o fundo do quadro "${quadro.name}":`, erro);
                    cartao.style.backgroundColor = '#334155';
                }
            } else if (/^#[0-9a-fA-F]{6}$/.test(quadro.value)) {
                cartao.style.backgroundColor = quadro.value;
            } else {
                cartao.style.backgroundColor = '#334155';
            }

            const nome = document.createElement('span');
            nome.className = 'favorite-board-name';
            nome.textContent = quadro.name;

            const tipo = document.createElement('span');
            tipo.className = 'favorite-board-type';
            tipo.textContent = quadro.type === 'image' ? 'Imagem de fundo' : 'Fundo colorido';
            cartao.append(nome, tipo);

            cartao.addEventListener('click', () => {
                try {
                    localStorage.setItem(CHAVE_QUADRO_ATUAL, JSON.stringify(quadro));
                } catch (erro) {
                    console.warn('Não foi possível salvar a aparência do quadro:', erro);
                }
            });

            gradeFavoritos.append(cartao);
        });
    }

    function renderizarQuadros() {
        gradeCores.replaceChildren();
        gradeImagens.replaceChildren();
        gradePersonalizados.replaceChildren();

        quadrosColoridos.forEach(quadro => gradeCores.append(criarCartaoQuadro(quadro)));
        quadrosComImagens.forEach(quadro => gradeImagens.append(criarCartaoQuadro(quadro)));

        quadrosPersonalizados.forEach(quadro => {
            gradePersonalizados.append(criarCartaoQuadro(quadro));
        });

        secaoPersonalizados.hidden = quadrosPersonalizados.length === 0;
        document.getElementById('color-board-count').textContent = `${quadrosColoridos.length} quadros`;
        document.getElementById('image-board-count').textContent = `${quadrosComImagens.length} quadros`;
        document.getElementById('custom-board-count').textContent = `${quadrosPersonalizados.length} quadros`;
        renderizarFavoritos();
        aplicarPesquisa();
    }

    // ================================================================
    // 4. PESQUISA DOS QUADROS
    // ================================================================
    function aplicarPesquisa() {
        const termo = pesquisa.value.toLocaleLowerCase('pt-BR').trim();
        let quantidadeVisivel = 0;

        document.querySelectorAll('.board-card').forEach(cartao => {
            const corresponde = cartao.dataset.boardName.includes(termo) ||
                cartao.dataset.boardCategory.includes(termo);
            cartao.hidden = !corresponde;
            if (corresponde) quantidadeVisivel++;
        });

        document.querySelectorAll('.favorite-board-card').forEach(cartao => {
            cartao.hidden = !cartao.dataset.boardName.includes(termo) &&
                !cartao.dataset.boardCategory.includes(termo);
        });

        document.querySelectorAll('[data-board-section]').forEach(secao => {
            const cartoesVisiveis = secao.querySelectorAll('.board-card:not([hidden])').length;
            secao.hidden = cartoesVisiveis === 0;
        });

        const secaoFavoritos = document.querySelector('.favorite-boards-section');
        if (secaoFavoritos) {
            const favoritosVisiveis = secaoFavoritos.querySelectorAll('.favorite-board-card:not([hidden])').length;
            secaoFavoritos.hidden = favoritosVisiveis === 0 && Boolean(termo);
        }

        avisoSemResultados.hidden = quantidadeVisivel > 0;
    }

    pesquisa.addEventListener('input', aplicarPesquisa);

    // Inicializa a galeria.
    renderizarQuadros();

    window.addEventListener('storage', evento => {
        if (
            evento.key === null ||
            evento.key === CHAVE_QUADROS_PERSONALIZADOS ||
            evento.key === CHAVE_FAVORITO_LEGADO ||
            (evento.key && evento.key.startsWith(PREFIXO_FAVORITOS))
        ) {
            quadrosPersonalizados = carregarQuadrosPersonalizados();
            renderizarQuadros();
        }
    });

    window.addEventListener('focus', () => {
        quadrosPersonalizados = carregarQuadrosPersonalizados();
        renderizarQuadros();
    });
});
