/**
 * ==========================================================================
 * CONFIGURAÇÕES DA APLICAÇÃO
 * ==========================================================================
 */
const AppConfig = {
    business: {
        id: "teamwave",
        nome: "Sede TeamWave",
        descricao: "Sede oficial da TeamWave, empresa especializada em comunicação e gestão de projetos.",
        endereco: "Praia Grande - SP",
        coordenadas: [-24.032406, -46.506550]
    },
    defaultZoom: 14,
    storageKey: "teamwave_empresas_localizacao_v1"
};

/**
 * ==========================================================================
 * ESTADO DA APLICAÇÃO
 * ==========================================================================
 */
let map = null;
let userMarker = null;
let businessMarker = null;
let userAccuracyCircle = null;
let distanceLine = null;
let companyLayer = null;
let companyMarkers = new Map();
let companies = loadCompanies();
let userCoords = null;
let selectedCompany = null;

/**
 * ==========================================================================
 * ELEMENTOS DO HTML
 * ==========================================================================
 */
const statusCard = document.getElementById("geo-status");
const statusText = document.getElementById("status-text");
const btnRetry = document.getElementById("btn-retry");
const btnRecenter = document.getElementById("btn-recenter");
const distancePanel = document.getElementById("distance-panel");
const selectedCompanyName = document.getElementById("selected-company-name");
const distanceText = document.getElementById("distance-text");
const distanceNote = document.getElementById("distance-note");
const companyStatus = document.getElementById("company-status");
const companyList = document.getElementById("company-list");
const companyCount = document.getElementById("company-count");
const businessCard = document.getElementById("business-card");

/**
 * ==========================================================================
 * INICIALIZAÇÃO DO MAPA
 * ==========================================================================
 */
function initMap() {
    map = L.map("map-container", {
        zoomControl: true,
        scrollWheelZoom: true
    }).setView(AppConfig.business.coordenadas, AppConfig.defaultZoom);

    // Camada do OpenStreetMap.
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Camada exclusiva para as empresas cadastradas.
    companyLayer = L.layerGroup().addTo(map);

    renderBusinessMarker();
    renderCompanyMarkers();
    renderCompanyList();
}

/**
 * ==========================================================================
 * CRIAÇÃO DOS MARCADORES
 * ==========================================================================
 */
function createMapIcon(type, label) {
    return L.divIcon({
        className: "",
        html: `<div class="custom-map-marker ${type}"><span>${label}</span></div>`,
        iconSize: [36, 44],
        iconAnchor: [18, 43],
        popupAnchor: [0, -42]
    });
}

/**
 * ==========================================================================
 * MARCADOR DA TEAMWAVE
 * ==========================================================================
 */
function renderBusinessMarker() {
    const business = AppConfig.business;
    const businessIcon = createMapIcon("business-map-marker", "TW");

    businessMarker = L.marker(business.coordenadas, {
        icon: businessIcon,
        title: business.nome
    }).addTo(map);

    businessMarker.bindPopup(`
        <div>
            <h4>${escapeHTML(business.nome)}</h4>
            <p>${escapeHTML(business.descricao)}</p>
            <p>${escapeHTML(business.endereco)}</p>
        </div>
    `);

    // Seleciona a sede quando seu popup for aberto.
    businessMarker.on("popupopen", () => {
        selectCompany({
            id: business.id,
            name: business.nome,
            description: business.descricao,
            latitude: business.coordenadas[0],
            longitude: business.coordenadas[1]
        });
    });
}

/**
 * ==========================================================================
 * CARREGAMENTO DAS EMPRESAS SALVAS
 * ==========================================================================
 */
function loadCompanies() {
    try {
        const savedCompanies = localStorage.getItem(AppConfig.storageKey);

        if (!savedCompanies) {
            return [];
        }

        const parsedCompanies = JSON.parse(savedCompanies);

        if (!Array.isArray(parsedCompanies)) {
            return [];
        }

        return parsedCompanies.filter(company => {
            return (
                company &&
                typeof company.id === "string" &&
                typeof company.name === "string" &&
                typeof company.description === "string" &&
                Number.isFinite(company.latitude) &&
                Number.isFinite(company.longitude) &&
                company.latitude >= -90 &&
                company.latitude <= 90 &&
                company.longitude >= -180 &&
                company.longitude <= 180
            );
        });
    } catch (error) {
        console.error("Erro ao recuperar empresas:", error);
        return [];
    }
}

/**
 * ==========================================================================
 * SALVAMENTO DAS EMPRESAS
 * ==========================================================================
 */
function saveCompanies() {
    try {
        localStorage.setItem(AppConfig.storageKey, JSON.stringify(companies));
        return true;
    } catch (error) {
        console.error("Erro ao salvar empresas:", error);
        return false;
    }
}

/**
 * ==========================================================================
 * MARCADORES DAS OUTRAS EMPRESAS
 * ==========================================================================
 */
function renderCompanyMarkers() {
    companyLayer.clearLayers();
    companyMarkers.clear();

    companies.forEach(company => {
        const companyIcon = createMapIcon("company-map-marker", "EM");

        const marker = L.marker(
            [company.latitude, company.longitude],
            {
                icon: companyIcon,
                title: company.name
            }
        ).addTo(companyLayer);

        // Informações exibidas ao clicar no marcador.
        marker.bindPopup(`
            <div class="company-popup">
                <h4>${escapeHTML(company.name)}</h4>
                <p>${escapeHTML(company.description).replace(/\n/g, "<br>")}</p>
                <p><strong>Latitude:</strong> ${company.latitude.toFixed(6)}</p>
                <p><strong>Longitude:</strong> ${company.longitude.toFixed(6)}</p>
            </div>
        `);

        // Seleciona a empresa e calcula a distância até o cliente.
        marker.on("click", () => {
            selectCompany(company);
        });

        companyMarkers.set(company.id, marker);
    });
}

/**
 * ==========================================================================
 * PROTEÇÃO DOS TEXTOS DOS POPUPS
 * ==========================================================================
 */
function escapeHTML(text) {
    return String(text).replace(/[&<>"']/g, character => {
        const characters = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        };

        return characters[character];
    });
}

/**
 * ==========================================================================
 * SELEÇÃO DE UMA EMPRESA PARA CALCULAR A DISTÂNCIA
 * ==========================================================================
 */
function selectCompany(company) {
    // Guarda a empresa escolhida pelo usuário.
    selectedCompany = company;

    // Atualiza o nome apresentado no painel.
    selectedCompanyName.textContent = company.name;

    // Mostra o painel de distância.
    distancePanel.classList.remove("hidden");

    // Calcula a distância somente para a empresa selecionada.
    updateDistance();

    // Ajusta o mapa para mostrar os dois pontos, quando possível.
    fitSelectedCompany();
}

// Seleciona a sede da TeamWave ao clicar no card.
function selectTeamWaveBusiness() {
    selectCompany({
        id: AppConfig.business.id,
        name: AppConfig.business.nome,
        description: AppConfig.business.descricao,
        latitude: AppConfig.business.coordenadas[0],
        longitude: AppConfig.business.coordenadas[1]
    });
}

/**
 * ==========================================================================
 * ATUALIZAÇÃO DA DISTÂNCIA DA EMPRESA SELECIONADA
 * ==========================================================================
 */
function updateDistance() {
    // Remove a linha anterior.
    if (distanceLine) {
        map.removeLayer(distanceLine);
        distanceLine = null;
    }

    // Não calcula distância se nenhuma empresa foi selecionada.
    if (!selectedCompany) {
        distancePanel.classList.add("hidden");
        return;
    }

    selectedCompanyName.textContent = selectedCompany.name;

    // Verifica se a localização do cliente foi obtida.
    if (!userCoords) {
        distanceText.textContent = "Indisponível";
        distanceNote.textContent = "Autorize o acesso à sua localização para calcular a distância até esta empresa.";
        return;
    }

    const companyCoords = [
        selectedCompany.latitude,
        selectedCompany.longitude
    ];

    // Calcula a distância entre o cliente e a empresa selecionada.
    const distanceInMeters = calculateDistance(
        userCoords[0],
        userCoords[1],
        companyCoords[0],
        companyCoords[1]
    );

    distanceText.textContent = formatDistance(distanceInMeters);
    distanceNote.textContent = "Distância aproximada em linha reta entre sua localização e a empresa selecionada.";

    // Desenha a linha entre o usuário e a empresa selecionada.
    distanceLine = L.polyline(
        [userCoords, companyCoords],
        {
            color: "#3159d9",
            weight: 3,
            opacity: 0.85,
            dashArray: "7, 8"
        }
    ).addTo(map);
}

/**
 * ==========================================================================
 * CENTRALIZAÇÃO DA EMPRESA SELECIONADA
 * ==========================================================================
 */
function fitSelectedCompany() {
    if (!selectedCompany) {
        return;
    }

    const companyCoords = [
        selectedCompany.latitude,
        selectedCompany.longitude
    ];

    // Quando a localização do usuário está disponível, mostra os dois pontos.
    if (userCoords) {
        const bounds = L.latLngBounds([
            userCoords,
            companyCoords
        ]);

        map.fitBounds(bounds, {
            padding: [55, 55],
            maxZoom: 14,
            animate: true
        });
    } else {
        map.setView(companyCoords, 15);
    }
}

/**
 * ==========================================================================
 * LISTA LATERAL DE EMPRESAS
 * ==========================================================================
 */
function renderCompanyList() {
    companyList.replaceChildren();
    companyCount.textContent = companies.length;

    if (companies.length === 0) {
        const emptyMessage = document.createElement("p");
        emptyMessage.className = "empty-companies";
        emptyMessage.textContent = "Nenhuma empresa cadastrada.";
        companyList.appendChild(emptyMessage);
        return;
    }

    companies.forEach(company => {
        const item = document.createElement("div");
        item.className = "company-item";

        const info = document.createElement("div");
        info.className = "company-item-info";

        const name = document.createElement("strong");
        name.textContent = company.name;

        const coordinates = document.createElement("small");
        coordinates.textContent = `${company.latitude.toFixed(4)}, ${company.longitude.toFixed(4)}`;

        info.appendChild(name);
        info.appendChild(coordinates);

        const actions = document.createElement("div");
        actions.className = "company-item-actions";

        const viewButton = document.createElement("button");
        viewButton.type = "button";
        viewButton.className = "btn-view-company";
        viewButton.textContent = "Ver";
        viewButton.dataset.id = company.id;

        actions.appendChild(viewButton);

        item.appendChild(info);
        item.appendChild(actions);

        companyList.appendChild(item);
    });
}

/**
 * ==========================================================================
 * EVENTOS DA LISTA DE EMPRESAS
 * ==========================================================================
 */
function handleCompanyListClick(event) {
    const viewButton = event.target.closest(".btn-view-company");

    if (viewButton) {
        const company = companies.find(item => item.id === viewButton.dataset.id);

        if (company) {
            selectCompany(company);

            const marker = companyMarkers.get(company.id);

            if (marker) {
                marker.openPopup();
            }
        }
    }

}

/**
 * ==========================================================================
 * MENSAGENS DA LISTA DE EMPRESAS
 * ==========================================================================
 */
function updateCompanyStatus(type, message) {
    companyStatus.className = `company-status ${type}`;
    companyStatus.textContent = message;
}

/**
 * ==========================================================================
 * GEOLOCALIZAÇÃO DO CLIENTE
 * ==========================================================================
 */
function executeGeolocation() {
    if (!navigator.geolocation) {
        updateUIStatus("error", "Seu navegador não oferece suporte à geolocalização. Você ainda pode visualizar as empresas.");
        btnRetry.classList.add("hidden");
        return;
    }

    if (!window.isSecureContext) {
        updateUIStatus("error", "Abra o projeto em uma conexão segura (HTTPS) ou em um servidor local, como o Live Server.");
        btnRetry.classList.add("hidden");
        return;
    }

    updateUIStatus("info", "Aguardando sua autorização no navegador para acessar a localização...");
    btnRetry.classList.add("hidden");

    const geoOptions = {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0
    };

    navigator.geolocation.getCurrentPosition(
        handleGeoSuccess,
        handleGeoError,
        geoOptions
    );
}

/**
 * ==========================================================================
 * LOCALIZAÇÃO DO CLIENTE ENCONTRADA
 * ==========================================================================
 */
function handleGeoSuccess(position) {
    const lat = position.coords.latitude;
    const lng = position.coords.longitude;
    const accuracy = position.coords.accuracy;

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
        handleGeoError({ code: 2 });
        return;
    }

    userCoords = [lat, lng];

    updateUIStatus("success", "Localização encontrada! Clique em uma empresa no mapa para calcular a distância até ela.");

    btnRetry.classList.add("hidden");
    btnRecenter.classList.remove("hidden");

    renderUserMarker(accuracy);

    // Só calcula a distância se o usuário já tiver selecionado uma empresa.
    if (selectedCompany) {
        updateDistance();
        fitSelectedCompany();
    } else {
        // Sem empresa selecionada, apenas mostra as localizações no mapa.
        fitAllLocations();
    }
}

/**
 * ==========================================================================
 * MARCADOR DA LOCALIZAÇÃO DO CLIENTE
 * ==========================================================================
 */
function renderUserMarker(accuracy) {
    const userIcon = createMapIcon("client-map-marker", "EU");

    if (userMarker) {
        map.removeLayer(userMarker);
    }

    if (userAccuracyCircle) {
        map.removeLayer(userAccuracyCircle);
    }

    userMarker = L.marker(userCoords, {
        icon: userIcon,
        title: "Sua localização atual"
    }).addTo(map);

    userMarker.bindPopup(`
        <div>
            <h4>Você está aqui!</h4>
            <p>Precisão aproximada: ${formatDistance(accuracy)}.</p>
        </div>
    `);

    if (Number.isFinite(accuracy) && accuracy > 0) {
        userAccuracyCircle = L.circle(userCoords, {
            radius: accuracy,
            color: "#2563eb",
            weight: 1,
            opacity: 0.55,
            fillColor: "#2563eb",
            fillOpacity: 0.08
        }).addTo(map);
    }
}

/**
 * ==========================================================================
 * TRATAMENTO DE ERROS DA GEOLOCALIZAÇÃO
 * ==========================================================================
 */
function handleGeoError(error) {
    let message = "Não foi possível obter sua localização atual.";
    const errorCode = error && Number(error.code);

    switch (errorCode) {
        case 1:
            message = "O acesso à localização foi negado. Altere a permissão nas configurações do navegador e tente novamente.";
            break;
        case 2:
            message = "Sua localização não está disponível no momento. Verifique o GPS ou a conexão.";
            break;
        case 3:
            message = "A busca pela localização demorou demais. Tente novamente.";
            break;
        default:
            message = "Ocorreu um erro ao obter sua localização. Você ainda pode visualizar as empresas cadastradas.";
    }

    updateUIStatus("error", message);

    btnRetry.classList.remove("hidden");
    btnRecenter.classList.add("hidden");

    if (!userCoords) {
        map.setView(AppConfig.business.coordenadas, AppConfig.defaultZoom);
    }

    // Não calcula distância automaticamente.
    // Se houver uma empresa selecionada, aguarda a localização do usuário.
    if (selectedCompany) {
        updateDistance();
    }
}

/**
 * ==========================================================================
 * FÓRMULA DE HAVERSINE
 * ==========================================================================
 */
function calculateDistance(lat1, lon1, lat2, lon2) {
    const earthRadius = 6371000;

    const toRadians = degrees => {
        return degrees * (Math.PI / 180);
    };

    const deltaLat = toRadians(lat2 - lat1);
    const deltaLon = toRadians(lon2 - lon1);

    const a = Math.sin(deltaLat / 2) ** 2 +
        Math.cos(toRadians(lat1)) *
        Math.cos(toRadians(lat2)) *
        Math.sin(deltaLon / 2) ** 2;

    const centralAngle = 2 * Math.atan2(
        Math.sqrt(a),
        Math.sqrt(1 - a)
    );

    return earthRadius * centralAngle;
}

/**
 * ==========================================================================
 * FORMATAÇÃO DA DISTÂNCIA
 * ==========================================================================
 */
function formatDistance(meters) {
    if (!Number.isFinite(meters)) {
        return "Indisponível";
    }

    if (meters < 1000) {
        return `${Math.round(meters)} m`;
    }

    return `${(meters / 1000).toLocaleString("pt-BR", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })} km`;
}

/**
 * ==========================================================================
 * CENTRALIZAÇÃO DE TODAS AS LOCALIZAÇÕES
 * ==========================================================================
 */
function fitAllLocations() {
    const locations = [AppConfig.business.coordenadas];

    if (userCoords) {
        locations.push(userCoords);
    }

    companies.forEach(company => {
        locations.push([company.latitude, company.longitude]);
    });

    const bounds = L.latLngBounds(locations);

    map.fitBounds(bounds, {
        padding: [55, 55],
        maxZoom: 14,
        animate: true
    });
}

/**
 * ==========================================================================
 * ATUALIZAÇÃO DO STATUS DA GEOLOCALIZAÇÃO
 * ==========================================================================
 */
function updateUIStatus(type, message) {
    statusCard.className = `status-card ${type}`;
    statusText.textContent = message;
}

/**
 * ==========================================================================
 * EVENTOS DOS BOTÕES E FORMULÁRIOS
 * ==========================================================================
 */

// Botões da lista de empresas.
companyList.addEventListener("click", handleCompanyListClick);

// Nova tentativa de obter localização.
btnRetry.addEventListener("click", executeGeolocation);

// Evento de clique no card.
businessCard.addEventListener("click", selectTeamWaveBusiness);

// Permite selecionar o card utilizando Enter ou Espaço.
businessCard.addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectTeamWaveBusiness();
    }
});

// Centralização do mapa na localização do usuário.
btnRecenter.addEventListener("click", () => {
    if (userCoords) {
        map.setView(userCoords, 15, { animate: true });
    } else {
        map.setView(AppConfig.business.coordenadas, AppConfig.defaultZoom);
    }
});

/**
 * ==========================================================================
 * INICIALIZAÇÃO DA APLICAÇÃO
 * ==========================================================================
 */
document.addEventListener("DOMContentLoaded", () => {
    initMap();
    executeGeolocation();
});